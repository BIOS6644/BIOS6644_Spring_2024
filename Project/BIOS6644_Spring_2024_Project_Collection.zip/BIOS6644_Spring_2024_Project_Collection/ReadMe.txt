
This is a collection of final projects submitted by students in the Spring 2024 run of BIOS6644: Practical Data Wrangling at the Colorado School of Public Health.

"Donating" to this collection was strictly voluntary and authors have concurred that no PII or other protected data is in these notebooks.

Copyright is held by the respective authors.  Permission has been given to share this collection for reference and academic purposes only.

POC:  James King (course instructor)
      james.king@cuanschutz.edu


