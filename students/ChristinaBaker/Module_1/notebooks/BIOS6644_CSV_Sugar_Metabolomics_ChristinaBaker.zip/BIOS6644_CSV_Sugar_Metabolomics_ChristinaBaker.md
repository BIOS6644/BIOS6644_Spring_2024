```python
##########################################################################################
#                                                                                        #
#  888888b.  8888888 .d88888b.   .d8888b.     .d8888b.   .d8888b.      d8888      d8888  #
#  888  "88b   888  d88P" "Y88b d88P  Y88b   d88P  Y88b d88P  Y88b    d8P888     d8P888  #
#  888  .88P   888  888     888 Y88b.        888        888          d8P 888    d8P 888  #
#  8888888K.   888  888     888  "Y888b.     888d888b.  888d888b.   d8P  888   d8P  888  #
#  888  "Y88b  888  888     888     "Y88b.   888P "Y88b 888P "Y88b d88   888  d88   888  #
#  888    888  888  888     888       "888   888    888 888    888 8888888888 8888888888 #
#  888   d88P  888  Y88b. .d88P Y88b  d88P   Y88b  d88P Y88b  d88P       888        888  #
#  8888888P" 8888888 "Y88888P"   "Y8888P"     "Y8888P"   "Y8888P"        888        888  #
#                                                                                        # 
##########################################################################################
#
# Slicing and Parsing
#
##########################################################################################
```


```python
##################################################################################################################
#
# YouDo:
#    1) Make a copy of this notebook with your name as a suffix:  
#       BIOS6644_CSV_Sugar_Metabolomics_FirstLast.ipynb
#    2) Do all work in this new notebook.
#    3) Place completed work in students/Module_1/Your_Name
#    4) Push to your branch on GitHub to submit
#
##################################################################################################################

```

# Wrangling Sugar Metabolomics Data



```python

import pandas as pd
import pylab as plt
import numpy as np
%matplotlib widget
```


```python


# General info here:
#   https://data.mendeley.com/datasets/9z7ncwvxnz/1
#
# Data here:
#   https://prod-dcd-datasets-cache-zipfiles.s3.eu-west-1.amazonaws.com/9z7ncwvxnz-1.zip

# I renamed mine to "sugar_metabolomics.csv" so I could remember what it is
data = '../Data/sugar_metabolomics.csv'

```


```python
data = 'C:/Users/chl_b/BIOS6644_Spring_2024_OLD/Modules/students/Module_1/data/sugar_metabolomics.csv'
```


```python
df = pd.read_csv(data)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Label</th>
      <th>Pyruvate</th>
      <th>MethylSuccinate</th>
      <th>Phosphoglyceric Acid</th>
      <th>Glucose 1-phosphate</th>
      <th>Malonic Acid</th>
      <th>Fumaric Acid</th>
      <th>Alpha-Ketoglutaric Acid</th>
      <th>Sarcosine</th>
      <th>...</th>
      <th>3-Hydroxybenzoic acid</th>
      <th>Succinate</th>
      <th>Glucose</th>
      <th>V127</th>
      <th>V128</th>
      <th>V129</th>
      <th>V130</th>
      <th>V131</th>
      <th>V132</th>
      <th>V133</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20</td>
      <td>0</td>
      <td>14.158545</td>
      <td>15.624522</td>
      <td>13.383600</td>
      <td>11.923638</td>
      <td>13.933560</td>
      <td>12.787696</td>
      <td>14.981440</td>
      <td>11.739484</td>
      <td>...</td>
      <td>3.161390</td>
      <td>2.165842</td>
      <td>8.310291624</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>24</td>
      <td>0</td>
      <td>14.180287</td>
      <td>15.325665</td>
      <td>13.468363</td>
      <td>12.046294</td>
      <td>13.043221</td>
      <td>12.536227</td>
      <td>14.593418</td>
      <td>11.833211</td>
      <td>...</td>
      <td>2.355910</td>
      <td>2.260621</td>
      <td>8.423733003</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>29</td>
      <td>0</td>
      <td>13.921329</td>
      <td>16.156867</td>
      <td>14.615061</td>
      <td>13.051929</td>
      <td>13.381985</td>
      <td>12.419600</td>
      <td>14.701978</td>
      <td>12.232070</td>
      <td>...</td>
      <td>2.472365</td>
      <td>2.295447</td>
      <td>8.357070943</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>52</td>
      <td>0</td>
      <td>13.785605</td>
      <td>15.939535</td>
      <td>13.206615</td>
      <td>12.342156</td>
      <td>12.448068</td>
      <td>12.211098</td>
      <td>14.860913</td>
      <td>11.949448</td>
      <td>...</td>
      <td>1.844567</td>
      <td>2.278589</td>
      <td>8.414503996</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>54</td>
      <td>0</td>
      <td>13.674234</td>
      <td>15.743668</td>
      <td>11.542008</td>
      <td>11.807872</td>
      <td>14.582068</td>
      <td>11.635154</td>
      <td>14.970451</td>
      <td>11.457569</td>
      <td>...</td>
      <td>3.773262</td>
      <td>2.136011</td>
      <td>8.193979575</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>88</th>
      <td>100</td>
      <td>1</td>
      <td>13.911391</td>
      <td>15.808535</td>
      <td>13.255651</td>
      <td>12.072060</td>
      <td>12.829308</td>
      <td>12.518926</td>
      <td>14.914205</td>
      <td>12.009783</td>
      <td>...</td>
      <td>2.099744</td>
      <td>2.460060</td>
      <td>8.268259167</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>89</th>
      <td>101</td>
      <td>1</td>
      <td>14.004190</td>
      <td>15.578057</td>
      <td>15.050097</td>
      <td>12.955338</td>
      <td>12.021058</td>
      <td>12.698247</td>
      <td>14.838858</td>
      <td>11.864216</td>
      <td>...</td>
      <td>1.215855</td>
      <td>2.716850</td>
      <td>8.382160574</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>90</th>
      <td>102</td>
      <td>1</td>
      <td>13.782098</td>
      <td>15.628488</td>
      <td>13.800509</td>
      <td>12.324283</td>
      <td>13.557521</td>
      <td>13.930284</td>
      <td>15.010427</td>
      <td>11.877001</td>
      <td>...</td>
      <td>2.567097</td>
      <td>2.339410</td>
      <td>8.362964723</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>91</th>
      <td>103</td>
      <td>1</td>
      <td>13.841570</td>
      <td>15.697214</td>
      <td>14.467861</td>
      <td>12.549533</td>
      <td>13.157717</td>
      <td>14.309882</td>
      <td>14.518098</td>
      <td>12.173317</td>
      <td>...</td>
      <td>1.637428</td>
      <td>2.147184</td>
      <td>8.379107727</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>92</th>
      <td>104</td>
      <td>1</td>
      <td>13.621706</td>
      <td>15.483609</td>
      <td>14.060104</td>
      <td>12.237578</td>
      <td>13.847064</td>
      <td>13.140827</td>
      <td>14.923120</td>
      <td>12.129161</td>
      <td>...</td>
      <td>3.024477</td>
      <td>2.641430</td>
      <td>8.477305855""""""""</td>
      <td>""""""""NA""""""""</td>
      <td>""""""""NA""""""""</td>
      <td>""""""""NA""""""""</td>
      <td>""""""""NA""""""""</td>
      <td>""""""""NA""""""""</td>
      <td>""""""""NA""""""""</td>
      <td>""""""""0""""""""</td>
    </tr>
  </tbody>
</table>
<p>93 rows × 133 columns</p>
</div>




```python
# I can see here that there are 93 rows and 133 columns. the first column is the row number, then column 1 is called unnamed:0, then Label, etc.The insturctions
# are to Ensure your data frame has the following handled correctly
#         a) the column names (1st row of the csv)
#.        b) The unlabeled first column is read as an index
#         c) The final row is totally weird--don't import it
#

```


```python
pd.read_csv?
```


    [1;31mSignature:[0m
    [0mpd[0m[1;33m.[0m[0mread_csv[0m[1;33m([0m[1;33m
    [0m    [0mfilepath_or_buffer[0m[1;33m:[0m [1;34m'FilePath | ReadCsvBuffer[bytes] | ReadCsvBuffer[str]'[0m[1;33m,[0m[1;33m
    [0m    [1;33m*[0m[1;33m,[0m[1;33m
    [0m    [0msep[0m[1;33m:[0m [1;34m'str | None | lib.NoDefault'[0m [1;33m=[0m [1;33m<[0m[0mno_default[0m[1;33m>[0m[1;33m,[0m[1;33m
    [0m    [0mdelimiter[0m[1;33m:[0m [1;34m'str | None | lib.NoDefault'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mheader[0m[1;33m:[0m [1;34m"int | Sequence[int] | None | Literal['infer']"[0m [1;33m=[0m [1;34m'infer'[0m[1;33m,[0m[1;33m
    [0m    [0mnames[0m[1;33m:[0m [1;34m'Sequence[Hashable] | None | lib.NoDefault'[0m [1;33m=[0m [1;33m<[0m[0mno_default[0m[1;33m>[0m[1;33m,[0m[1;33m
    [0m    [0mindex_col[0m[1;33m:[0m [1;34m'IndexLabel | Literal[False] | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0musecols[0m[1;33m:[0m [1;34m'list[HashableT] | Callable[[Hashable], bool] | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mdtype[0m[1;33m:[0m [1;34m'DtypeArg | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mengine[0m[1;33m:[0m [1;34m'CSVEngine | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mconverters[0m[1;33m:[0m [1;34m'Mapping[Hashable, Callable] | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mtrue_values[0m[1;33m:[0m [1;34m'list | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mfalse_values[0m[1;33m:[0m [1;34m'list | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mskipinitialspace[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mFalse[0m[1;33m,[0m[1;33m
    [0m    [0mskiprows[0m[1;33m:[0m [1;34m'list[int] | int | Callable[[Hashable], bool] | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mskipfooter[0m[1;33m:[0m [1;34m'int'[0m [1;33m=[0m [1;36m0[0m[1;33m,[0m[1;33m
    [0m    [0mnrows[0m[1;33m:[0m [1;34m'int | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mna_values[0m[1;33m:[0m [1;34m'Sequence[str] | Mapping[str, Sequence[str]] | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mkeep_default_na[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mTrue[0m[1;33m,[0m[1;33m
    [0m    [0mna_filter[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mTrue[0m[1;33m,[0m[1;33m
    [0m    [0mverbose[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mFalse[0m[1;33m,[0m[1;33m
    [0m    [0mskip_blank_lines[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mTrue[0m[1;33m,[0m[1;33m
    [0m    [0mparse_dates[0m[1;33m:[0m [1;34m'bool | Sequence[Hashable] | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0minfer_datetime_format[0m[1;33m:[0m [1;34m'bool | lib.NoDefault'[0m [1;33m=[0m [1;33m<[0m[0mno_default[0m[1;33m>[0m[1;33m,[0m[1;33m
    [0m    [0mkeep_date_col[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mFalse[0m[1;33m,[0m[1;33m
    [0m    [0mdate_parser[0m[1;33m:[0m [1;34m'Callable | lib.NoDefault'[0m [1;33m=[0m [1;33m<[0m[0mno_default[0m[1;33m>[0m[1;33m,[0m[1;33m
    [0m    [0mdate_format[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mdayfirst[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mFalse[0m[1;33m,[0m[1;33m
    [0m    [0mcache_dates[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mTrue[0m[1;33m,[0m[1;33m
    [0m    [0miterator[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mFalse[0m[1;33m,[0m[1;33m
    [0m    [0mchunksize[0m[1;33m:[0m [1;34m'int | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mcompression[0m[1;33m:[0m [1;34m'CompressionOptions'[0m [1;33m=[0m [1;34m'infer'[0m[1;33m,[0m[1;33m
    [0m    [0mthousands[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mdecimal[0m[1;33m:[0m [1;34m'str'[0m [1;33m=[0m [1;34m'.'[0m[1;33m,[0m[1;33m
    [0m    [0mlineterminator[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mquotechar[0m[1;33m:[0m [1;34m'str'[0m [1;33m=[0m [1;34m'"'[0m[1;33m,[0m[1;33m
    [0m    [0mquoting[0m[1;33m:[0m [1;34m'int'[0m [1;33m=[0m [1;36m0[0m[1;33m,[0m[1;33m
    [0m    [0mdoublequote[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mTrue[0m[1;33m,[0m[1;33m
    [0m    [0mescapechar[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mcomment[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mencoding[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mencoding_errors[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;34m'strict'[0m[1;33m,[0m[1;33m
    [0m    [0mdialect[0m[1;33m:[0m [1;34m'str | csv.Dialect | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mon_bad_lines[0m[1;33m:[0m [1;34m'str'[0m [1;33m=[0m [1;34m'error'[0m[1;33m,[0m[1;33m
    [0m    [0mdelim_whitespace[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mFalse[0m[1;33m,[0m[1;33m
    [0m    [0mlow_memory[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mTrue[0m[1;33m,[0m[1;33m
    [0m    [0mmemory_map[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mFalse[0m[1;33m,[0m[1;33m
    [0m    [0mfloat_precision[0m[1;33m:[0m [1;34m"Literal['high', 'legacy'] | None"[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mstorage_options[0m[1;33m:[0m [1;34m'StorageOptions | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mdtype_backend[0m[1;33m:[0m [1;34m'DtypeBackend | lib.NoDefault'[0m [1;33m=[0m [1;33m<[0m[0mno_default[0m[1;33m>[0m[1;33m,[0m[1;33m
    [0m[1;33m)[0m [1;33m->[0m [1;34m'DataFrame | TextFileReader'[0m[1;33m[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Read a comma-separated values (csv) file into DataFrame.
    
    Also supports optionally iterating or breaking of the file
    into chunks.
    
    Additional help can be found in the online docs for
    `IO Tools <https://pandas.pydata.org/pandas-docs/stable/user_guide/io.html>`_.
    
    Parameters
    ----------
    filepath_or_buffer : str, path object or file-like object
        Any valid string path is acceptable. The string could be a URL. Valid
        URL schemes include http, ftp, s3, gs, and file. For file URLs, a host is
        expected. A local file could be: file://localhost/path/to/table.csv.
    
        If you want to pass in a path object, pandas accepts any ``os.PathLike``.
    
        By file-like object, we refer to objects with a ``read()`` method, such as
        a file handle (e.g. via builtin ``open`` function) or ``StringIO``.
    sep : str, default ','
        Character or regex pattern to treat as the delimiter. If ``sep=None``, the
        C engine cannot automatically detect
        the separator, but the Python parsing engine can, meaning the latter will
        be used and automatically detect the separator from only the first valid
        row of the file by Python's builtin sniffer tool, ``csv.Sniffer``.
        In addition, separators longer than 1 character and different from
        ``'\s+'`` will be interpreted as regular expressions and will also force
        the use of the Python parsing engine. Note that regex delimiters are prone
        to ignoring quoted data. Regex example: ``'\r\t'``.
    delimiter : str, optional
        Alias for ``sep``.
    header : int, Sequence of int, 'infer' or None, default 'infer'
        Row number(s) containing column labels and marking the start of the
        data (zero-indexed). Default behavior is to infer the column names: if no ``names``
        are passed the behavior is identical to ``header=0`` and column
        names are inferred from the first line of the file, if column
        names are passed explicitly to ``names`` then the behavior is identical to
        ``header=None``. Explicitly pass ``header=0`` to be able to
        replace existing names. The header can be a list of integers that
        specify row locations for a :class:`~pandas.MultiIndex` on the columns
        e.g. ``[0, 1, 3]``. Intervening rows that are not specified will be
        skipped (e.g. 2 in this example is skipped). Note that this
        parameter ignores commented lines and empty lines if
        ``skip_blank_lines=True``, so ``header=0`` denotes the first line of
        data rather than the first line of the file.
    names : Sequence of Hashable, optional
        Sequence of column labels to apply. If the file contains a header row,
        then you should explicitly pass ``header=0`` to override the column names.
        Duplicates in this list are not allowed.
    index_col : Hashable, Sequence of Hashable or False, optional
      Column(s) to use as row label(s), denoted either by column labels or column
      indices.  If a sequence of labels or indices is given, :class:`~pandas.MultiIndex`
      will be formed for the row labels.
    
      Note: ``index_col=False`` can be used to force pandas to *not* use the first
      column as the index, e.g., when you have a malformed file with delimiters at
      the end of each line.
    usecols : list of Hashable or Callable, optional
        Subset of columns to select, denoted either by column labels or column indices.
        If list-like, all elements must either
        be positional (i.e. integer indices into the document columns) or strings
        that correspond to column names provided either by the user in ``names`` or
        inferred from the document header row(s). If ``names`` are given, the document
        header row(s) are not taken into account. For example, a valid list-like
        ``usecols`` parameter would be ``[0, 1, 2]`` or ``['foo', 'bar', 'baz']``.
        Element order is ignored, so ``usecols=[0, 1]`` is the same as ``[1, 0]``.
        To instantiate a :class:`~pandas.DataFrame` from ``data`` with element order
        preserved use ``pd.read_csv(data, usecols=['foo', 'bar'])[['foo', 'bar']]``
        for columns in ``['foo', 'bar']`` order or
        ``pd.read_csv(data, usecols=['foo', 'bar'])[['bar', 'foo']]``
        for ``['bar', 'foo']`` order.
    
        If callable, the callable function will be evaluated against the column
        names, returning names where the callable function evaluates to ``True``. An
        example of a valid callable argument would be ``lambda x: x.upper() in
        ['AAA', 'BBB', 'DDD']``. Using this parameter results in much faster
        parsing time and lower memory usage.
    dtype : dtype or dict of {Hashable : dtype}, optional
        Data type(s) to apply to either the whole dataset or individual columns.
        E.g., ``{'a': np.float64, 'b': np.int32, 'c': 'Int64'}``
        Use ``str`` or ``object`` together with suitable ``na_values`` settings
        to preserve and not interpret ``dtype``.
        If ``converters`` are specified, they will be applied INSTEAD
        of ``dtype`` conversion.
    
        .. versionadded:: 1.5.0
    
            Support for ``defaultdict`` was added. Specify a ``defaultdict`` as input where
            the default determines the ``dtype`` of the columns which are not explicitly
            listed.
    engine : {'c', 'python', 'pyarrow'}, optional
        Parser engine to use. The C and pyarrow engines are faster, while the python engine
        is currently more feature-complete. Multithreading is currently only supported by
        the pyarrow engine.
    
        .. versionadded:: 1.4.0
    
            The 'pyarrow' engine was added as an *experimental* engine, and some features
            are unsupported, or may not work correctly, with this engine.
    converters : dict of {Hashable : Callable}, optional
        Functions for converting values in specified columns. Keys can either
        be column labels or column indices.
    true_values : list, optional
        Values to consider as ``True`` in addition to case-insensitive variants of 'True'.
    false_values : list, optional
        Values to consider as ``False`` in addition to case-insensitive variants of 'False'.
    skipinitialspace : bool, default False
        Skip spaces after delimiter.
    skiprows : int, list of int or Callable, optional
        Line numbers to skip (0-indexed) or number of lines to skip (``int``)
        at the start of the file.
    
        If callable, the callable function will be evaluated against the row
        indices, returning ``True`` if the row should be skipped and ``False`` otherwise.
        An example of a valid callable argument would be ``lambda x: x in [0, 2]``.
    skipfooter : int, default 0
        Number of lines at bottom of file to skip (Unsupported with ``engine='c'``).
    nrows : int, optional
        Number of rows of file to read. Useful for reading pieces of large files.
    na_values : Hashable, Iterable of Hashable or dict of {Hashable : Iterable}, optional
        Additional strings to recognize as ``NA``/``NaN``. If ``dict`` passed, specific
        per-column ``NA`` values.  By default the following values are interpreted as
        ``NaN``: " ", "#N/A", "#N/A N/A", "#NA", "-1.#IND", "-1.#QNAN", "-NaN", "-nan",
        "1.#IND", "1.#QNAN", "<NA>", "N/A", "NA", "NULL", "NaN", "None",
        "n/a", "nan", "null ".
    
    keep_default_na : bool, default True
        Whether or not to include the default ``NaN`` values when parsing the data.
        Depending on whether ``na_values`` is passed in, the behavior is as follows:
    
        * If ``keep_default_na`` is ``True``, and ``na_values`` are specified, ``na_values``
          is appended to the default ``NaN`` values used for parsing.
        * If ``keep_default_na`` is ``True``, and ``na_values`` are not specified, only
          the default ``NaN`` values are used for parsing.
        * If ``keep_default_na`` is ``False``, and ``na_values`` are specified, only
          the ``NaN`` values specified ``na_values`` are used for parsing.
        * If ``keep_default_na`` is ``False``, and ``na_values`` are not specified, no
          strings will be parsed as ``NaN``.
    
        Note that if ``na_filter`` is passed in as ``False``, the ``keep_default_na`` and
        ``na_values`` parameters will be ignored.
    na_filter : bool, default True
        Detect missing value markers (empty strings and the value of ``na_values``). In
        data without any ``NA`` values, passing ``na_filter=False`` can improve the
        performance of reading a large file.
    verbose : bool, default False
        Indicate number of ``NA`` values placed in non-numeric columns.
    skip_blank_lines : bool, default True
        If ``True``, skip over blank lines rather than interpreting as ``NaN`` values.
    parse_dates : bool, list of Hashable, list of lists or dict of {Hashable : list}, default False
        The behavior is as follows:
    
        * ``bool``. If ``True`` -> try parsing the index.
        * ``list`` of ``int`` or names. e.g. If ``[1, 2, 3]`` -> try parsing columns 1, 2, 3
          each as a separate date column.
        * ``list`` of ``list``. e.g.  If ``[[1, 3]]`` -> combine columns 1 and 3 and parse
          as a single date column.
        * ``dict``, e.g. ``{'foo' : [1, 3]}`` -> parse columns 1, 3 as date and call
          result 'foo'
    
        If a column or index cannot be represented as an array of ``datetime``,
        say because of an unparsable value or a mixture of timezones, the column
        or index will be returned unaltered as an ``object`` data type. For
        non-standard ``datetime`` parsing, use :func:`~pandas.to_datetime` after
        :func:`~pandas.read_csv`.
    
        Note: A fast-path exists for iso8601-formatted dates.
    infer_datetime_format : bool, default False
        If ``True`` and ``parse_dates`` is enabled, pandas will attempt to infer the
        format of the ``datetime`` strings in the columns, and if it can be inferred,
        switch to a faster method of parsing them. In some cases this can increase
        the parsing speed by 5-10x.
    
        .. deprecated:: 2.0.0
            A strict version of this argument is now the default, passing it has no effect.
    
    keep_date_col : bool, default False
        If ``True`` and ``parse_dates`` specifies combining multiple columns then
        keep the original columns.
    date_parser : Callable, optional
        Function to use for converting a sequence of string columns to an array of
        ``datetime`` instances. The default uses ``dateutil.parser.parser`` to do the
        conversion. pandas will try to call ``date_parser`` in three different ways,
        advancing to the next if an exception occurs: 1) Pass one or more arrays
        (as defined by ``parse_dates``) as arguments; 2) concatenate (row-wise) the
        string values from the columns defined by ``parse_dates`` into a single array
        and pass that; and 3) call ``date_parser`` once for each row using one or
        more strings (corresponding to the columns defined by ``parse_dates``) as
        arguments.
    
        .. deprecated:: 2.0.0
           Use ``date_format`` instead, or read in as ``object`` and then apply
           :func:`~pandas.to_datetime` as-needed.
    date_format : str or dict of column -> format, optional
       Format to use for parsing dates when used in conjunction with ``parse_dates``.
       For anything more complex, please read in as ``object`` and then apply
       :func:`~pandas.to_datetime` as-needed.
    
       .. versionadded:: 2.0.0
    dayfirst : bool, default False
        DD/MM format dates, international and European format.
    cache_dates : bool, default True
        If ``True``, use a cache of unique, converted dates to apply the ``datetime``
        conversion. May produce significant speed-up when parsing duplicate
        date strings, especially ones with timezone offsets.
    
    iterator : bool, default False
        Return ``TextFileReader`` object for iteration or getting chunks with
        ``get_chunk()``.
    
        .. versionchanged:: 1.2
    
           ``TextFileReader`` is a context manager.
    chunksize : int, optional
        Number of lines to read from the file per chunk. Passing a value will cause the
        function to return a ``TextFileReader`` object for iteration.
        See the `IO Tools docs
        <https://pandas.pydata.org/pandas-docs/stable/io.html#io-chunking>`_
        for more information on ``iterator`` and ``chunksize``.
    
        .. versionchanged:: 1.2
    
           ``TextFileReader`` is a context manager.
    compression : str or dict, default 'infer'
        For on-the-fly decompression of on-disk data. If 'infer' and 'filepath_or_buffer' is
        path-like, then detect compression from the following extensions: '.gz',
        '.bz2', '.zip', '.xz', '.zst', '.tar', '.tar.gz', '.tar.xz' or '.tar.bz2'
        (otherwise no compression).
        If using 'zip' or 'tar', the ZIP file must contain only one data file to be read in.
        Set to ``None`` for no decompression.
        Can also be a dict with key ``'method'`` set
        to one of {``'zip'``, ``'gzip'``, ``'bz2'``, ``'zstd'``, ``'xz'``, ``'tar'``} and
        other key-value pairs are forwarded to
        ``zipfile.ZipFile``, ``gzip.GzipFile``,
        ``bz2.BZ2File``, ``zstandard.ZstdDecompressor``, ``lzma.LZMAFile`` or
        ``tarfile.TarFile``, respectively.
        As an example, the following could be passed for Zstandard decompression using a
        custom compression dictionary:
        ``compression={'method': 'zstd', 'dict_data': my_compression_dict}``.
    
        .. versionadded:: 1.5.0
            Added support for `.tar` files.
    
        .. versionchanged:: 1.4.0 Zstandard support.
    
    thousands : str (length 1), optional
        Character acting as the thousands separator in numerical values.
    decimal : str (length 1), default '.'
        Character to recognize as decimal point (e.g., use ',' for European data).
    lineterminator : str (length 1), optional
        Character used to denote a line break. Only valid with C parser.
    quotechar : str (length 1), optional
        Character used to denote the start and end of a quoted item. Quoted
        items can include the ``delimiter`` and it will be ignored.
    quoting : {0 or csv.QUOTE_MINIMAL, 1 or csv.QUOTE_ALL, 2 or csv.QUOTE_NONNUMERIC, 3 or csv.QUOTE_NONE}, default csv.QUOTE_MINIMAL
        Control field quoting behavior per ``csv.QUOTE_*`` constants. Default is
        ``csv.QUOTE_MINIMAL`` (i.e., 0) which implies that only fields containing special
        characters are quoted (e.g., characters defined in ``quotechar``, ``delimiter``,
        or ``lineterminator``.
    doublequote : bool, default True
       When ``quotechar`` is specified and ``quoting`` is not ``QUOTE_NONE``, indicate
       whether or not to interpret two consecutive ``quotechar`` elements INSIDE a
       field as a single ``quotechar`` element.
    escapechar : str (length 1), optional
        Character used to escape other characters.
    comment : str (length 1), optional
        Character indicating that the remainder of line should not be parsed.
        If found at the beginning
        of a line, the line will be ignored altogether. This parameter must be a
        single character. Like empty lines (as long as ``skip_blank_lines=True``),
        fully commented lines are ignored by the parameter ``header`` but not by
        ``skiprows``. For example, if ``comment='#'``, parsing
        ``#empty\na,b,c\n1,2,3`` with ``header=0`` will result in ``'a,b,c'`` being
        treated as the header.
    encoding : str, optional, default 'utf-8'
        Encoding to use for UTF when reading/writing (ex. ``'utf-8'``). `List of Python
        standard encodings
        <https://docs.python.org/3/library/codecs.html#standard-encodings>`_ .
    
        .. versionchanged:: 1.2
    
           When ``encoding`` is ``None``, ``errors='replace'`` is passed to
           ``open()``. Otherwise, ``errors='strict'`` is passed to ``open()``.
           This behavior was previously only the case for ``engine='python'``.
    
        .. versionchanged:: 1.3.0
    
           ``encoding_errors`` is a new argument. ``encoding`` has no longer an
           influence on how encoding errors are handled.
    
    encoding_errors : str, optional, default 'strict'
        How encoding errors are treated. `List of possible values
        <https://docs.python.org/3/library/codecs.html#error-handlers>`_ .
    
        .. versionadded:: 1.3.0
    
    dialect : str or csv.Dialect, optional
        If provided, this parameter will override values (default or not) for the
        following parameters: ``delimiter``, ``doublequote``, ``escapechar``,
        ``skipinitialspace``, ``quotechar``, and ``quoting``. If it is necessary to
        override values, a ``ParserWarning`` will be issued. See ``csv.Dialect``
        documentation for more details.
    on_bad_lines : {'error', 'warn', 'skip'} or Callable, default 'error'
        Specifies what to do upon encountering a bad line (a line with too many fields).
        Allowed values are :
    
        - ``'error'``, raise an Exception when a bad line is encountered.
        - ``'warn'``, raise a warning when a bad line is encountered and skip that line.
        - ``'skip'``, skip bad lines without raising or warning when they are encountered.
    
        .. versionadded:: 1.3.0
    
        .. versionadded:: 1.4.0
    
            - Callable, function with signature
              ``(bad_line: list[str]) -> list[str] | None`` that will process a single
              bad line. ``bad_line`` is a list of strings split by the ``sep``.
              If the function returns ``None``, the bad line will be ignored.
              If the function returns a new ``list`` of strings with more elements than
              expected, a ``ParserWarning`` will be emitted while dropping extra elements.
              Only supported when ``engine='python'``
    
    delim_whitespace : bool, default False
        Specifies whether or not whitespace (e.g. ``' '`` or ``'\t'``) will be
        used as the ``sep`` delimiter. Equivalent to setting ``sep='\s+'``. If this option
        is set to ``True``, nothing should be passed in for the ``delimiter``
        parameter.
    low_memory : bool, default True
        Internally process the file in chunks, resulting in lower memory use
        while parsing, but possibly mixed type inference.  To ensure no mixed
        types either set ``False``, or specify the type with the ``dtype`` parameter.
        Note that the entire file is read into a single :class:`~pandas.DataFrame`
        regardless, use the ``chunksize`` or ``iterator`` parameter to return the data in
        chunks. (Only valid with C parser).
    memory_map : bool, default False
        If a filepath is provided for ``filepath_or_buffer``, map the file object
        directly onto memory and access the data directly from there. Using this
        option can improve performance because there is no longer any I/O overhead.
    float_precision : {'high', 'legacy', 'round_trip'}, optional
        Specifies which converter the C engine should use for floating-point
        values. The options are ``None`` or ``'high'`` for the ordinary converter,
        ``'legacy'`` for the original lower precision pandas converter, and
        ``'round_trip'`` for the round-trip converter.
    
        .. versionchanged:: 1.2
    
    storage_options : dict, optional
        Extra options that make sense for a particular storage connection, e.g.
        host, port, username, password, etc. For HTTP(S) URLs the key-value pairs
        are forwarded to ``urllib.request.Request`` as header options. For other
        URLs (e.g. starting with "s3://", and "gcs://") the key-value pairs are
        forwarded to ``fsspec.open``. Please see ``fsspec`` and ``urllib`` for more
        details, and for more examples on storage options refer `here
        <https://pandas.pydata.org/docs/user_guide/io.html?
        highlight=storage_options#reading-writing-remote-files>`_.
    
        .. versionadded:: 1.2
    
    dtype_backend : {'numpy_nullable', 'pyarrow'}, default 'numpy_nullable'
        Back-end data type applied to the resultant :class:`DataFrame`
        (still experimental). Behaviour is as follows:
    
        * ``"numpy_nullable"``: returns nullable-dtype-backed :class:`DataFrame`
          (default).
        * ``"pyarrow"``: returns pyarrow-backed nullable :class:`ArrowDtype`
          DataFrame.
    
        .. versionadded:: 2.0
    
    Returns
    -------
    DataFrame or TextFileReader
        A comma-separated values (csv) file is returned as two-dimensional
        data structure with labeled axes.
    
    See Also
    --------
    DataFrame.to_csv : Write DataFrame to a comma-separated values (csv) file.
    read_table : Read general delimited file into DataFrame.
    read_fwf : Read a table of fixed-width formatted lines into DataFrame.
    
    Examples
    --------
    >>> pd.read_csv('data.csv')  # doctest: +SKIP
    [1;31mFile:[0m      c:\users\chl_b\anaconda3\lib\site-packages\pandas\io\parsers\readers.py
    [1;31mType:[0m      function



```python
##################################################################################################################
#
# YouDo:
# 
#    1) Notice that the import is wonky -- examine the data set
#       manually and figure out how to make it import cleanly.
#      
#       Ensure your data frame has the following handled correctly
#         a) the column names (1st row of the csv)
#.        b) The unlabeled first column is read as an index
#         c) The final row is totally weird--don't import it
#
#       (hint: pd.read_csv? lists various import options)
#
#######################################  BEGIN STUDENT CODE  #####################################################
# column name handling
df = pd.read_csv('C:/Users/chl_b/BIOS6644_Spring_2024_OLD/Modules/students/Module_1/data/sugar_metabolomics.csv')



# 1)making unlabeled first column to read as an index-see below



#######################################   END STUDENT CODE   #####################################################
#assert df.shape == (92, 132)
```


```python
print(f"Column Names:  {df.columns}")

# I am not sure what part a) means above that says"the column names (1st row of the csv)??
```

    Column Names:  Index(['Unnamed: 0', 'Label', 'Pyruvate', 'MethylSuccinate',
           'Phosphoglyceric Acid', 'Glucose 1-phosphate', 'Malonic Acid',
           'Fumaric Acid', 'Alpha-Ketoglutaric Acid', 'Sarcosine',
           ...
           '3-Hydroxybenzoic acid', 'Succinate', 'Glucose', 'V127', 'V128', 'V129',
           'V130', 'V131', 'V132', 'V133'],
          dtype='object', length=133)
    


```python
#get summaries of numerical fields
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Label</th>
      <th>Pyruvate</th>
      <th>MethylSuccinate</th>
      <th>Phosphoglyceric Acid</th>
      <th>Glucose 1-phosphate</th>
      <th>Malonic Acid</th>
      <th>Fumaric Acid</th>
      <th>Alpha-Ketoglutaric Acid</th>
      <th>Sarcosine</th>
      <th>...</th>
      <th>Methionine</th>
      <th>Histidine</th>
      <th>Phenylalanine</th>
      <th>Arginine</th>
      <th>Tyrosine</th>
      <th>Tryptophan</th>
      <th>Cystine</th>
      <th>lactate</th>
      <th>3-Hydroxybenzoic acid</th>
      <th>Succinate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>92.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>...</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
      <td>93.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>53.290323</td>
      <td>0.602151</td>
      <td>13.846534</td>
      <td>15.638135</td>
      <td>13.474366</td>
      <td>12.177811</td>
      <td>13.403452</td>
      <td>13.186031</td>
      <td>14.806625</td>
      <td>11.968439</td>
      <td>...</td>
      <td>3.097086</td>
      <td>4.410013</td>
      <td>4.001954</td>
      <td>4.353345</td>
      <td>3.638734</td>
      <td>3.446432</td>
      <td>3.184439</td>
      <td>6.723370</td>
      <td>2.515354</td>
      <td>2.343602</td>
    </tr>
    <tr>
      <th>std</th>
      <td>30.262468</td>
      <td>0.492107</td>
      <td>0.263409</td>
      <td>0.183434</td>
      <td>0.654588</td>
      <td>0.430470</td>
      <td>0.746551</td>
      <td>0.997958</td>
      <td>0.148203</td>
      <td>0.284143</td>
      <td>...</td>
      <td>0.165616</td>
      <td>0.122908</td>
      <td>0.117119</td>
      <td>0.179987</td>
      <td>0.235945</td>
      <td>0.231529</td>
      <td>0.277646</td>
      <td>0.287672</td>
      <td>0.707089</td>
      <td>0.252287</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>13.101075</td>
      <td>15.138233</td>
      <td>11.454016</td>
      <td>10.708722</td>
      <td>12.021058</td>
      <td>11.558824</td>
      <td>14.478469</td>
      <td>11.082123</td>
      <td>...</td>
      <td>2.649629</td>
      <td>4.091856</td>
      <td>3.767357</td>
      <td>3.883285</td>
      <td>2.969516</td>
      <td>2.588503</td>
      <td>2.442535</td>
      <td>6.074876</td>
      <td>1.215855</td>
      <td>1.530227</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>27.000000</td>
      <td>0.000000</td>
      <td>13.682746</td>
      <td>15.550370</td>
      <td>13.103939</td>
      <td>11.923638</td>
      <td>12.829308</td>
      <td>12.535203</td>
      <td>14.721283</td>
      <td>11.758245</td>
      <td>...</td>
      <td>3.014268</td>
      <td>4.315900</td>
      <td>3.919316</td>
      <td>4.259914</td>
      <td>3.504973</td>
      <td>3.313728</td>
      <td>3.029616</td>
      <td>6.515645</td>
      <td>1.890642</td>
      <td>2.169131</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>55.000000</td>
      <td>1.000000</td>
      <td>13.841570</td>
      <td>15.649060</td>
      <td>13.473905</td>
      <td>12.129888</td>
      <td>13.334791</td>
      <td>13.035004</td>
      <td>14.803905</td>
      <td>11.960705</td>
      <td>...</td>
      <td>3.074536</td>
      <td>4.400890</td>
      <td>4.011909</td>
      <td>4.350741</td>
      <td>3.628347</td>
      <td>3.427296</td>
      <td>3.201855</td>
      <td>6.701857</td>
      <td>2.431075</td>
      <td>2.328135</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>79.000000</td>
      <td>1.000000</td>
      <td>14.093084</td>
      <td>15.733782</td>
      <td>13.851155</td>
      <td>12.419112</td>
      <td>13.933560</td>
      <td>13.666401</td>
      <td>14.923120</td>
      <td>12.155206</td>
      <td>...</td>
      <td>3.175599</td>
      <td>4.492664</td>
      <td>4.073425</td>
      <td>4.472819</td>
      <td>3.795237</td>
      <td>3.607930</td>
      <td>3.369579</td>
      <td>6.929935</td>
      <td>3.115917</td>
      <td>2.483654</td>
    </tr>
    <tr>
      <th>max</th>
      <td>104.000000</td>
      <td>1.000000</td>
      <td>14.468678</td>
      <td>16.156867</td>
      <td>15.236153</td>
      <td>13.343259</td>
      <td>15.452533</td>
      <td>17.093881</td>
      <td>15.195933</td>
      <td>12.625845</td>
      <td>...</td>
      <td>3.885615</td>
      <td>4.687895</td>
      <td>4.259428</td>
      <td>4.789008</td>
      <td>4.249722</td>
      <td>4.078951</td>
      <td>3.838334</td>
      <td>7.527530</td>
      <td>4.158521</td>
      <td>3.101140</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 125 columns</p>
</div>




```python

#My student code
# Read the CSV file into a DataFrame with column 1 as index file
df = pd.read_csv('C:/Users/chl_b/BIOS6644_Spring_2024_OLD/Modules/students/Module_1/data/sugar_metabolomics.csv', index_col=0)

# now I want to get rid of the last row

df = df.iloc[:-1]

# Now export the modified DataFrame back to a CSV file
df.to_csv('C:/Users/chl_b/BIOS6644_Spring_2024_OLD/Modules/students/Module_1/data/sugar_metamolomics.csv')


```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Label</th>
      <th>Pyruvate</th>
      <th>MethylSuccinate</th>
      <th>Phosphoglyceric Acid</th>
      <th>Glucose 1-phosphate</th>
      <th>Malonic Acid</th>
      <th>Fumaric Acid</th>
      <th>Alpha-Ketoglutaric Acid</th>
      <th>Sarcosine</th>
      <th>Cadaverine</th>
      <th>...</th>
      <th>3-Hydroxybenzoic acid</th>
      <th>Succinate</th>
      <th>Glucose</th>
      <th>V127</th>
      <th>V128</th>
      <th>V129</th>
      <th>V130</th>
      <th>V131</th>
      <th>V132</th>
      <th>V133</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>0</td>
      <td>14.158545</td>
      <td>15.624522</td>
      <td>13.383600</td>
      <td>11.923638</td>
      <td>13.933560</td>
      <td>12.787696</td>
      <td>14.981440</td>
      <td>11.739484</td>
      <td>10.921776</td>
      <td>...</td>
      <td>3.161390</td>
      <td>2.165842</td>
      <td>8.310291624</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0</td>
      <td>14.180287</td>
      <td>15.325665</td>
      <td>13.468363</td>
      <td>12.046294</td>
      <td>13.043221</td>
      <td>12.536227</td>
      <td>14.593418</td>
      <td>11.833211</td>
      <td>11.121865</td>
      <td>...</td>
      <td>2.355910</td>
      <td>2.260621</td>
      <td>8.423733003</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0</td>
      <td>13.921329</td>
      <td>16.156867</td>
      <td>14.615061</td>
      <td>13.051929</td>
      <td>13.381985</td>
      <td>12.419600</td>
      <td>14.701978</td>
      <td>12.232070</td>
      <td>11.025333</td>
      <td>...</td>
      <td>2.472365</td>
      <td>2.295447</td>
      <td>8.357070943</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>52</th>
      <td>0</td>
      <td>13.785605</td>
      <td>15.939535</td>
      <td>13.206615</td>
      <td>12.342156</td>
      <td>12.448068</td>
      <td>12.211098</td>
      <td>14.860913</td>
      <td>11.949448</td>
      <td>11.015657</td>
      <td>...</td>
      <td>1.844567</td>
      <td>2.278589</td>
      <td>8.414503996</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>54</th>
      <td>0</td>
      <td>13.674234</td>
      <td>15.743668</td>
      <td>11.542008</td>
      <td>11.807872</td>
      <td>14.582068</td>
      <td>11.635154</td>
      <td>14.970451</td>
      <td>11.457569</td>
      <td>11.103239</td>
      <td>...</td>
      <td>3.773262</td>
      <td>2.136011</td>
      <td>8.193979575</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>99</th>
      <td>1</td>
      <td>13.881991</td>
      <td>15.634942</td>
      <td>12.687261</td>
      <td>11.649048</td>
      <td>12.839689</td>
      <td>12.596961</td>
      <td>14.787885</td>
      <td>11.974167</td>
      <td>11.090949</td>
      <td>...</td>
      <td>2.093669</td>
      <td>2.238217</td>
      <td>8.352756627</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>100</th>
      <td>1</td>
      <td>13.911391</td>
      <td>15.808535</td>
      <td>13.255651</td>
      <td>12.072060</td>
      <td>12.829308</td>
      <td>12.518926</td>
      <td>14.914205</td>
      <td>12.009783</td>
      <td>11.241416</td>
      <td>...</td>
      <td>2.099744</td>
      <td>2.460060</td>
      <td>8.268259167</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>101</th>
      <td>1</td>
      <td>14.004190</td>
      <td>15.578057</td>
      <td>15.050097</td>
      <td>12.955338</td>
      <td>12.021058</td>
      <td>12.698247</td>
      <td>14.838858</td>
      <td>11.864216</td>
      <td>11.361720</td>
      <td>...</td>
      <td>1.215855</td>
      <td>2.716850</td>
      <td>8.382160574</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>102</th>
      <td>1</td>
      <td>13.782098</td>
      <td>15.628488</td>
      <td>13.800509</td>
      <td>12.324283</td>
      <td>13.557521</td>
      <td>13.930284</td>
      <td>15.010427</td>
      <td>11.877001</td>
      <td>11.293042</td>
      <td>...</td>
      <td>2.567097</td>
      <td>2.339410</td>
      <td>8.362964723</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>103</th>
      <td>1</td>
      <td>13.841570</td>
      <td>15.697214</td>
      <td>14.467861</td>
      <td>12.549533</td>
      <td>13.157717</td>
      <td>14.309882</td>
      <td>14.518098</td>
      <td>12.173317</td>
      <td>11.058203</td>
      <td>...</td>
      <td>1.637428</td>
      <td>2.147184</td>
      <td>8.379107727</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>92 rows × 132 columns</p>
</div>




```python
# now I can check if this new modified csv does not contain the last row
assert df.shape == (92,132)
# I do not get any errors so I think it worked. I created a new csv modified to the df as I do not want to permanently change a datafile as we learned in calss
```


```python
##################################################################################################################
#
# YouDo:
# 
#    1) Get rid of any columns that have only NaN values
# https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.dropna.html
#
#######################################  BEGIN STUDENT CODE  #####################################################
# getting rid of any columns that have only NaN values
df = df.dropna(axis=1, how='all')



#######################################   END STUDENT CODE   #####################################################

assert df.shape == (92, 125)

# it looks like it worked because now I have only 125 columns and that is correct since columns V127-V133 had the NA values so 7 columns are gone now

df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Label</th>
      <th>Pyruvate</th>
      <th>MethylSuccinate</th>
      <th>Phosphoglyceric Acid</th>
      <th>Glucose 1-phosphate</th>
      <th>Malonic Acid</th>
      <th>Fumaric Acid</th>
      <th>Alpha-Ketoglutaric Acid</th>
      <th>Sarcosine</th>
      <th>Cadaverine</th>
      <th>...</th>
      <th>Histidine</th>
      <th>Phenylalanine</th>
      <th>Arginine</th>
      <th>Tyrosine</th>
      <th>Tryptophan</th>
      <th>Cystine</th>
      <th>lactate</th>
      <th>3-Hydroxybenzoic acid</th>
      <th>Succinate</th>
      <th>Glucose</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>0</td>
      <td>14.158545</td>
      <td>15.624522</td>
      <td>13.383600</td>
      <td>11.923638</td>
      <td>13.933560</td>
      <td>12.787696</td>
      <td>14.981440</td>
      <td>11.739484</td>
      <td>10.921776</td>
      <td>...</td>
      <td>4.439493</td>
      <td>3.934856</td>
      <td>4.362485</td>
      <td>3.125658</td>
      <td>3.344071</td>
      <td>3.223674</td>
      <td>7.391850</td>
      <td>3.161390</td>
      <td>2.165842</td>
      <td>8.310291624</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0</td>
      <td>14.180287</td>
      <td>15.325665</td>
      <td>13.468363</td>
      <td>12.046294</td>
      <td>13.043221</td>
      <td>12.536227</td>
      <td>14.593418</td>
      <td>11.833211</td>
      <td>11.121865</td>
      <td>...</td>
      <td>4.091856</td>
      <td>3.799364</td>
      <td>4.055512</td>
      <td>3.812430</td>
      <td>3.537357</td>
      <td>3.297459</td>
      <td>6.926229</td>
      <td>2.355910</td>
      <td>2.260621</td>
      <td>8.423733003</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0</td>
      <td>13.921329</td>
      <td>16.156867</td>
      <td>14.615061</td>
      <td>13.051929</td>
      <td>13.381985</td>
      <td>12.419600</td>
      <td>14.701978</td>
      <td>12.232070</td>
      <td>11.025333</td>
      <td>...</td>
      <td>4.647577</td>
      <td>4.217314</td>
      <td>4.789008</td>
      <td>3.910396</td>
      <td>4.078951</td>
      <td>3.158093</td>
      <td>7.132086</td>
      <td>2.472365</td>
      <td>2.295447</td>
      <td>8.357070943</td>
    </tr>
    <tr>
      <th>52</th>
      <td>0</td>
      <td>13.785605</td>
      <td>15.939535</td>
      <td>13.206615</td>
      <td>12.342156</td>
      <td>12.448068</td>
      <td>12.211098</td>
      <td>14.860913</td>
      <td>11.949448</td>
      <td>11.015657</td>
      <td>...</td>
      <td>4.531611</td>
      <td>4.166923</td>
      <td>4.573985</td>
      <td>3.953711</td>
      <td>3.698545</td>
      <td>2.442535</td>
      <td>6.605744</td>
      <td>1.844567</td>
      <td>2.278589</td>
      <td>8.414503996</td>
    </tr>
    <tr>
      <th>54</th>
      <td>0</td>
      <td>13.674234</td>
      <td>15.743668</td>
      <td>11.542008</td>
      <td>11.807872</td>
      <td>14.582068</td>
      <td>11.635154</td>
      <td>14.970451</td>
      <td>11.457569</td>
      <td>11.103239</td>
      <td>...</td>
      <td>4.551687</td>
      <td>3.767357</td>
      <td>4.449439</td>
      <td>3.553009</td>
      <td>3.434078</td>
      <td>2.675290</td>
      <td>6.318173</td>
      <td>3.773262</td>
      <td>2.136011</td>
      <td>8.193979575</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>99</th>
      <td>1</td>
      <td>13.881991</td>
      <td>15.634942</td>
      <td>12.687261</td>
      <td>11.649048</td>
      <td>12.839689</td>
      <td>12.596961</td>
      <td>14.787885</td>
      <td>11.974167</td>
      <td>11.090949</td>
      <td>...</td>
      <td>4.269239</td>
      <td>4.029189</td>
      <td>4.106445</td>
      <td>3.719126</td>
      <td>3.212139</td>
      <td>3.381057</td>
      <td>7.102711</td>
      <td>2.093669</td>
      <td>2.238217</td>
      <td>8.352756627</td>
    </tr>
    <tr>
      <th>100</th>
      <td>1</td>
      <td>13.911391</td>
      <td>15.808535</td>
      <td>13.255651</td>
      <td>12.072060</td>
      <td>12.829308</td>
      <td>12.518926</td>
      <td>14.914205</td>
      <td>12.009783</td>
      <td>11.241416</td>
      <td>...</td>
      <td>4.570584</td>
      <td>3.935102</td>
      <td>4.676844</td>
      <td>3.735049</td>
      <td>3.427296</td>
      <td>3.121327</td>
      <td>6.751464</td>
      <td>2.099744</td>
      <td>2.460060</td>
      <td>8.268259167</td>
    </tr>
    <tr>
      <th>101</th>
      <td>1</td>
      <td>14.004190</td>
      <td>15.578057</td>
      <td>15.050097</td>
      <td>12.955338</td>
      <td>12.021058</td>
      <td>12.698247</td>
      <td>14.838858</td>
      <td>11.864216</td>
      <td>11.361720</td>
      <td>...</td>
      <td>4.423799</td>
      <td>4.169760</td>
      <td>4.259914</td>
      <td>3.433266</td>
      <td>3.317550</td>
      <td>3.491284</td>
      <td>7.009974</td>
      <td>1.215855</td>
      <td>2.716850</td>
      <td>8.382160574</td>
    </tr>
    <tr>
      <th>102</th>
      <td>1</td>
      <td>13.782098</td>
      <td>15.628488</td>
      <td>13.800509</td>
      <td>12.324283</td>
      <td>13.557521</td>
      <td>13.930284</td>
      <td>15.010427</td>
      <td>11.877001</td>
      <td>11.293042</td>
      <td>...</td>
      <td>4.538909</td>
      <td>3.842126</td>
      <td>4.282809</td>
      <td>3.307526</td>
      <td>2.588503</td>
      <td>3.388397</td>
      <td>6.825325</td>
      <td>2.567097</td>
      <td>2.339410</td>
      <td>8.362964723</td>
    </tr>
    <tr>
      <th>103</th>
      <td>1</td>
      <td>13.841570</td>
      <td>15.697214</td>
      <td>14.467861</td>
      <td>12.549533</td>
      <td>13.157717</td>
      <td>14.309882</td>
      <td>14.518098</td>
      <td>12.173317</td>
      <td>11.058203</td>
      <td>...</td>
      <td>4.371212</td>
      <td>3.780527</td>
      <td>4.339276</td>
      <td>3.554490</td>
      <td>3.071197</td>
      <td>3.074653</td>
      <td>6.561956</td>
      <td>1.637428</td>
      <td>2.147184</td>
      <td>8.379107727</td>
    </tr>
  </tbody>
</table>
<p>92 rows × 125 columns</p>
</div>




```python
##################################################################################################################
#
# YouDo:
# 
#    1) Generate boxplots of Tryptophan levels separated based on 
#        the "Label" value
#
#      Use whatever plotting library you like.   
#      Hint 1: matplotlib has a boxplot tool
#          help(plt.boxplot)
#      Hint 2: pandas data frames have a built-in boxplot tool
#          help(df.boxplot)
#
#######################################  BEGIN STUDENT CODE  #####################################################
# label column is the third column;it looks like it is 1 or 0. I want to find out where Tryptophan is


Tryptophan_column_number = df.columns.get_loc('Tryptophan')
print("Column number of 'Tryptophan':", Tryptophan_column_number)

# now I need to generate the boxplots of Tryptophan levels separated on the"Label" value

import matplotlib.pyplot as plt


# Grouping the 'Tryptophan' values by the 'Label' values
grouped_data = df.groupby(df.iloc[:, 0])  # Group by 'Label' column

# Extracting the 'Tryptophan' column values for each group
data_to_plot = [grouped_data.get_group(label).iloc[:, 119] for label in grouped_data.groups]

# Creating a boxplot
plt.figure()
plt.boxplot(data_to_plot, labels=grouped_data.groups.keys())
plt.xlabel('Label')
plt.ylabel('Tryptophan Values')
plt.title('Boxplot of Tryptophan Values by Label')
plt.show()

#######################################   END STUDENT CODE   #####################################################

```

    Column number of 'Tryptophan': 119
    



<div style="display: inline-block;">
    <div class="jupyter-widgets widget-label" style="text-align: center;">
        Figure
    </div>
    <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAoAAAAHgCAYAAAA10dzkAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjguMCwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy81sbWrAAAACXBIWXMAAA9hAAAPYQGoP6dpAABIyUlEQVR4nO3deVxVdf7H8fdlBwXMHZUEIxUX3NBcxi1TMzMdx7HJ3LVyScqsJvWXaaWYlaVTodO4jqYloVNWpE25Ndq45lpaiWiCpiUgKgp8f3/04I43EDGQo/e8no/HfdT9nu/5ns+5oPft92wOY4wRAAAAbMPD6gIAAABQugiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAHHDW7hwoRwOh8urUqVK6tChg1avXm11eU5hYWEaPHjwNa937tw5TZ48WevWrSvxmpKSktS9e3eVL19eDodDjz/+eL4+kydPzvf5FvTq0KFDidd3JW+99ZYWLlxYKtvK2/9Tp06VyvYK8/XXX8vhcOiZZ565Yp9Dhw7J4XAoJiamyOPm7eONKCkpSQ6HQ6+88sp13c66devkcDgUHx9fIuOFhYXp3nvvLZGxLh/z9/wdAvweXlYXABTVggULVLduXRljlJqaqjfeeEM9evTQBx98oB49elhd3u927tw5TZkyRZJKPGSNHTtWX331lebPn6+qVasqJCQkX5/hw4fr7rvvdr5PSUlR7969NWbMGPXr18/ZHhQUVKK1Featt95SxYoVbfdl2KhRIzVr1kyLFy/W1KlT5enpma/PggULJEnDhg0r7fIAuBECIG4aDRo0UHR0tPP93XffrVtuuUXLli27qQPg9bR37161aNFCvXr1umKfGjVqqEaNGs73SUlJkqRbb71VLVu2vOJ6ly5dksPhkJcXf42UpGHDhmnUqFH65JNP8s0w5eTkaPHixWrWrJkaNWpkUYUA3AGHgHHT8vPzk4+Pj7y9vV3af/75Z40aNUrVq1eXj4+PatWqpYkTJyorK0uSdOHCBTVp0kQRERFKS0tzrpeamqqqVauqQ4cOysnJkSQNHjxYZcuW1b59+9SpUyeVKVNGlSpV0qOPPqpz585dtcbk5GT1799flStXlq+vryIjI/Xqq68qNzdX0q9hq1KlSpKkKVOmOA+3Xm3m62rj5h3u+u677/TJJ584x80Ld9cqb7x//vOfGjdunKpXry5fX19999138vLyUmxsbL51NmzYIIfDoRUrVkj632HInTt3qnfv3goKClJwcLD69++vn376ybleWFiY9u3bp/Xr1zvrDgsLK/K+532uDodDM2bM0NSpU3XrrbfKz89P0dHR+ve//13gPp44cUIPPPCAgoODVaVKFQ0dOtTl90OS3nzzTbVr106VK1dWmTJl1LBhQ82YMUOXLl1y6dehQwc1aNBAW7duVdu2bRUQEKBatWpp+vTpLnUWpF+/fvL393fO9F1uzZo1+vHHHzV06FBJ0rvvvqsuXbooJCRE/v7+ioyM1DPPPKPMzMxCtyFJDodDkydPztde0GHI1NRUPfLII6pRo4Z8fHwUHh6uKVOmKDs726VfXFycGjVqpLJlyyowMFB169bVhAkTrlqLJOXm5hb6s9q4caMcDoeWLVuWb93FixfL4XBo69atRdpWYaZMmaI77rhD5cuXV1BQkJo2bap58+bJGFNg/5UrVyoqKkp+fn6qVauWZs+ena9Penq6nnzySYWHh8vHx0fVq1fX448/XqSfE3DdGOAGt2DBAiPJbNmyxVy6dMlcvHjRHD161MTExBgPDw+TmJjo7Hv+/HkTFRVlypQpY1555RWzZs0a8+yzzxovLy9zzz33OPsdPHjQBAYGmt69extjjMnJyTF33nmnqVy5sjl+/Liz36BBg4yPj4+59dZbzdSpU82aNWvM5MmTjZeXl7n33ntd6qxZs6YZNGiQ8/3JkydN9erVTaVKlcycOXNMYmKiefTRR40kM3LkSGOMMRcuXDCJiYlGkhk2bJjZvHmz2bx5s/nuu++u+HkUZdy0tDSzefNmU7VqVdOmTRvnuBcuXLjq53348GEjybz88svOti+++MJIMtWrVzd9+vQxH3zwgVm9erU5ffq0+eMf/2huvfVWk52d7TLOn//8Z1OtWjVz6dIlY4wxzz33nJFkatasaZ566inz6aefmpkzZ5oyZcqYJk2amIsXLxpjjNmxY4epVauWadKkibPuHTt2FHnfL9+H0NBQ84c//MG8//77ZsWKFaZ58+bG29vb/Oc//3H2zaurTp06ZtKkSWbt2rVm5syZxtfX1wwZMsRln8aOHWvi4uJMYmKi+fzzz81rr71mKlasmK9f+/btTYUKFcztt99u5syZY9auXWtGjRplJJlFixZd9WfQv39/4+3tbU6ePJnvM/Xz8zO//PKLMcaYF154wbz22mvmo48+MuvWrTNz5swx4eHhpmPHji7r5e3j5SSZ5557Lt+2f/t7nJKSYkJDQ03NmjXN3LlzzWeffWZeeOEF4+vrawYPHuzst2zZMiPJjBkzxqxZs8Z89tlnZs6cOSYmJqbQfb2Wn1WTJk1MmzZt8o3RvHlz07x580K3k/c7vGLFikL7DR482MybN8+sXbvWrF271rzwwgvG39/fTJkyxaVfzZo1TfXq1c2tt95q5s+fbz7++GPz4IMP5vuzk5mZaRo3bmwqVqxoZs6caT777DMza9YsExwcbO68806Tm5vrMublnz1wPREAccPLC4C/ffn6+pq33nrLpe+cOXOMJPPee++5tL/00ktGklmzZo2z7d133zWSzOuvv24mTZpkPDw8XJYb82sAlGRmzZrl0j516lQjyWzatMnZ9tu/vJ955hkjyXz11Vcu644cOdI4HA7z7bffGmOM+emnn674ZVyQoo6bV1P37t2LNG6ewgJgu3bt8vXPW7Zy5Upn248//mi8vLxcvjTzQsjYsWNd1l+6dKmRZJYsWeJsq1+/vmnfvn2+bRV13/P2oVq1aub8+fPOfunp6aZ8+fLmrrvuylfXjBkzXMYcNWqU8fPzc/mCvlxOTo65dOmSWbx4sfH09DQ///yzc1n79u0LrLNevXqma9euBY53ubzPdObMmc6206dPG19fX/Pggw8WuE5ubq65dOmSWb9+vZFkvv7663z7eLmiBsBHHnnElC1b1hw5csSl3yuvvGIkmX379hljjHn00UdNuXLlrrpvv3UtP6u8vwt27tzpbPvvf/9bpGBd1AB4ubyf8fPPP28qVKiQL6w5HA6za9cul3U6d+5sgoKCTGZmpjHGmNjYWOPh4WG2bt3q0i8+Pt5IMh9//LHLmARAlBYOAeOmsXjxYm3dulVbt27VJ598okGDBmn06NF64403nH0+//xzlSlTRn369HFZN++Q1uWHlPr27auRI0fqqaee0osvvqgJEyaoc+fOBW77wQcfdHmfd3HEF198ccV6P//8c9WrV08tWrTIV4sxRp9//vnVd7oUxy2KP/3pT/naOnTooEaNGunNN990ts2ZM0cOh0MPP/xwvv6//Sz79u0rLy+vQj/LPNe6771795afn5/zfWBgoHr06KENGzY4D/Pnue+++1zeR0VF6cKFCzp58qSzbefOnbrvvvtUoUIFeXp6ytvbWwMHDlROTo4OHjzosn7VqlXz1RkVFaUjR45cdT/bt2+v2267zeUw8NKlS5WVleU8/CtJP/zwg/r166eqVas662nfvr0k6cCBA1fdTlGsXr1aHTt2VLVq1ZSdne18devWTZK0fv16SVKLFi105swZPfDAA/rXv/51zVdVF+Vn9cADD6hy5couv2t/+9vfVKlSJd1///3F3VVJv/6O3XXXXQoODnZ+ppMmTdLp06ddfhckqX79+vnOxezXr5/S09O1Y8cOSb9+fg0aNFDjxo1dPr+uXbvK4XBcl6v/gaIgAOKmERkZqejoaEVHR+vuu+/W3Llz1aVLFz399NM6c+aMJOn06dOqWrVqvlteVK5cWV5eXjp9+rRL+9ChQ3Xp0iV5eXld8bYaXl5eqlChgktb1apVndu7ktOnTxd41W21atWuum5hrte4RVHQdiUpJiZG//73v/Xtt9/q0qVLevvtt9WnTx/n53S537blfb5Fqfta9/1K27948aLOnj3r0v7bn7Gvr68k6fz585J+Pfewbdu2+vHHHzVr1ixt3LhRW7dudYaRvH5XGi9vzN/2K4jD4dDQoUO1Z88ebdu2TdKvV/+Gh4erY8eOkqSzZ8+qbdu2+uqrr/Tiiy9q3bp12rp1qxISEgqs5/c6ceKEPvzwQ3l7e7u86tevL0nOoDdgwADNnz9fR44c0Z/+9CdVrlxZd9xxh9auXVuk7RTlZ+Xr66tHHnlE77zzjs6cOaOffvpJ7733noYPH+78eRXHf//7X3Xp0kWS9Pbbb+vLL7/U1q1bNXHiREn5P9PCfr/zfhdPnDih3bt35/v8AgMDZYy5IW4/BHvi8j3c1KKiovTpp5/q4MGDatGihSpUqKCvvvpKxhiXEHjy5EllZ2erYsWKzrbMzEwNGDBAtWvX1okTJzR8+HD961//yreN7OxsnT592uULPTU1VVLBX/J5KlSooJSUlHztx48flySXWq7F9Rq3KK50L7l+/frpr3/9q9588021bNlSqampGj16dIF9U1NTVb16def7gj7fK7nWfc/7Of22zcfHR2XLlr3q9i63atUqZWZmKiEhQTVr1nS279q165rGKarBgwdr0qRJmj9/vry9vbVz50698MILzp/B559/ruPHj2vdunXOWT9Jzn8MXY2vr6/zwqjL/TZEV6xYUVFRUZo6dWqB4+SFb0kaMmSIhgwZoszMTG3YsEHPPfec7r33Xh08eNDlMytIUX9WI0eO1PTp0zV//nxduHBB2dnZGjFiRKFjF9Xy5cvl7e2t1atXu8xGrlq16ppqlv73d0PFihXl7++v+fPnFzjG9fzzChSGGUDc1PK+fPOupO3UqZPOnj2b7y/sxYsXO5fnGTFihJKTk5WQkKB58+bpgw8+0GuvvVbgdpYuXery/p133pFU+H37OnXqpP379zsPBV1ei8PhcM7k/Ham6WqKOm5p8vPz08MPP6xFixZp5syZaty4sdq0aVNg399+lu+9956ys7NdPssrzZRd674nJCTowoULzvcZGRn68MMP1bZt2wLvsVeYvOB1+UyTMUZvv/32NY1TVNWqVdPdd9+tZcuW6c0335SHh4cGDRpUaD2SNHfu3CKNHxYWpt27d7u0ff755/lmRu+9917t3btXt912m3MG/vLX5QEwT5kyZdStWzdNnDhRFy9e1L59+65aT1F/ViEhIfrzn/+st956S3PmzFGPHj106623FmmfrybvtkaXb+/8+fP65z//WWD/ffv26euvv3Zpe+eddxQYGKimTZtK+vXz+/7771WhQoUCP7/Lr3AHShMzgLhp7N2713nbidOnTyshIUFr167VH//4R4WHh0uSBg4cqDfffFODBg1SUlKSGjZsqE2bNmnatGm65557dNddd0mS/vGPf2jJkiVasGCB6tevr/r16+vRRx/VX//6V7Vp08bl3C0fHx+9+uqrOnv2rJo3b67//Oc/evHFF9WtWzf94Q9/uGK9Y8eO1eLFi9W9e3c9//zzqlmzpj766CO99dZbGjlypGrXri3p13OdatasqX/961/q1KmTypcvr4oVK17xi6Go45a2UaNGacaMGdq+fbv+8Y9/XLFfQkKCvLy81LlzZ+3bt0/PPvusGjVqpL59+zr7NGzYUMuXL9e7776rWrVqyc/PTw0bNrzmfff09FTnzp31xBNPKDc3Vy+99JLS09OdN96+Fp07d5aPj48eeOABPf3007pw4YLi4uL0yy+/XPNYRTVs2DB99NFH+sc//qGuXbsqNDTUuax169a65ZZbNGLECD333HPy9vbW0qVL8wWSKxkwYICeffZZTZo0Se3bt9f+/fv1xhtvKDg42KXf888/r7Vr16p169aKiYlRnTp1dOHCBSUlJenjjz/WnDlzVKNGDT300EPy9/dXmzZtFBISotTUVMXGxio4OFjNmze/aj3X8rN67LHHdMcdd0hSgbfLKcyWLVsKbG/fvr26d++umTNnql+/fnr44Yd1+vRpvfLKK1c8vFytWjXdd999mjx5skJCQrRkyRKtXbtWL730kgICAiRJjz/+uN5//321a9dOY8eOVVRUlHJzc5WcnKw1a9Zo3Lhxzn0BSpWVV6AARVHQVcDBwcGmcePGZubMmflubXL69GkzYsQIExISYry8vEzNmjXN+PHjnf12795t/P39811td+HCBdOsWTMTFhbmvM3GoEGDTJkyZczu3btNhw4djL+/vylfvrwZOXKkOXv2rMv6BV3Bd+TIEdOvXz9ToUIF4+3tberUqWNefvllk5OT49Lvs88+M02aNDG+vr5G0lWvBCzquCV9FfDVrqDs0KGDKV++vDl37ly+ZXlXom7fvt306NHDlC1b1gQGBpoHHnjAnDhxwqVvUlKS6dKliwkMDHTeOuZa9j1vH1566SUzZcoUU6NGDePj42OaNGliPv300wLr+umnn1za837vDh8+7Gz78MMPTaNGjYyfn5+pXr26eeqpp8wnn3xiJJkvvvjC2a99+/amfv36+T6DQYMGuezL1Vy8eNFUqVKlwCvbjTHmP//5j2nVqpUJCAgwlSpVMsOHDzc7duwwksyCBQvy7ePlsrKyzNNPP21CQ0ONv7+/ad++vdm1a1eBv8c//fSTiYmJMeHh4cbb29uUL1/eNGvWzEycONH552DRokWmY8eOpkqVKsbHx8dUq1bN9O3b1+zevbvQfbyWn9XlwsLCTGRk5FU+wf/J+x2+0ivv5zd//nxTp04d4+vra2rVqmViY2PNvHnz8v0u5P3Zio+PN/Xr1zc+Pj4mLCzM5crtPGfPnjX/93//Z+rUqWN8fHxMcHCwadiwoRk7dqxJTU11GZOrgFFaHMZc4e6WADR48GDFx8fnOyyG/E6ePKmaNWtqzJgxmjFjRr7lkydP1pQpU/TTTz9d9/OekpKSFB4erpdffllPPvnkdd0WSt/u3budV56PGjXK6nKAmxKHgAEUy7Fjx/TDDz/o5ZdfloeHhx577DGrS4Kb+v7773XkyBFNmDBBISEhtntWNFCSuAgEQLH84x//UIcOHbRv3z4tXbrU5QpfoCS98MIL6ty5s86ePasVK1Y4z7MDcO04BAwAAGAzzAACAADYDAEQAADAZgiAAAAANkMABAAAsBluA1MMubm5On78uAIDA6/4jFQAAHBjMcYoIyND1apVk4eHPefCCIDFcPz4cZdHMwEAgJvH0aNHVaNGDavLsAQBsBgCAwMl/foLFBQUZHE1AACgKNLT0xUaGur8HrcjAmAx5B32DQoKIgACAHCTsfPpW/Y88A0AAGBjBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGG0EDRZCTk6ONGzcqJSVFISEhatu2rTw9Pa0uCwCA34UZQOAqEhISFBERoY4dO6pfv37q2LGjIiIilJCQYHVpAAD8LgRAoBAJCQnq06ePGjZsqM2bNysjI0ObN29Ww4YN1adPH0IgAOCm5DDGGKuLuFmlp6crODhYaWlpPAvYDeXk5CgiIkINGzbUqlWr5OHxv38v5ebmqlevXtq7d68OHTrE4WAAuInw/c0MIHBFGzduVFJSkiZMmOAS/iTJw8ND48eP1+HDh7Vx40aLKgQA4PchAAJXkJKSIklq0KBBgcvz2vP6AQBwsyAAAlcQEhIiSdq7d2+By/Pa8/oBAHCzIAACV9C2bVuFhYVp2rRpys3NdVmWm5ur2NhYhYeHq23bthZVCADA70MABK7A09NTr776qlavXq1evXq5XAXcq1cvrV69Wq+88goXgAAAbjrcCBooRO/evRUfH69x48apdevWzvbw8HDFx8erd+/eFlYHAMDvw21gioHLyO2DJ4EAgPvg+5sZQKBIPD091aFDB6vLAACgRHAOIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANuOWATA2NlYOh0OPP/54of3Wr1+vZs2ayc/PT7Vq1dKcOXNKp0AAAAALuV0A3Lp1q/7+978rKiqq0H6HDx/WPffco7Zt22rnzp2aMGGCYmJi9P7775dSpQAAANZwqwB49uxZPfjgg3r77bd1yy23FNp3zpw5uvXWW/X6668rMjJSw4cP19ChQ/XKK6+UUrUAAADWcKsAOHr0aHXv3l133XXXVftu3rxZXbp0cWnr2rWrtm3bpkuXLhW4TlZWltLT011eAAAANxu3CYDLly/Xjh07FBsbW6T+qampqlKliktblSpVlJ2drVOnThW4TmxsrIKDg52v0NDQYtcNAABQ2twiAB49elSPPfaYlixZIj8/vyKv53A4XN4bYwpszzN+/HilpaU5X0ePHv39RQMAAFjEy+oCSsL27dt18uRJNWvWzNmWk5OjDRs26I033lBWVpY8PT1d1qlatapSU1Nd2k6ePCkvLy9VqFChwO34+vrK19e35HcAAACgFLlFAOzUqZP27Nnj0jZkyBDVrVtXf/3rX/OFP0lq1aqVPvzwQ5e2NWvWKDo6Wt7e3te1XgAAACu5RQAMDAxUgwYNXNrKlCmjChUqONvHjx+vH3/8UYsXL5YkjRgxQm+88YaeeOIJPfTQQ9q8ebPmzZunZcuWlXr9AAAApcktzgEsipSUFCUnJzvfh4eH6+OPP9a6devUuHFjvfDCC5o9e7b+9Kc/WVglAADA9ecweVc+4Jqlp6crODhYaWlpCgoKsrocAABQBHx/22gGEAAAAL8iAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGQIgAACAzRAAAQAAbIYACAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGQIgAACAzRAAAQAAbMbL6gIAALBSTk6ONm7cqJSUFIWEhKht27by9PS0uizgumIGEABgWwkJCYqIiFDHjh3Vr18/dezYUREREUpISLC6NOC6YgYQkHTu3Dl98803hfY5f/68kpKSFBYWJn9//0L71q1bVwEBASVZIoASlpCQoD59+ujee+/VsmXL1KBBA+3du1fTpk1Tnz59FB8fr969e1tdJnBdOIwxxuoiblbp6ekKDg5WWlqagoKCrC4HxbBjxw41a9asxMbbvn27mjZtWmLjAShZOTk5ioiIUMOGDbVq1Sp5ePzvgFhubq569eqlvXv36tChQxwOdkN8fzMDCEj6dcZu+/bthfY5cOCA+vfvryVLligyMvKq4wG4cW3cuFFJSUlatmyZS/iTJA8PD40fP16tW7fWxo0b1aFDB2uKBK4jAiAgKSAgoMgzdpGRkczuATe5lJQUSVKDBg0KXJ7XntcPcDdcBAIAsJ2QkBBJ0t69ewtcntee1w9wNwRAAIDttG3bVmFhYZo2bZpyc3NdluXm5io2Nlbh4eFq27atRRUC1xcBEABgO56ennr11Ve1evVq9erVS5s3b1ZGRoY2b96sXr16afXq1XrllVe4AARui3MAAQC21Lt3b8XHx2vcuHFq3bq1sz08PJxbwMDtEQABALbVu3dv9ezZkyeBwHYIgAAAt1aUG717e3srNzdX3t7e+vrrrwvty43e4Q4IgAAAt/bNN99wo3fgNwiAAAC3xo3egfwIgAAAt8aN3oH8uA0MAACAzRAAAQAAbIYACAAAYDMEQAAAAJtxiwAYFxenqKgoBQUFKSgoSK1atdInn3xS6DpLly5Vo0aNFBAQoJCQEA0ZMkSnT58upYoBAACs4xYBsEaNGpo+fbq2bdumbdu26c4771TPnj21b9++Avtv2rRJAwcO1LBhw7Rv3z6tWLFCW7du1fDhw0u5cgAAgNLnFreB6dGjh8v7qVOnKi4uTlu2bFH9+vXz9d+yZYvCwsIUExMj6dfnPj7yyCOaMWNGqdQLAABgJbeYAbxcTk6Oli9frszMTLVq1arAPq1bt9axY8f08ccfyxijEydOKD4+Xt27dy907KysLKWnp7u8AAAAbjZuEwD37NmjsmXLytfXVyNGjNDKlStVr169Avu2bt1aS5cu1f333y8fHx9VrVpV5cqV09/+9rdCtxEbG6vg4GDnKzQ09HrsCgAAwHXlNgGwTp062rVrl7Zs2aKRI0dq0KBB2r9/f4F99+/fr5iYGE2aNEnbt29XYmKiDh8+rBEjRhS6jfHjxystLc35Onr06PXYFQAAgOvKLc4BlCQfHx9FRERIkqKjo7V161bNmjVLc+fOzdc3NjZWbdq00VNPPSVJioqKUpkyZdS2bVu9+OKLCgkJKXAbvr6+8vX1vX47AQAAUArcZgbwt4wxysrKKnDZuXPn5OHhuuuenp7O9QAAANyZW8wATpgwQd26dVNoaKgyMjK0fPlyrVu3TomJiZJ+PXT7448/avHixZJ+vWr4oYceUlxcnLp27aqUlBQ9/vjjatGihapVq2blrgAAAFx3bhEAT5w4oQEDBiglJUXBwcGKiopSYmKiOnfuLElKSUlRcnKys//gwYOVkZGhN954Q+PGjVO5cuV055136qWXXrJqFwAAAEqNWwTAefPmFbp84cKF+drGjBmjMWPGXKeKAAAAblxuew4gAAAACkYABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkvqwsArrdDhw4pIyOj2OMcOHDA5b/FFRgYqNtvv71ExgIA4FoQAOHWDh06pNq1a5fomP379y+xsQ4ePEgIBACUOgIg3FrezN+SJUsUGRlZrLHOnz+vpKQkhYWFyd/fv1hjHThwQP379y+RmUkAAK4VARC2EBkZqaZNmxZ7nDZt2pRANQAAWIuLQAAAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYjFsEwLi4OEVFRSkoKEhBQUFq1aqVPvnkk0LXycrK0sSJE1WzZk35+vrqtttu0/z580upYgAAAOt4Wbnx8+fPyxijgIAASdKRI0e0cuVK1atXT126dCnyODVq1ND06dMVEREhSVq0aJF69uypnTt3qn79+gWu07dvX504cULz5s1TRESETp48qezs7OLvFAAAwA3O0gDYs2dP9e7dWyNGjNCZM2d0xx13yNvbW6dOndLMmTM1cuTIIo3To0cPl/dTp05VXFyctmzZUmAATExM1Pr16/XDDz+ofPnykqSwsLBi7w8AAMDNwNJDwDt27FDbtm0lSfHx8apSpYqOHDmixYsXa/bs2b9rzJycHC1fvlyZmZlq1apVgX0++OADRUdHa8aMGapevbpq166tJ598UufPny907KysLKWnp7u8AAAAbjaWzgCeO3dOgYGBkqQ1a9aod+/e8vDwUMuWLXXkyJFrGmvPnj1q1aqVLly4oLJlyzoPJRfkhx9+0KZNm+Tn56eVK1fq1KlTGjVqlH7++edCzwOMjY3VlClTrqkuAACAG42lM4ARERFatWqVjh49qk8//dR53t/JkycVFBR0TWPVqVNHu3bt0pYtWzRy5EgNGjRI+/fvL7Bvbm6uHA6Hli5dqhYtWuiee+7RzJkztXDhwkJnAcePH6+0tDTn6+jRo9dUIwAAwI3A0hnASZMmqV+/fho7dqzuvPNO5yHbNWvWqEmTJtc0lo+Pj/MikOjoaG3dulWzZs3S3Llz8/UNCQlR9erVFRwc7GyLjIyUMUbHjh3T7bffXuA2fH195evre011wXpVyzrkf+agdPzGuejd/8xBVS3rsLoMAIBNWRoA+/Tpoz/84Q9KSUlRo0aNnO2dOnXSH//4x2KNbYxRVlZWgcvatGmjFStW6OzZsypbtqwk6eDBg/Lw8FCNGjWKtV3ceB5p5qPIDY9IG6yu5H8i9WtdAABYwdIAKElVq1bV2bNntXbtWrVr107+/v5q3ry5HI6iz45MmDBB3bp1U2hoqDIyMrR8+XKtW7dOiYmJkn49dPvjjz9q8eLFkqR+/frphRde0JAhQzRlyhSdOnVKTz31lIYOHSp/f//rsp+wztztF3X/pIWKrFvX6lKcDnzzjea+2k/3WV0IAMCWLA2Ap0+fVt++ffXFF1/I4XDo0KFDqlWrloYPH65y5crp1VdfLdI4J06c0IABA5SSkqLg4GBFRUUpMTFRnTt3liSlpKQoOTnZ2b9s2bJau3atxowZo+joaFWoUEF9+/bViy++eF32E9ZKPWt0vlxtqVpjq0txOp+aq9SzxuoyAAA2ZWkAHDt2rLy9vZWcnKzIyEhn+/3336+xY8cWOQDOmzev0OULFy7M11a3bl2tXbv2muoFAABwB5YGwDVr1ujTTz/Nd97d7bfffs23gQEAAEDRWHpZZGZmpvMxcJc7deoUV9sCAABcJ5YGwHbt2jkvzJAkh8Oh3Nxcvfzyy+rYsaOFlQEAALgvSw8Bv/zyy+rQoYO2bdumixcv6umnn9a+ffv0888/68svv7SyNAAAALdl6QxgvXr1tHv3brVo0UKdO3dWZmamevfurZ07d+q2226zsjQAAAC3dUPcB5Dn6wIAAJQeSwPghg2FP5qhXbt2pVQJAACAfVgaADt06JCv7fIngOTk5JRiNQAAAPZg6TmAv/zyi8vr5MmTSkxMVPPmzbVmzRorSwMAAHBbls4ABgcH52vr3LmzfH19NXbsWG3fvt2CqgAAANybpTOAV1KpUiV9++23VpcBAADgliydAdy9e7fLe2OMUlJSNH36dDVq1MiiqgAAANybpQGwcePGcjgcMsa4tLds2VLz58+3qCoAAAD3ZmkAPHz4sMt7Dw8PVapUSX5+fhZVBAAA4P4sDYA1a9a0cvMAAAC2VOoBcPbs2UXuGxMTcx0rAQAAsKdSD4CvvfZakfo5HA4CIAAAwHVQ6gHwt+f9AQAAoHRZeg4gAADFcejQIWVkZBR7nAMHDrj8t7gCAwN1++23l8hYwPVgeQA8duyYPvjgAyUnJ+vixYsuy2bOnGlRVQCAG92hQ4dUu3btEh2zf//+JTbWwYMHCYG4YVkaAP/973/rvvvuU3h4uL799ls1aNBASUlJMsaoadOmVpYGALjB5c38LVmyRJGRkcUa6/z580pKSlJYWJj8/f2LNdaBAwfUv3//EpmZBK4XSwPg+PHjNW7cOD3//PMKDAzU+++/r8qVK+vBBx/U3XffbWVpAICbRGRkZIlMGrRp06YEqgFuDpY+C/jAgQMaNGiQJMnLy0vnz59X2bJl9fzzz+ull16ysjQAAAC3ZWkALFOmjLKysiRJ1apV0/fff+9cdurUKavKAgAAcGuWHgJu2bKlvvzyS9WrV0/du3fXuHHjtGfPHiUkJKhly5ZWlgYAAOC2LAmAP/30kypVqqSZM2fq7NmzkqTJkyfr7NmzevfddxUREVHkG0YDAADg2lgSAKtXr6777rtPw4YNc17sERAQoLfeesuKcgAAAGzFknMAFy1apPT0dPXo0UOhoaF69tlnXc7/AwAAwPVjSQB84IEHtGbNGh0+fFgPPfSQli5dqtq1a6tjx45aunSpLly4YEVZAAAAtmDpVcChoaF67rnn9MMPP2jNmjWqXr26Hn74YYWEhGjUqFFWlgYAAOC2LH8UXJ5OnTqpU6dOev/99/Xwww9r7ty5nBOIYjt37pwkaceOHcUeq6SfFAAAgFVuiACYlJSkBQsWaNGiRTp27Jg6duyoYcOGWV0W3MA333wjSXrooYcsrqRggYGBVpcAALAhywLghQsXtGLFCi1YsEAbNmxQ9erVNXjwYA0ZMkRhYWFWlQU306tXL0lS3bp1FRAQUKyx8p7vWRLPHZV+DX88KB4AYAVLAuDDDz+s9957TxcuXFDPnj310UcfqUuXLnI4HFaUAzdWsWJFDR8+vETHLKnnjgIAYBVLLgLZsmWLpkyZouPHj+vdd99V165dixX+4uLiFBUVpaCgIAUFBalVq1b65JNPirTul19+KS8vLzVu3Ph3bx8AAOBmYskM4O7du0t0vBo1amj69OmKiIiQ9Ot9Bnv27KmdO3eqfv36V1wvLS1NAwcOVKdOnXTixIkSrQkAAOBGZeltYEpKjx49dM8996h27dqqXbu2pk6dqrJly2rLli2FrvfII4+oX79+atWqVSlVCgAAYD23CICXy8nJ0fLly5WZmVlosFuwYIG+//57Pffcc0UeOysrS+np6S4vAACAm80NcRuYkrBnzx61atVKFy5cUNmyZbVy5UrVq1evwL6HDh3SM888o40bN8rLq+gfQWxsrKZMmVJSJQMAAFjCbWYA69Spo127dmnLli0aOXKkBg0apP379+frl5OTo379+mnKlCmqXbv2NW1j/PjxSktLc76OHj1aUuUDAACUGstnAM+cOaP//ve/OnnypHJzc12WDRw4sMjj+Pj4OC8CiY6O1tatWzVr1izNnTvXpV9GRoa2bdumnTt36tFHH5Uk5ebmyhgjLy8vrVmzRnfeeWeB2/D19ZWvr++17B4AAMANx9IA+OGHH+rBBx9UZmamAgMDXW4F43A4rikA/pYxRllZWfnag4KCtGfPHpe2t956S59//rni4+MVHh7+u7cJAABwM7A0AI4bN05Dhw7VtGnTivWUhgkTJqhbt24KDQ1VRkaGli9frnXr1ikxMVHSr4duf/zxRy1evFgeHh5q0KCBy/qVK1eWn59fvnYAAAB3ZGkA/PHHHxUTE1PsR3SdOHFCAwYMUEpKioKDgxUVFaXExER17txZkpSSkqLk5OSSKBkAAOCmZ2kA7Nq1q7Zt26ZatWoVa5x58+YVunzhwoWFLp88ebImT55crBoAAABuFpYGwO7du+upp57S/v371bBhQ3l7e7ssv++++yyqDAAAwH1ZGgAfeughSdLzzz+fb5nD4VBOTk5plwQAAOD2LA2Av73tCwAAAK4/y+8DCADA71W1rEP+Zw5Kx2+c5xr4nzmoqmUdV+8IWMjyAJiZman169crOTlZFy9edFkWExNjUVUAgJvBI818FLnhEWmD1ZX8T6R+rQu4kVkaAHfu3Kl77rlH586dU2ZmpsqXL69Tp04pICBAlStXJgACAAo1d/tF3T9poSLr1rW6FKcD33yjua/2E5cx4kZmaQAcO3asevToobi4OJUrV05btmyRt7e3+vfvr8cee8zK0gAAN4HUs0bny9WWqjW2uhSn86m5Sj1rrC4DKJSlJ03s2rVL48aNk6enpzw9PZWVlaXQ0FDNmDFDEyZMsLI0AAAAt2VpAPT29nY+/7dKlSrOp3UEBwfz5A4AAIDrxNJDwE2aNNG2bdtUu3ZtdezYUZMmTdKpU6f0z3/+Uw0bNrSyNAAAALdl6QzgtGnTFBISIkl64YUXVKFCBY0cOVInT57U3//+dytLAwAAcFuWzgBGR0c7/79SpUr6+OOPLawGAADAHm6cO2cCAACgVFgaAE+cOKEBAwaoWrVq8vLycl4NnPcCAABAybP0EPDgwYOVnJysZ599ViEhIc4rggEAAHD9WBoAN23apI0bN6px48ZWlgEAAGArlh4CDg0NlTHcLR0AAKA0WRoAX3/9dT3zzDNKSkqysgwAAABbKfVDwLfccovLuX6ZmZm67bbbFBAQIG9vb5e+P//8c2mXBwAA4PZKPQC+/vrrpb1JAAAAXKbUA+CgQYNKe5MAAAC4jKVXAUtSTk6OVq5cqQMHDsjhcCgyMlI9e/aUl5flpQEAALglS1PW3r171bNnT6WmpqpOnTqSpIMHD6pSpUr64IMP1LBhQyvLAwAAcEuWXgU8fPhw1a9fX8eOHdOOHTu0Y8cOHT16VFFRUXr44YetLA0AAMBtWToD+PXXX2vbtm265ZZbnG233HKLpk6dqubNm1tYGQAAgPuydAawTp06OnHiRL72kydPKiIiwoKKAAAA3J+lAXDatGmKiYlRfHy8jh07pmPHjik+Pl6PP/64XnrpJaWnpztfAAAAKBmWHgK+9957JUl9+/Z13hw679FwPXr0cL53OBzKycmxpkgAAAA3Y2kA/OKLL6zcPAAAgC1ZGgDbt29v5eYBAABsyfK7LZ85c0bz5s1z3gi6Xr16Gjp0qIKDg60uDQAAwC1ZGgC3bdumrl27yt/fXy1atJAxRjNnztTUqVO1Zs0aNW3a1MryAAA3sHPnzkmSduzYUeyxzp8/r6SkJIWFhcnf379YYx04cKDY9QDXm6UBcOzYsbrvvvv09ttvOx/9lp2dreHDh+vxxx/Xhg0brCwPNnLu3Dl98803hfbJ+0u9KH+5161bVwEBASVSG4CC5f2ZfeihhyyupGCBgYFWlwBckcPkXXZrAX9/f+3cuVN169Z1ad+/f7+io6Od/7q7UaWnpys4OFhpaWkKCgqyuhwUw44dO9SsWbMSG2/79u3MYAPX2alTp7Rq1aoS+QfXgQMH1L9/fy1ZskSRkZHFri0wMFC33357scfB9cH3t8UzgEFBQUpOTs4XAI8ePXpN/3KKi4tTXFyckpKSJEn169fXpEmT1K1btwL7JyQkKC4uTrt27VJWVpbq16+vyZMnq2vXrr97X3Bzq1u3rrZv315on2s5RPTb32kAJa9ixYoaPnx4iY4ZGRnJP95gC5YGwPvvv1/Dhg3TK6+8otatW8vhcGjTpk166qmn9MADDxR5nBo1amj69OnOp4csWrRIPXv21M6dO1W/fv18/Tds2KDOnTtr2rRpKleunBYsWKAePXroq6++UpMmTUps/3DzCAgIKNJf+m3atCmFagAAuL4sPQR88eJFPfXUU5ozZ46ys7MlSd7e3ho5cqSmT58uX1/f3z12+fLl9fLLL2vYsGFF6l+/fn3df//9mjRpUpG3wRQyALiHvNNAOH3DHvj+tngG0MfHR7NmzVJsbKy+//57GWMUERFRrHM5cnJytGLFCmVmZqpVq1ZFWic3N1cZGRkqX778794uAADAzcLSZwEPHTpUGRkZCggIUMOGDRUVFaWAgABlZmZq6NCh1zTWnj17VLZsWfn6+mrEiBFauXKl6tWrV6R1X331VWVmZqpv376F9svKynJ5PjHPKAYAADcjSwPgokWLdP78+Xzt58+f1+LFi69prDp16mjXrl3asmWLRo4cqUGDBmn//v1XXW/ZsmWaPHmy3n33XVWuXLnQvrGxsQoODna+QkNDr6lGAACAG4ElATA9PV1paWkyxigjI8NlRu2XX37Rxx9/fNUw9ls+Pj6KiIhQdHS0YmNj1ahRI82aNavQdd59910NGzZM7733nu66666rbmP8+PFKS0tzvo4ePXpNNQIAANwILDkHsFy5cnI4HHI4HKpdu3a+5Q6HQ1OmTCnWNowxysrKuuLyZcuWaejQoVq2bJm6d+9epDF9fX2LdWEKAADAjcCSAPjFF1/IGKM777xT77//vsvFFz4+PqpZs6aqVatW5PEmTJigbt26KTQ0VBkZGVq+fLnWrVunxMRESb/O3P3444/Ow8rLli3TwIEDNWvWLLVs2VKpqamSfr0xNc8gBgAA7s6SANi+fXtJ0uHDhxUaGioPj+IdiT5x4oQGDBiglJQUBQcHKyoqSomJiercubMkKSUlRcnJyc7+c+fOVXZ2tkaPHq3Ro0c72wcNGqSFCxcWqxYAAIAbnaW3galZs6Z++eUXzZs3TwcOHJDD4VBkZKSGDBlyTbdkmTdvXqHLfxvq1q1b9zuqBQAAcA+WXgW8fv16hYWFafbs2frll1/0888/a/bs2QoPD9f69eutLA0AAMBtWToDOHr0aN1///2Ki4uTp6enpF9v5Dxq1CiNHj1ae/futbI8AAAAt2TpDOD333+vcePGOcOfJHl6euqJJ57Q999/b2FlAAAA7svSANi0aVMdOHAgX/uBAwfUuHHj0i8IAADABiw9BBwTE6PHHntM3333nVq2bClJ2rJli958801Nnz5du3fvdvaNioqyqkwAAAC3YmkAfOCBByRJTz/9dIHLHA6HjDFyOBzKyckp7fIAAADckqUB8PDhw1ZuHgAAwJYsDYAVK1ZUmTJlrCwBAADAdiy9CKRKlSoaOnSoNm3aZGUZAAAAtmJpAFy2bJnS0tLUqVMn1a5dW9OnT9fx48etLAkAAMDtWRoAe/Tooffff1/Hjx/XyJEjtWzZMtWsWVP33nuvEhISlJ2dbWV5AAAAbsnSAJinQoUKGjt2rL7++mvNnDlTn332mfr06aNq1app0qRJOnfunNUlAgAAuA1LLwLJk5qaqsWLF2vBggVKTk5Wnz59NGzYMB0/flzTp0/Xli1btGbNGqvLBAAAcAuWBsCEhAQtWLBAn376qerVq6fRo0erf//+KleunLNP48aN1aRJE+uKBAAAcDOWBsAhQ4bogQce0JdffqnmzZsX2KdWrVqaOHFiKVcGAADgviwLgNnZ2YqNjVXv3r1VtWrVK/bz9/fXc889V4qVAQAAuDfLLgLx8vLSk08+qaysLKtKAAAAsCVLrwK+4447tHPnTitLAAAAsB1LzwEcNWqUxo0bp2PHjqlZs2b5HgsXFRVlUWUAAADuy5IAOHToUL3++uu6//77JUkxMTHOZQ6HQ8YYORwO5eTkWFEeAACAW7MkAC5atEjTp0/X4cOHrdg8AACArVkSAI0xkqSaNWtasXkAAABbs+wiEIfDYdWmAQAAbM2yi0Bq16591RD4888/l1I1AAAA9mFZAJwyZYqCg4Ot2jwAAIBtWRYA//KXv6hy5cpWbR4AAMC2LDkHkPP/AAAArGNJAMy7ChgAAAClz5JDwLm5uVZsFgAAALL4WcAAAAAofQRAAAAAmyEAAgAA2AwBEAAAwGYIgAAAADbjFgEwLi5OUVFRCgoKUlBQkFq1aqVPPvmk0HXWr1+vZs2ayc/PT7Vq1dKcOXNKqVoAAABruUUArFGjhqZPn65t27Zp27ZtuvPOO9WzZ0/t27evwP6HDx/WPffco7Zt22rnzp2aMGGCYmJi9P7775dy5QAAAKXPskfBlaQePXq4vJ86dari4uK0ZcsW1a9fP1//OXPm6NZbb9Xrr78uSYqMjNS2bdv0yiuv6E9/+lNplAwAKCXnzp3TN998U2ifAwcOuPy3MHXr1lVAQECJ1AZYxS0C4OVycnK0YsUKZWZmqlWrVgX22bx5s7p06eLS1rVrV82bN0+XLl2St7d3aZQKACgF33zzjZo1a1akvv37979qn+3bt6tp06bFLQuwlNsEwD179qhVq1a6cOGCypYtq5UrV6pevXoF9k1NTVWVKlVc2qpUqaLs7GydOnVKISEhBa6XlZWlrKws5/v09PSS2wEAwHVRt25dbd++vdA+58+fV1JSksLCwuTv73/V8YCbndsEwDp16mjXrl06c+aM3n//fQ0aNEjr16+/Ygh0OBwu7/OeT/zb9svFxsZqypQpJVc0AOC6CwgIKNKMXZs2bUqhGuDG4BYXgUiSj4+PIiIiFB0drdjYWDVq1EizZs0qsG/VqlWVmprq0nby5El5eXmpQoUKV9zG+PHjlZaW5nwdPXq0RPcBAACgNLjNDOBvGWNcDtderlWrVvrwww9d2tasWaPo6OhCz//z9fWVr69vidYJAABQ2txiBnDChAnauHGjkpKStGfPHk2cOFHr1q3Tgw8+KOnXmbuBAwc6+48YMUJHjhzRE088oQMHDmj+/PmaN2+ennzySat2AQAAoNS4xQzgiRMnNGDAAKWkpCg4OFhRUVFKTExU586dJUkpKSlKTk529g8PD9fHH3+ssWPH6s0331S1atU0e/ZsbgEDAABswWHyrn7ANUtPT1dwcLDS0tIUFBRkdTkAAKAI+P52k0PAAAAAKDoCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM0QAAEAAGyGAAgAAGAzBEAAAACbIQACAADYDAEQAADAZgiAAAAANkMABAAAsBkCIAAAgM24RQCMjY1V8+bNFRgYqMqVK6tXr1769ttvr7re0qVL1ahRIwUEBCgkJERDhgzR6dOnS6FiAAAA67hFAFy/fr1Gjx6tLVu2aO3atcrOzlaXLl2UmZl5xXU2bdqkgQMHatiwYdq3b59WrFihrVu3avjw4aVYOQAAQOnzsrqAkpCYmOjyfsGCBapcubK2b9+udu3aFbjOli1bFBYWppiYGElSeHi4HnnkEc2YMeO61wsAAGAlt5gB/K20tDRJUvny5a/Yp3Xr1jp27Jg+/vhjGWN04sQJxcfHq3v37qVVJgAAgCUcxhhjdRElyRijnj176pdfftHGjRsL7RsfH68hQ4bowoULys7O1n333af4+Hh5e3sX2D8rK0tZWVnO9+np6QoNDVVaWpqCgoJKdD8AAMD1kZ6eruDgYFt/f7vdDOCjjz6q3bt3a9myZYX2279/v2JiYjRp0iRt375diYmJOnz4sEaMGHHFdWJjYxUcHOx8hYaGlnT5AAAA151bzQCOGTNGq1at0oYNGxQeHl5o3wEDBujChQtasWKFs23Tpk1q27atjh8/rpCQkHzrMAMIAMDNjxlAN7kIxBijMWPGaOXKlVq3bt1Vw58knTt3Tl5errvv6enpHK8gvr6+8vX1LX7BAAAAFnKLQ8CjR4/WkiVL9M477ygwMFCpqalKTU3V+fPnnX3Gjx+vgQMHOt/36NFDCQkJiouL0w8//KAvv/xSMTExatGihapVq2bFbgAAAJQKt5gBjIuLkyR16NDBpX3BggUaPHiwJCklJUXJycnOZYMHD1ZGRobeeOMNjRs3TuXKldOdd96pl156qbTKBgAAsIRbnQNY2jiHAACAmw/f325yCBgAAABFRwAEAACwGQIgAACAzRAAAQAAbIYACAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGQIgAACAzRAAAQAAbIYACAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGQIgAACAzRAAAQAAbIYACAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGQIgAACAzRAAAQAAbIYACAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGbcIgLGxsWrevLkCAwNVuXJl9erVS99+++1V18vKytLEiRNVs2ZN+fr66rbbbtP8+fNLoWIAAADreFldQElYv369Ro8erebNmys7O1sTJ05Uly5dtH//fpUpU+aK6/Xt21cnTpzQvHnzFBERoZMnTyo7O7sUKwcAACh9DmOMsbqIkvbTTz+pcuXKWr9+vdq1a1dgn8TERP3lL3/RDz/8oPLly/+u7aSnpys4OFhpaWkKCgoqTskAAIvk5ORo48aNSklJUUhIiNq2bStPT0+ry8J1xPe3mxwC/q20tDRJKjTYffDBB4qOjtaMGTNUvXp11a5dW08++aTOnz9fWmUCACyWkJCgiIgIdezYUf369VPHjh0VERGhhIQEq0sDriu3C4DGGD3xxBP6wx/+oAYNGlyx3w8//KBNmzZp7969WrlypV5//XXFx8dr9OjRV1wnKytL6enpLi8AwM0pISFBffr0UcOGDbV582ZlZGRo8+bNatiwofr06UMIhFtzu0PAo0eP1kcffaRNmzapRo0aV+zXpUsXbdy4UampqQoODpb0v78MMjMz5e/vn2+dyZMna8qUKfna7TyFDAA3o5ycHEVERKhhw4ZatWqVPDz+Nx+Sm5urXr16ae/evTp06BCHg90Qh4DdbAZwzJgx+uCDD/TFF18UGv4kKSQkRNWrV3eGP0mKjIyUMUbHjh0rcJ3x48crLS3N+Tp69GiJ1g8AKB0bN25UUlKSJkyY4BL+JMnDw0Pjx4/X4cOHtXHjRosqBK4vtwiAxhg9+uijSkhI0Oeff67w8PCrrtOmTRsdP35cZ8+edbYdPHhQHh4eVwyPvr6+CgoKcnkBAG4+KSkpknTFU4Xy2vP6Ae7GLQLg6NGjtWTJEr3zzjsKDAxUamqqUlNTXS7oGD9+vAYOHOh8369fP1WoUEFDhgzR/v37tWHDBj311FMaOnRogYd/AQDuIyQkRJK0d+/eApfntef1A9yNWwTAuLg4paWlqUOHDgoJCXG+3n33XWeflJQUJScnO9+XLVtWa9eu1ZkzZxQdHa0HH3xQPXr00OzZs63YBQBAKWrbtq3CwsI0bdo05ebmuizLzc1VbGyswsPD1bZtW4sqBK4vt7sIpDRxEikA3LzyLvy79957NX78eDVo0EB79+5VbGysVq9erfj4ePXu3dvqMnEd8P3tJk8CAQDgWvXu3Vvx8fEaN26cWrdu7WwPDw8n/MHtMQNYDPwLAgBufjwJxH74/mYGEABgc56enurQoYPVZQClyi0uAgEAAEDREQABAABshgAIAABgMwRAAAAAmyEAAgAA2AwBEAAAwGYIgAAAADZDAAQAALAZAiAAAIDN8CSQYsh7il56errFlQAAgKLK+96289NwCYDFkJGRIUkKDQ21uBIAAHCtMjIyFBwcbHUZlnAYO8ffYsrNzdXx48cVGBgoh8NhdTm4ztLT0xUaGqqjR4/a9uHhgLviz7e9GGOUkZGhatWqycPDnmfDMQNYDB4eHqpRo4bVZaCUBQUF8QUBuCn+fNuHXWf+8tgz9gIAANgYARAAAMBmCIBAEfn6+uq5556Tr6+v1aUAKGH8+YbdcBEIAACAzTADCAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIBAEbz11lsKDw+Xn5+fmjVrpo0bN1pdEoASsGHDBvXo0UPVqlWTw+HQqlWrrC4JKBUEQOAq3n33XT3++OOaOHGidu7cqbZt26pbt25KTk62ujQAxZSZmalGjRrpjTfesLoUoFRxGxjgKu644w41bdpUcXFxzrbIyEj16tVLsbGxFlYGoCQ5HA6tXLlSvXr1sroU4LpjBhAoxMWLF7V9+3Z16dLFpb1Lly76z3/+Y1FVAAAUDwEQKMSpU6eUk5OjKlWquLRXqVJFqampFlUFAEDxEACBInA4HC7vjTH52gAAuFkQAIFCVKxYUZ6envlm+06ePJlvVhAAgJsFARAohI+Pj5o1a6a1a9e6tK9du1atW7e2qCoAAIrHy+oCgBvdE088oQEDBig6OlqtWrXS3//+dyUnJ2vEiBFWlwagmM6ePavvvvvO+f7w4cPatWuXypcvr1tvvdXCyoDri9vAAEXw1ltvacaMGUpJSVGDBg302muvqV27dlaXBaCY1q1bp44dO+ZrHzRokBYuXFj6BQGlhAAIAABgM5wDCAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGQIgAACAzRAAAeA3Fi5cqHLlyhV7HIfDoVWrVhV7HAAoaQRAAG5p8ODB6tWrl9VlAMANiQAIAABgMwRAALYzc+ZMNWzYUGXKlFFoaKhGjRqls2fP5uu3atUq1a5dW35+furcubOOHj3qsvzDDz9Us2bN5Ofnp1q1amnKlCnKzs4urd0AgN+NAAjAdjw8PDR79mzt3btXixYt0ueff66nn37apc+5c+c0depULVq0SF9++aXS09P1l7/8xbn8008/Vf/+/RUTE6P9+/dr7ty5WrhwoaZOnVrauwMA18xhjDFWFwEAJW3w4ME6c+ZMkS7CWLFihUaOHKlTp05J+vUikCFDhmjLli264447JEnffPONIiMj9dVXX6lFixZq166dunXrpvHjxzvHWbJkiZ5++mkdP35c0q8XgaxcuZJzEQHccLysLgAAStsXX3yhadOmaf/+/UpPT1d2drYuXLigzMxMlSlTRpLk5eWl6Oho5zp169ZVuXLldODAAbVo0ULbt2/X1q1bXWb8cnJydOHCBZ07d04BAQGlvl8AUFQEQAC2cuTIEd1zzz0aMWKEXnjhBZUvX16bNm3SsGHDdOnSJZe+Docj3/p5bbm5uZoyZYp69+6dr4+fn9/1KR4ASggBEICtbNu2TdnZ2Xr11Vfl4fHradDvvfdevn7Z2dnatm2bWrRoIUn69ttvdebMGdWtW1eS1LRpU3377beKiIgoveIBoIQQAAG4rbS0NO3atculrVKlSsrOztbf/vY39ejRQ19++aXmzJmTb11vb2+NGTNGs2fPlre3tx599FG1bNnSGQgnTZqke++9V6Ghofrzn/8sDw8P7d69W3v27NGLL75YGrsHAL8bVwEDcFvr1q1TkyZNXF7z58/XzJkz9dJLL6lBgwZaunSpYmNj860bEBCgv/71r+rXr59atWolf39/LV++3Lm8a9euWr16tdauXavmzZurZcuWmjlzpmrWrFmauwgAvwtXAQMAANgMM4AAAAA2QwAEAACwGQIgAACAzRAAAQAAbIYACAAAYDMEQAAAAJshAAIAANgMARAAAMBmCIAAAAA2QwAEAACwGQIgAACAzRAAAQAAbOb/Adx+gYbMwygFAAAAAElFTkSuQmCC' width=640.0/>
</div>




```python
plt.imshow?
```


    [1;31mSignature:[0m
    [0mplt[0m[1;33m.[0m[0mimshow[0m[1;33m([0m[1;33m
    [0m    [0mX[0m[1;33m:[0m [1;34m'ArrayLike | PIL.Image.Image'[0m[1;33m,[0m[1;33m
    [0m    [0mcmap[0m[1;33m:[0m [1;34m'str | Colormap | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mnorm[0m[1;33m:[0m [1;34m'str | Normalize | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [1;33m*[0m[1;33m,[0m[1;33m
    [0m    [0maspect[0m[1;33m:[0m [1;34m"Literal['equal', 'auto'] | float | None"[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0minterpolation[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0malpha[0m[1;33m:[0m [1;34m'float | ArrayLike | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mvmin[0m[1;33m:[0m [1;34m'float | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mvmax[0m[1;33m:[0m [1;34m'float | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0morigin[0m[1;33m:[0m [1;34m"Literal['upper', 'lower'] | None"[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mextent[0m[1;33m:[0m [1;34m'tuple[float, float, float, float] | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0minterpolation_stage[0m[1;33m:[0m [1;34m"Literal['data', 'rgba'] | None"[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mfilternorm[0m[1;33m:[0m [1;34m'bool'[0m [1;33m=[0m [1;32mTrue[0m[1;33m,[0m[1;33m
    [0m    [0mfilterrad[0m[1;33m:[0m [1;34m'float'[0m [1;33m=[0m [1;36m4.0[0m[1;33m,[0m[1;33m
    [0m    [0mresample[0m[1;33m:[0m [1;34m'bool | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0murl[0m[1;33m:[0m [1;34m'str | None'[0m [1;33m=[0m [1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [0mdata[0m[1;33m=[0m[1;32mNone[0m[1;33m,[0m[1;33m
    [0m    [1;33m**[0m[0mkwargs[0m[1;33m,[0m[1;33m
    [0m[1;33m)[0m [1;33m->[0m [1;34m'AxesImage'[0m[1;33m[0m[1;33m[0m[0m
    [1;31mDocstring:[0m
    Display data as an image, i.e., on a 2D regular raster.
    
    The input may either be actual RGB(A) data, or 2D scalar data, which
    will be rendered as a pseudocolor image. For displaying a grayscale
    image, set up the colormapping using the parameters
    ``cmap='gray', vmin=0, vmax=255``.
    
    The number of pixels used to render an image is set by the Axes size
    and the figure *dpi*. This can lead to aliasing artifacts when
    the image is resampled, because the displayed image size will usually
    not match the size of *X* (see
    :doc:`/gallery/images_contours_and_fields/image_antialiasing`).
    The resampling can be controlled via the *interpolation* parameter
    and/or :rc:`image.interpolation`.
    
    Parameters
    ----------
    X : array-like or PIL image
        The image data. Supported array shapes are:
    
        - (M, N): an image with scalar data. The values are mapped to
          colors using normalization and a colormap. See parameters *norm*,
          *cmap*, *vmin*, *vmax*.
        - (M, N, 3): an image with RGB values (0-1 float or 0-255 int).
        - (M, N, 4): an image with RGBA values (0-1 float or 0-255 int),
          i.e. including transparency.
    
        The first two dimensions (M, N) define the rows and columns of
        the image.
    
        Out-of-range RGB(A) values are clipped.
    
    cmap : str or `~matplotlib.colors.Colormap`, default: :rc:`image.cmap`
        The Colormap instance or registered colormap name used to map scalar data
        to colors.
    
        This parameter is ignored if *X* is RGB(A).
    
    norm : str or `~matplotlib.colors.Normalize`, optional
        The normalization method used to scale scalar data to the [0, 1] range
        before mapping to colors using *cmap*. By default, a linear scaling is
        used, mapping the lowest value to 0 and the highest to 1.
    
        If given, this can be one of the following:
    
        - An instance of `.Normalize` or one of its subclasses
          (see :ref:`colormapnorms`).
        - A scale name, i.e. one of "linear", "log", "symlog", "logit", etc.  For a
          list of available scales, call `matplotlib.scale.get_scale_names()`.
          In that case, a suitable `.Normalize` subclass is dynamically generated
          and instantiated.
    
        This parameter is ignored if *X* is RGB(A).
    
    vmin, vmax : float, optional
        When using scalar data and no explicit *norm*, *vmin* and *vmax* define
        the data range that the colormap covers. By default, the colormap covers
        the complete value range of the supplied data. It is an error to use
        *vmin*/*vmax* when a *norm* instance is given (but using a `str` *norm*
        name together with *vmin*/*vmax* is acceptable).
    
        This parameter is ignored if *X* is RGB(A).
    
    aspect : {'equal', 'auto'} or float or None, default: None
        The aspect ratio of the Axes.  This parameter is particularly
        relevant for images since it determines whether data pixels are
        square.
    
        This parameter is a shortcut for explicitly calling
        `.Axes.set_aspect`. See there for further details.
    
        - 'equal': Ensures an aspect ratio of 1. Pixels will be square
          (unless pixel sizes are explicitly made non-square in data
          coordinates using *extent*).
        - 'auto': The Axes is kept fixed and the aspect is adjusted so
          that the data fit in the Axes. In general, this will result in
          non-square pixels.
    
        Normally, None (the default) means to use :rc:`image.aspect`.  However, if
        the image uses a transform that does not contain the axes data transform,
        then None means to not modify the axes aspect at all (in that case, directly
        call `.Axes.set_aspect` if desired).
    
    interpolation : str, default: :rc:`image.interpolation`
        The interpolation method used.
    
        Supported values are 'none', 'antialiased', 'nearest', 'bilinear',
        'bicubic', 'spline16', 'spline36', 'hanning', 'hamming', 'hermite',
        'kaiser', 'quadric', 'catrom', 'gaussian', 'bessel', 'mitchell',
        'sinc', 'lanczos', 'blackman'.
    
        The data *X* is resampled to the pixel size of the image on the
        figure canvas, using the interpolation method to either up- or
        downsample the data.
    
        If *interpolation* is 'none', then for the ps, pdf, and svg
        backends no down- or upsampling occurs, and the image data is
        passed to the backend as a native image.  Note that different ps,
        pdf, and svg viewers may display these raw pixels differently. On
        other backends, 'none' is the same as 'nearest'.
    
        If *interpolation* is the default 'antialiased', then 'nearest'
        interpolation is used if the image is upsampled by more than a
        factor of three (i.e. the number of display pixels is at least
        three times the size of the data array).  If the upsampling rate is
        smaller than 3, or the image is downsampled, then 'hanning'
        interpolation is used to act as an anti-aliasing filter, unless the
        image happens to be upsampled by exactly a factor of two or one.
    
        See
        :doc:`/gallery/images_contours_and_fields/interpolation_methods`
        for an overview of the supported interpolation methods, and
        :doc:`/gallery/images_contours_and_fields/image_antialiasing` for
        a discussion of image antialiasing.
    
        Some interpolation methods require an additional radius parameter,
        which can be set by *filterrad*. Additionally, the antigrain image
        resize filter is controlled by the parameter *filternorm*.
    
    interpolation_stage : {'data', 'rgba'}, default: 'data'
        If 'data', interpolation
        is carried out on the data provided by the user.  If 'rgba', the
        interpolation is carried out after the colormapping has been
        applied (visual interpolation).
    
    alpha : float or array-like, optional
        The alpha blending value, between 0 (transparent) and 1 (opaque).
        If *alpha* is an array, the alpha blending values are applied pixel
        by pixel, and *alpha* must have the same shape as *X*.
    
    origin : {'upper', 'lower'}, default: :rc:`image.origin`
        Place the [0, 0] index of the array in the upper left or lower
        left corner of the Axes. The convention (the default) 'upper' is
        typically used for matrices and images.
    
        Note that the vertical axis points upward for 'lower'
        but downward for 'upper'.
    
        See the :ref:`imshow_extent` tutorial for
        examples and a more detailed description.
    
    extent : floats (left, right, bottom, top), optional
        The bounding box in data coordinates that the image will fill.
        These values may be unitful and match the units of the Axes.
        The image is stretched individually along x and y to fill the box.
    
        The default extent is determined by the following conditions.
        Pixels have unit size in data coordinates. Their centers are on
        integer coordinates, and their center coordinates range from 0 to
        columns-1 horizontally and from 0 to rows-1 vertically.
    
        Note that the direction of the vertical axis and thus the default
        values for top and bottom depend on *origin*:
    
        - For ``origin == 'upper'`` the default is
          ``(-0.5, numcols-0.5, numrows-0.5, -0.5)``.
        - For ``origin == 'lower'`` the default is
          ``(-0.5, numcols-0.5, -0.5, numrows-0.5)``.
    
        See the :ref:`imshow_extent` tutorial for
        examples and a more detailed description.
    
    filternorm : bool, default: True
        A parameter for the antigrain image resize filter (see the
        antigrain documentation).  If *filternorm* is set, the filter
        normalizes integer values and corrects the rounding errors. It
        doesn't do anything with the source floating point values, it
        corrects only integers according to the rule of 1.0 which means
        that any sum of pixel weights must be equal to 1.0.  So, the
        filter function must produce a graph of the proper shape.
    
    filterrad : float > 0, default: 4.0
        The filter radius for filters that have a radius parameter, i.e.
        when interpolation is one of: 'sinc', 'lanczos' or 'blackman'.
    
    resample : bool, default: :rc:`image.resample`
        When *True*, use a full resampling method.  When *False*, only
        resample when the output image is larger than the input image.
    
    url : str, optional
        Set the url of the created `.AxesImage`. See `.Artist.set_url`.
    
    Returns
    -------
    `~matplotlib.image.AxesImage`
    
    Other Parameters
    ----------------
    data : indexable object, optional
        If given, all parameters also accept a string ``s``, which is
        interpreted as ``data[s]`` (unless this raises an exception).
    
    **kwargs : `~matplotlib.artist.Artist` properties
        These parameters are passed on to the constructor of the
        `.AxesImage` artist.
    
    See Also
    --------
    matshow : Plot a matrix or an array as an image.
    
    Notes
    -----
    Unless *extent* is used, pixel centers will be located at integer
    coordinates. In other words: the origin will coincide with the center
    of pixel (0, 0).
    
    There are two common representations for RGB images with an alpha
    channel:
    
    -   Straight (unassociated) alpha: R, G, and B channels represent the
        color of the pixel, disregarding its opacity.
    -   Premultiplied (associated) alpha: R, G, and B channels represent
        the color of the pixel, adjusted for its opacity by multiplication.
    
    `~matplotlib.pyplot.imshow` expects RGB images adopting the straight
    (unassociated) alpha representation.
    [1;31mFile:[0m      c:\users\chl_b\anaconda3\lib\site-packages\matplotlib\pyplot.py
    [1;31mType:[0m      function



```python
##################################################################################################################
#
# YouDo:
# Make a pair of plots as follows:
#    1) Show the correlation matrix between columns of the data
#        (hint 1: it should be 124x124, hint 2: check out plt.imshow() 
#         Hint 2: numpy has a function for generating the correlation matrix)
#
#    2) Make a similar plot showing correlation > 90%
#
#  Stretch goal:  using plt.subplot()  make a single figure with both plots side-by-side
#
#######################################  BEGIN STUDENT CODE  #####################################################
# correlation matrix between columns of data with 124 x124
import pandas as pd
import matplotlib.pyplot as plt


correlation_matrix = df.corr()
plt.figure(figsize=(12, 10))
plt.imshow(correlation_matrix, cmap='viridis')
plt.colorbar()
plt.title('Correlation Matrix of Metabolomics Data')
plt.show()




#######################################   END STUDENT CODE   #####################################################

```



<div style="display: inline-block;">
    <div class="jupyter-widgets widget-label" style="text-align: center;">
        Figure
    </div>
    <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABLAAAAPoCAYAAADOWwfbAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjguMCwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy81sbWrAAAACXBIWXMAAA9hAAAPYQGoP6dpAAEAAElEQVR4nOzdd5wdZfn//+vs2d2z/Wzf7G56Dz2EGjpIEBDFQhGl40cMithQRKR8EL6gIjaagtgFFMSCCNKRGggJSSghvexm+9l69uyeM78//CQ/l/O+kEViJub1fDzyR66dveeee+6ZOZmcmXckCILAAAAAAAAAgJDK2dYdAAAAAAAAAN4KN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAAAAAAAhBo3sAAAAAAAABBq3MACAAAAAABAqHEDCwAAAAAAAKHGDSwAAAAAAACEGjewAAAAAAAAEGrcwAIAAAAAAECocQMLAAAAAAAAocYNLAAAAAAAAIQaN7AAAAAAAAAQatzAAgAAAAAAQKhxAwsAAAAAAAChxg0sAAiJxYsX25lnnmmTJk2ygoICKykpsT333NOuvfZa6+jo2NbdG+HRRx+1SCRijz766Kh/d9myZXbZZZfZ6tWrs352xhln2MSJE//t/r0TkUjEIpGInXHGGfLnV1xxxZZlVN//laeeesouu+wy6+rqGtXvTZw40e3T1tTR0WEnn3yy1dbWWiQSseOPP95d9tBDD7VIJGKTJ0+2IAiyfv74449vGbvbb7991H3ZuHGjXXbZZfbSSy+N+nc3u/322y0SidiCBQvecRtvdtlll1kkEnnX2huNzdvzTubiO7F5Wzf/KSoqsrFjx9pRRx1l3//+962np+cdt/1Ojw0AALBj4QYWAITAj370I5szZ449//zz9qUvfcnuv/9+u+eee+yEE06wm266yc4+++xt3cV3zbJly+zyyy+X//C+5JJL7J577vnPd+r/lJaW2l133ZX1j/EgCOz222+3srKyd9z2U089ZZdffvmo/5F+zz332CWXXPKO1/tO/e///q/dc8899p3vfMeefvppu/baa99y+dLSUlu1apU9/PDDWT+77bbb/q2x27hxo11++eX/1g2s/zbHHnusPf3001ZfX/8fXe/9999vTz/9tN1///32rW99y8aPH28XXnih7bzzzrZo0aJ31OY7PTYAAMCOJXdbdwAAdnRPP/20fepTn7IjjzzSfv/731ssFtvysyOPPNK+8IUv2P333/+urKu/v9+Kioqy6ul02oaHh0ese1uYMmXKNl3/Bz7wAfvd735nv/nNb+wTn/jElvrDDz9sq1atsk984hP2ox/96D/Sl4GBASssLLTZs2f/R9b3ZkuWLLEpU6bYxz72sbe1/Pjx4620tNRuu+02O+KII7bUe3p67K677rKPfexj/7Gx2xHU1NRYTU3Nf3y9c+bMserq6i1/P/nkk+3Tn/60HXLIIfb+97/fXn/99W1+HgEAAP+d+AYWAGxjV111lUUiEbvlllvkP/zy8/Pt/e9//5a/ZzIZu/baa23mzJkWi8WstrbWTjvtNFu/fv2I3zv00ENtl112sccff9zmzp1rRUVFdtZZZ9nq1astEonYtddea1deeaVNmjTJYrGYPfLII2ZmtmDBAnv/+99vlZWVVlBQYLNnz7Y777zzX27HggUL7OSTT7aJEydaYWGhTZw40T760Y/amjVrtixz++232wknnGBmZocddljWY2XqEcJkMmkXXXSRTZo0yfLz862xsdHOO++8rG9rTJw40d73vvfZ/fffb3vuuacVFhbazJkz7bbbbvuXfd8sHo/bBz/4wazfue222+yAAw6w6dOnZ/3Ogw8+aB/4wAds7NixVlBQYFOnTrVPfvKT1tbWtmWZyy67zL70pS+ZmdmkSZO2bPfmRzA39/3uu++22bNnW0FBgV1++eVbfvbPjxCee+65VlBQYC+88MKWWiaTsSOOOMLq6uqsqanpLbexo6PD5s+fb42NjZafn2+TJ0+2iy++2AYHB83MtsyPv/3tb/bKK69k9fWtnHXWWXb33XeP2De/+c1vzOwfNzqU5cuX2ymnnGK1tbUWi8Vs1qxZ9sMf/nDLzx999FHbe++9zczszDPP3NKfyy67zMze3rz7Z52dnXbmmWdaZWWlFRcX23HHHWcrV67MWu62226z3Xff3QoKCqyystI++MEP2iuvvPIvx2C0x+fTTz9tc+fO3dL3n/zkJ2Zm9uc//9n23HNPKyoqsl133TXrJrb3COH9999vRxxxhMXjcSsqKrJZs2bZ1VdfveXnK1eutJNPPtkaGhosFotZXV2dHXHEEf/Wt9t23313u/jii23t2rV2xx13bKm/G8fGHXfcYfPmzbP6+norLCy0WbNm2Ve+8hXr6+t7x/0FgG3h8ccft+OOO84aGhosEonY73//+3/5O4899pjNmTPHCgoKbPLkyXbTTTdt/Y4CIcYNLADYhtLptD388MM2Z84cGzdu3Nv6nU996lP25S9/2Y488kj7wx/+YP/7v/9r999/v82dO3fEPwzNzJqamuzjH/+4nXLKKXbffffZ/Pnzt/zse9/7nj388MP2rW99y/7yl7/YzJkz7ZFHHrEDDjjAurq67KabbrJ7773X9thjDzvppJP+5buLVq9ebTNmzLDrr7/e/vrXv9o111xjTU1Ntvfee2/p17HHHmtXXXWVmZn98Ic/tKefftqefvppO/bYY2WbQRDY8ccfb9/61rfs1FNPtT//+c/2+c9/3n7605/a4YcfvuWmy2aLFi2yL3zhC/a5z33O7r33Xtttt93s7LPPtscff/xtja2Z2dlnn23PPPPMlpsVXV1ddvfdd7uPca5YscL2339/u/HGG+2BBx6wr3/96/bss8/agQceaENDQ2Zmds4559hnPvMZMzO7++67t2z3nnvuuaWdF1980b70pS/Z+eefb/fff799+MMfluu7/vrrbdasWXbiiSduuVF0+eWX26OPPmq/+MUv3vKRsmQyaYcddpj97Gc/s89//vP25z//2T7+8Y/btddeax/60IfMzKy+vt6efvppmz17tk2ePFn21XPyySdbNBq1X//611tqt956q33kIx+RjxAuW7bM9t57b1uyZIl9+9vftj/96U927LHH2vnnn7/lBt6ee+655abO1772tS39Oeecc8zs7c27f3b22WdbTk6O/epXv7Lrr7/ennvuOTv00ENH3HS7+uqr7eyzz7add97Z7r77bvvud79rixcvtv3339+WL1/+lmMwmuOzubnZzjzzTDvnnHPs3nvvtV133dXOOussu+KKK+yiiy6yCy+80H73u99ZSUmJHX/88bZx48a3XPett95qxxxzjGUyGbvpppvsj3/8o51//vkjbp4dc8wx9sILL9i1115rDz74oN144402e/bsf/vxvc032f/5WHs3jo3ly5fbMcccY7feeqvdf//9dsEFF9idd95pxx133L/VXwD4T+vr67Pdd9/dfvCDH7yt5VetWmXHHHOMHXTQQbZw4UL76le/aueff7797ne/28o9BUIsAABsM83NzYGZBSeffPLbWv6VV14JzCyYP3/+iPqzzz4bmFnw1a9+dUvtkEMOCcwseOihh0Ysu2rVqsDMgilTpgSpVGrEz2bOnBnMnj07GBoaGlF/3/veF9TX1wfpdDoIgiB45JFHAjMLHnnkEbevw8PDQW9vb1BcXBx897vf3VK/66673N89/fTTgwkTJmz5+/333x+YWXDttdeOWO6OO+4IzCy45ZZbttQmTJgQFBQUBGvWrNlSGxgYCCorK4NPfvKTbj83M7PgvPPOCzKZTDBp0qTgi1/8YhAEQfDDH/4wKCkpCXp6eoJvfvObgZkFq1atkm1kMplgaGgoWLNmTWBmwb333rvlZ2/1uxMmTAii0Wjw2muvyZ+dfvrpI2rLly8PysrKguOPPz7429/+FuTk5ARf+9rX/uU23nTTTYGZBXfeeeeI+jXXXBOYWfDAAw9sqR1yyCHBzjvv/C/bfPOyp59+erDXXnsFQRAES5cuDcwsePTRR4Pnn38+MLPgJz/5yZbfO+qoo4KxY8cGiURiRHuf/vSng4KCgqCjoyMIgkD+rsebdz/5yU8CMws++MEPjlj+73//e2BmwZVXXhkEQRB0dnYGhYWFwTHHHDNiubVr1waxWCw45ZRTttQuvfTS4J8/Sr2T43PBggVbau3t7UE0Gg0KCwuDDRs2bKm/9NJLgZkF3/ve97K2Z/N86unpCcrKyoIDDzwwyGQycmza2toCMwuuv/56PXhvYfO2tra2yp8PDAwEZhYcffTR8ufv9NhQbTz22GOBmQWLFi0a9XYAQBiYWXDPPfe85TIXXnhhMHPmzBG1T37yk8F+++23FXsGhBvfwAKA7cjmx/zenEq3zz772KxZs+yhhx4aUa+oqLDDDz9ctvX+97/f8vLytvz9jTfesFdffXXLO4+Gh4e3/DnmmGOsqanJXnvtNbdvvb299uUvf9mmTp1qubm5lpubayUlJdbX1/e2Hr1SNr8Q/M3be8IJJ1hxcXHW9u6xxx42fvz4LX8vKCiw6dOnu4+TKZuTCH/+85/b8PCw3XrrrXbiiSdaSUmJXL6lpcXOPfdcGzdunOXm5lpeXp5NmDDBzGxU273bbrvJRxSVqVOn2o9+9CP7/e9/b+973/vsoIMO2vJI3Vt5+OGHrbi42D7ykY+MqG8e3zeP5ztx1lln2YIFC+zll1+2W2+91aZMmWIHH3xw1nLJZNIeeugh++AHP2hFRUVZ8y2ZTNozzzzzL9c32nn35nd6zZ071yZMmLDl2Hr66adtYGAga86NGzfODj/88Lcco9Een/X19TZnzpwtf6+srLTa2lrbY489rKGhYUt91qxZZmZvOY+feuop6+7utvnz57vJiJWVlTZlyhT75je/adddd50tXLjQMpmM2+ZoBCJ98t04NlauXGmnnHKKjRkzxqLRqOXl5dkhhxwyqjYAbP+SyaR1d3eH7k8ikciqvfnb4e/U008/bfPmzRtRO+qoo2zBggVbvsUK7Gh4iTsAbEPV1dVWVFRkq1atelvLt7e3m5nJx8QaGhqy/oH7Vo+TvflnmzZtMjOzL37xi/bFL35R/o56JGuzU045xR566CG75JJLbO+997aysjKLRCJ2zDHH2MDAgPt7b6W9vd1yc3OzXlYdiURszJgxW8Zjs6qqqqw2YrHYqNd/5pln2uWXX25XXXWVvfjii/b9739fLpfJZGzevHm2ceNGu+SSS2zXXXe14uJiy2Qytt9++41qvaNNkzv22GOtrq7ONm3aZJ///OctGo3+y99pb2+3MWPGZN3gqK2ttdzc3KzxfCcOPvhgmzZtmt18881255132gUXXCBvqLS3t9vw8LB9//vfd8f3rebbZqOdd2PGjJG1zdv+r46xBx980O3LaI/PysrKrOXy8/Oz6vn5+Wb2j3/AeVpbW83MbOzYse4ykUjEHnroIbviiivs2muvtS984QtWWVlpH/vYx+wb3/iGlZaWur/7r2zets033t6NY6O3t9cOOuggKygosCuvvNKmT59uRUVFtm7dOvvQhz70js8rALYvyWTSJk0oseaW9LbuSpaSkhLr7e0dUbv00kvf1n8q/SvNzc1WV1c3olZXV2fDw8PW1tb2H0+hBcKAG1gAsA1Fo1E74ogj7C9/+YutX7/+Lf/xafb/36BpamrKWnbjxo0j0sHMzP0mhvrZ5t+96KKLtrwP6c1mzJgh64lEwv70pz/ZpZdeal/5yle21AcHB62jo8Ptw79SVVVlw8PD1traOuImVhAE1tzcvOXl3u+2cePG2Xve8x67/PLLbcaMGTZ37ly53JIlS2zRokV2++232+mnn76l/sYbb4x6nW+1r5Rzzz3Xenp6bOedd7bzzz/fDjroIKuoqHjL36mqqrJnn33WgiAYsb6WlhYbHh7Omj/v1Jlnnmlf+9rXLBKJjBiXf1ZRUWHRaNROPfVUO++88+QykyZNesv1vJN519zcLGtTp041s5HH2JupY+yfjfb4fDdtPj7e/LL4N5swYYLdeuutZmb2+uuv25133mmXXXaZpVKpf+vlwH/4wx/M7B8vpzd7d46Nhx9+2DZu3GiPPvrolm9dmdm//b4uANuXVCplzS1pW/PCRCsrDc8DRN09GZswZ7WtW7duxHse380k1jd/Ntj8bdfRfmYA/luE5wwAADuoiy66yIIgsE984hOWSqWyfj40NGR//OMfzcy2PA74i1/8YsQyzz//vL3yyit2xBFHvON+zJgxw6ZNm2aLFi2yvfbaS/7xvqERiUQsCIKsD20//vGPLZ0e+T+mm5d5O9+e2Lw9b97e3/3ud9bX1/dvbe+/8oUvfMGOO+44u+SSS9xlNn+AfPN233zzzVnLjma7/5Uf//jH9otf/MJ+8IMf2B/+8Afr6uqyM88881/+3hFHHGG9vb1ZyUc/+9nPtvz83XD66afbcccdZ1/60pessbFRLlNUVGSHHXaYLVy40HbbbTc53zbfEPLGbjTzbrNf/vKXI/7+1FNP2Zo1a7bceNl///2tsLAwa86tX7/eHn744bcco615fP4rc+fOtXg8bjfddJN8nE+ZPn26fe1rX7Ndd93VXnzxxXe87kWLFtlVV11lEydOtBNPPNHM3p1jYzRtAPjvV1aaY2Wl0RD9+cc/pcvKykb8ebduYI0ZMybrP11aWlosNzdXfuMc2BHwDSwA2MY2p3TNnz/f5syZY5/61Kds5513tqGhIVu4cKHdcssttssuu9hxxx1nM2bMsP/5n/+x73//+5aTk2NHH320rV692i655BIbN26cfe5zn/u3+nLzzTfb0UcfbUcddZSdccYZ1tjYaB0dHfbKK6/Yiy++aHfddZf8vbKyMjv44IPtm9/8plVXV9vEiRPtscces1tvvdXKy8tHLLvLLruYmdktt9xipaWlVlBQYJMmTZIfxo488kg76qij7Mtf/rJ1d3fbAQccYIsXL7ZLL73UZs+ebaeeeuq/tb1vZd68eVnvnnizmTNn2pQpU+wrX/mKBUFglZWV9sc//lE+Zrbrrruamdl3v/tdO/300y0vL89mzJgx6se2Xn75ZTv//PPt9NNP33LTanPS3/XXX28XXHCB+7unnXaa/fCHP7TTTz/dVq9ebbvuuqs9+eSTdtVVV9kxxxxj73nPe0bVF09DQ8Pbigf/7ne/awceeKAddNBB9qlPfcomTpxoPT099sYbb9gf//jHLe9AmzJlihUWFtovf/lLmzVrlpWUlFhDQ4M1NDS87Xm32YIFC+ycc86xE044wdatW2cXX3yxNTY2bknoLC8vt0suucS++tWv2mmnnWYf/ehHrb293S6//HIrKCiwSy+91N2erX18vpWSkhL79re/beecc4695z3vsU984hNWV1dnb7zxhi1atMh+8IMf2OLFi+3Tn/60nXDCCTZt2jTLz8+3hx9+2BYvXjziG2xv5YUXXrB4PG5DQ0O2ceNGe+ihh+znP/+51dbW2h//+Mctjzu+G8fG3LlzraKiws4991y79NJLLS8vz375y1/aokWL3r2BA7DdyFhgGXt33tv3bsjY2/vPgndq//333/IfmJs98MADttdee414hymwQ9lWb48HAIz00ksvBaeffnowfvz4ID8/PyguLg5mz54dfP3rXw9aWlq2LJdOp4NrrrkmmD59epCXlxdUV1cHH//4x4N169aNaM9LkducQvjNb35T9mPRokXBiSeeGNTW1gZ5eXnBmDFjgsMPPzy46aabtiyjUgjXr18ffPjDHw4qKiqC0tLS4L3vfW+wZMkSmaJ3/fXXB5MmTQqi0eiIdLk3pxAGwT/Szb785S8HEyZMCPLy8oL6+vrgU5/6VNDZ2TliuQkTJgTHHnts1vYccsghwSGHHCK39Z/Z/6UQvhWVlrZs2bLgyCOPDEpLS4OKiorghBNOCNauXRuYWXDppZeO+P2LLrooaGhoCHJyckaMn9f3zT/bPH69vb3BzJkzg5122ino6+sbsdx5550X5OXlBc8+++xbbkN7e3tw7rnnBvX19UFubm4wYcKE4KKLLgqSyeSI5d5pCqHHSxJctWpVcNZZZwWNjY1BXl5eUFNTE8ydO3dLKuBmv/71r4OZM2cGeXl5I8b27c67zal9DzzwQHDqqacG5eXlW9IGly9fntXfH//4x8Fuu+0W5OfnB/F4PPjABz4QLF26dMQyb04hDIJ///j05sKb5+ebUwg3u++++4JDDjkkKC4uDoqKioKddtopuOaaa4IgCIJNmzYFZ5xxRjBz5syguLg4KCkpCXbbbbfgO9/5TjA8PJy1TrWtm//EYrGgvr4+mDdvXvDd73436O7uzvqdd+PYeOqpp4L9998/KCoqCmpqaoJzzjknePHFF992KiWA7V8ikQjMLGh/fVIw1DQlNH/aX58UmFlWkq6np6cnWLhwYbBw4cLAzILrrrsuWLhw4Zb05K985SvBqaeeumX5lStXBkVFRcHnPve5YNmyZcGtt94a5OXlBb/97W+3yjgD24NIELzN75kDAAAAAPAf1N3dbfF43NpfnxS6d2BVTV9liURixDuwPI8++qgddthhWfXTTz/dbr/9djvjjDNs9erV9uijj2752WOPPWaf+9znbOnSpdbQ0GBf/vKX7dxzz303NwPYrnADCwAAAAAQSptvYLW8NiF0N7BqZ6x52zewAPz7wnMGAAAAAAAAAARuYAEAAAAAACDUSCEEAAAAAITaP1IIw/P2mzD1BdhR8A0sAAAAAAAAhBo3sCDdcMMNNmnSJCsoKLA5c+bYE088sa27BAAAAAAAdlA8Qogsd9xxh11wwQV2ww032AEHHGA333yzHX300bZs2TIbP378v/z9TCZjGzdutNLSUotEIv+BHgMAAADwBEFgPT091tDQYDk52+d3GDKWscy27sQ/CVdvgB1DJAgCHt7FCPvuu6/tueeeduONN26pzZo1y44//ni7+uqr/+Xvr1+/3saNG7c1uwgAAABglNatW2djx47d1t0Yle7ubovH47bxtbFWVhqem2/dPRlrmLHeEomElZWVbevuADsEvoGFEVKplL3wwgv2la98ZUR93rx59tRTT72tNkpLS83MbM2LE62sZORF5pBvnC1/p7A9Lev9tVFZz+vV912HC/U3vnY7fYmsL/rFLrJetEn3p30nfciUrdX/A5OJ6v4MlWbX845sk8v2PVMt64MzBmQ9/nSBrO9z2iJZ37lkvaz/9itHyXrX1DxZ795pSNbHPKr3YcY5+0RPbtXL/7pG1svPWCfrry/TH86m3KnHrWluiayPfaBDt39WXNbrH5dl6xmnx2HGB1+X9VU/m6bbP2W1rL/ywsSs2gH7L5XLVsX6ZP3v39tb1isWtMj6G2fXynrjLs2y3vFgg6z3N+rjZ+qvumV92g9XyPrjv5kj656IPsytZ7r+QeEYPW671W2U9fzIsKy/dKc+7+Q757XcAV1PVurzy/6nLpT1lZ+cIOtdu1XI+kHnP5tVe6lTH1fdv2iU9fjrvbLeO75Y1psPkGWzuD6/FBSnZH2gS58Hi1bmy3r/VN1OXoFeb83vdfu99fo4752o53hObVLWIzl6+fyX9HlqYBd9Xit+qVDWvfcOR1P6B1Uv98t6yxy9H712DjptQVbtlcQYueyuFfq4WtSp51pzt/7HY9lvdR9b99LHz85zVsn6G+36GlR6r94nbXvIslVNb5f13J9W6vqAPh+17qHncuD8277xMX3+WnGGvhjXPKbbz+/V/Qmcb9wnq3SHvPPvcJFuJ627Iz8PDhfoNoo36eOqZ5zuY6APZ4vqw81qXtLHSd4KfU0c+JE+j3T/oV7Wi1qd/jfqjg40jBybTDJpa7/xv1s+pwPA9ogbWBihra3N0um01dXVjajX1dVZc7O+AA8ODtrg4OCWv/f09JiZWVlJTtb/kkTz9cU6N09/konm64tyNF9/OA7y9YeW/BL9yWfU/YnpQyaarz9URJwbWBnRz2hRzFmn7mNOkR4Db5vyS/SNp8ISvU25ebqdaEy3k1Oo91Vunq6ndTOWW6zHIe30x1s+p9BZPtcZN2ecc6OjbN/ZrmjMuRlbPLq56S2fU5C9vDfvYzH9j3X3ePDGQKzTzN8n7lwu0MdPbnRQ1r257LXv8f4BlVPoHP9F+oaUt0/ynUc0vH56/+jPHfaOde98p8fH249R59iKiXZyU04b7tzRN4C880uOc7/FnPNL1PnHbs6gd/5yjp9Cva/885rXvl7em+M5RbLs3sAa9fXAOya8G1jOD3JzR9cfrx05p4b1nFLLmr3FHHTaceeac5PDPScPjO74yXGGPuqcH71+5g55n0dGdwMrN1e3k1Pofa7R7Xufj7wbWNH80d3A8j7HmR42ed4MYrqN3DxvHo/yBpbz1Jh3nOTmOGPpXSvdz6Ze/73zjj4Ot+fXe6SDwNIhengoTH0BdhTh+Q4mQuXNF7cgCNwL3tVXX23xeHzLHx4fBAAAAAAA7yZuYGGE6upqi0ajWd+2amlpyfpW1mYXXXSRJRKJLX/WrdOPdAEAAAAAALwT3MDCCPn5+TZnzhx78MEHR9QffPBBmzt3rvydWCxmZWVlI/4AAAAAwLslY0Ho/gD4zyKFEFnuuOMOO/XUU+2mm26y/fff32655Rb70Y9+ZEuXLrUJE/RLgP/Z5qSQ3U7/RtZz/AuuuFH+zn4Xnivr3ktQYx363uvEn6+V9aZj9WONefqdplbQqV/OMFiu19u+q/O+hT5dL1udfdh574Tq3FkfomUrdF8KOp2XMzhHetp530Qq7ryAXr+v1krW6xUUN+t34LTtot8JUdDhvDslobfLe2nysH5vr1W+ot9jVLhJv5W1eX/9stOqpfr9TOuOdN6H1OXNBb1dA86Lb713cvQ3iPeAOK+5aHhCz+/Dv/GkrP/hhkNkPdd5kW1iqq6XOF/OrFyiX3zbPUW/EKm30Rkb579kippHeZlzxq24Wc+djQfqd8gUNeuGBstH2R2n+8POe48ql+h6nvMy+OZ99cDVvpC9fNFG/dLxrul6XxV06fndOc15p5V+PZsVOS9fHirWYxxfoRvqbXTeRTOoxyZnyHmBvnMtGKh19nmVbmfCX/R5xDtfD39Vh0qkbtUvQveOifxePZ5tu+q5PFyoO1S0yXlxt84esbrns68HfXV6nd7x1l+jl09WO++cdN726p17veUHqvVgzjv9aVl/5If7yXp8lZ6b/XXOu/2cORhxLvWRT+rQjcgP9Evo1x3pfH7p9c4LesWts/Xy3nmqNvt9/mZm1raH7k/9U/q61bZz9g4bmKA/d5Qs12Ps7fOM8+L4fJ0vYgM13nnEeT+YPp3a/FP/KOt/njtZ1jeetrOsD74pFyCdTNqKq7+6XSbmbf63xZpXG0KXQjhh5sbtckyB7RUvcUeWk046ydrb2+2KK66wpqYm22WXXey+++57WzevAAAAAAAA3m3cwII0f/58mz9//rbuBgAAAABYxgJLh+ixPR4hBP7zwvMdTAAAAAAAAEDgBhYAAAAAAABCjUcIAQAAAAChFrbkvzD1BdhRkEKId93mpJB933eF5eaNTCFMlegv/T1z7U2yvtON+j1cER1GY6VrdTrOYFyvN3V4QtaHXtNJIoUtXpKMPow699ZJOAVrs6Nt4it033Od5LD2XXWKV3y5k2rnJCgVtTqJQnvKspW9ocdg2EkD65mmk6Tiy/T98yEnPTC/x+nPGt3+pr31+KQLZNli7br/eXN16ldyYaWs5+spZb3j9TjXPqeXH6jR+6tko578PY3Z21v9sk44S0zW0UqpMmff6oA5m/QznfrZu3uDrHdN0/s85iRPevsqx0mq8/rvpfh5iY4pHTxppWt0QxWv9Mp65046stNLhuuv0/335n7USc4bLtTt9DU6SXIb9fI54tDyjrfu8XrfRpyPGN45vNfJCil/VdcLO3R/2mfptLG8Xt2fgTFOemCl7mj5Mr0T0zHnGCqSZStu0v3x9m1/rV6vl5ZWst5JbyxyEvucNNweHX5med1eYtzbP/ekC5wUvP7RzR03Sc7Zpq5dnWtujx7j4vVOPKmjsE23n6zQ7Xzg3Mdk/e7bD5X13gm6fXd88vR4FrTqE2GsU7eT+942WW9fWSHreQk9nnefep2sn/r/Pi/riQN1ZF+QyJ5T03+iI6aLrtsk6019+jNfy6s6uTE+RQ9O/0v6c0HaOT7LVup6xkmHLuhw0pgb9BiXrhu5/PBQ0l743de2y8S8zf+2WPHqGCsNUQphT0/Gpsxs3i7HFNhehecMAAAAAAAAAAg8QggAAAAACLV0EFg6RA8PhakvwI6Cb2ABAAAAAAAg1LiBBQAAAAAAgFDjEUIAAAAAQKhl/u9PWISpL8COghRCvOs2J4XsetY3LJo/MkYsMU1Pt3wnpWbZp26Q9T/06Uin7/3PybLetouOMxvUgTHmpeKWrdY/SExxEmPadTsqac9LRIvpEDwb1gFnVrhJ99FLqRpy0gPNKe950suyvvBXu8p6fJWTErazk0JYovtftcRJXHNSv1r311FMXvqhlxjlpTd6aYmFbU7KWbXuZ6zLmVPOseLNk8JN2f0MnH2YpwOaLFk9urH32s/kOomO/c4YV+kxHnaS0vrrndTCOh1PWPRKTNa9NMDA+a+dqA7BsvxuZ5/X6v6f/9F7Zb0hTydb/blzd1nf0F8u6xvvmCjrXjrh+097QtbvvuugrFqsSy7qJlWWOil4ndP14Ccb9Pki2uMkpXXobSpbM7r0vY499PIFzU6aaUzv8/gKWbZ+J+UwojfXylfq81fHx3TiZcFfdfpV0jnvFLY4553puj8FrU5S4IBePmdodAmZSsoJ9EpO0Md52WJ9ketvcJIek84+cVL8Clt1O73j9fJewlyODid2k+pUGqiZn7raM2V0yZl9OjTWYl2jS130kjY93tyf8l49cM0/maTbEZvbeay+yOUt0h+cvMTbIFfv88JmPTbetcPb531jdftDZXofTr1DNzT41S5Z7/xb/Yi/pweT9tp3v7pdJuZt/rfFq6/UhS6FcOasTdvlmALbq/CcAQAAAAAAAACBRwgBAAAAAKGWtsDS3mMS20CY+gLsKPgGFgAAAAAAAEKNG1gAAAAAAAAINR4hBAAAAACEWjr4x5+wCFNfgB0FN7Cw1eT1BhbNH3lmj3WM7kt/Xtrg+4v7Zf2bFXmy7qWEpZ0Eu4E6vfxg3EuSk2VXyfrs9gfLnba7dTpW7oCToORcTL1tzetzUnCcdMKdSjbK+tLELnrFTn+8BLuclP5BfkJHFgXlOiWsYKM+vXnpWP11em7mOymB3vj44yzLbjulq50EvjFOotZgdi3W4czjCidRrE/XU6Wy7Kb4FXQ6O90LvHRyqDPOFaqgzRmbfH38e0lpXv8zuhlLlevtKn9Db0AmqudmjnOQvpJslPVdivUxt6bXiVF1hn/YSc4sytGpblEReJWK6zbKVukx8FJCvfNUQZPe6d6+8hLavOM8yNH9ifbrFeT16PaTdXp7c4Z1+5mos15n7vc556PkGn0wRkucVDTnmPPSAHNSetzc5Dwd8CnPR2Z6P7pt6Glp0ULnWhDVMX65/aNLgPSeTfDmWqzduxbo5SPDo/sXb7cO37Nc/THIncvetcn7/OLtcy9t0BtPb9y881FdgT7oNjgpjZn87O3KzdUHlpcS6J2PzDme007qqjnHs5cwmd/pHIeDuqMDNU6qaK6T3vrm5FznuASA7QmPEAIAAAAAACDU+AYWAAAAACDUMuZ+0W2bCFNfgB0F38ACAAAAAABAqHEDCwAAAAAAAKHGI4QAAAAAgFDLWMTSXiLMNpAJUV+AHQU3sLDVDBdGLHhTOszEn6+Vy7YfMlbWv/c/J8u6lzb4xA9ulvXJv/2krBc26ZSwyiWybPm9aVnPTeqn4KMDut41NTuSZrBCrzPWpS+OfWOdVCsnZcZLwfESmvJ7dCzPA+cdLOtdR+v2e/ucVDE99Fa8Tq+3dQ+9z9MFup2iZt1Oz0E6kq6k+M1xPf+Q+bPeMV6yncdL9+pr0MtP+qNewaZ9dARU+fLsFKJUmf6SbXeVs867u2W9bY8y3c403U7uEj2nesfq/vSP1wlKNU87KX5Oilc65iTJ9erlvfTDvnrd/+FiJ9nOmcv5znp/eeH7ZL1orU7fGi7Xkzw3oQ/25PucdNVxOlbsoQsOlPX0Adm1VJkzlitl2U0sq3lJ7/PuCfp8kXTmrLdvu6bqneKlGVYs1e0MFzmpfEndkJd+WLFcT7aiT26Q9RVL9Ylh0u/1uK36gJPAWaej6gqd813Z3XqgS9fpudYyR0ftla3SEYJr35vdz6KNTuJijZP6+bCOgCts19dnL3GxfTcviVGWrXuyro//qx7L1cfpi25kSK+3eIOXwKvX66UlT7tCf4B57Yf6hD39+/q80DdOH7yJSfrYKmxxjpW0k/xbq/f7ms/rfnZ9WLcz7sHsYyL/Bd3Htt3ffoqvmVmsRx+3/TW676Xr9BxMF+h92zld93Pin/S14Mbf3ijrJ339S7Ke86bzV+DsCwDYnvAIIQAAAAAAAEKNb2ABAAAAAEItE/zjT1iEqS/AjoJvYAEAAAAAACDUuIEFAAAAAACAUOMRQgAAAABAqKVDlkIYpr4AOwpuYGGr2e30JZZfMjKF54Xc3eSyQVRfAJIVOn0rv1s/dO6lDa78iE4n3OuST8l67qCTGDfGSd9pcy5gpXr5/obs5Qv3bJfLJnIr9Tp375D14G96+dp562X94Jo3ZP2xL+wv611T9D5JN+okptrf6ySm3kY9Np2H6XZq/qLTrmZ9ZqmsP7FyiqxX/E0nWPXV68Sl2g06oaljpk79KmzSqUWpUj1HjjriRVlf+MIesn78GY/J+i8fyE6HzJ+kk4yOnLBcr3PRbFmvebZT1tvn6HTC9vfqGK/i5/QY55bp5ate0tFQqW/3yXricZ1m6iVweoacpL3GWZtkfWNNuaxPGdMq6y2/Gy/ryQrdTsl6PT4D9cWyPvVIHQnYetNEWR+s1F/G/p+T78uqPdWpj6v1C3RyWNUyfTwnJurzSM9cnZpngXONGKOPw0hKb9OYp3TznbP08sFO+hiq/7Wey+l83c+2XXU9aNUpp0GJTjNr3lefB4OYTieMvVAi68NDuh4t0HM/P6HnYCZP92ewQn+8PObQF7Jqizsa5bL71qyW9ceapsp6U5fepvJH9Dnfu2YdNuNVWR9I67m2bMXOsh6p10myw/16bGJLdfueVLmubzx7V1mvekTv2zdO1PvQTWN2Pn9FnJcBDRXpue9MQeuYpfdXyRonkXlMdr13rB5jL3k2WaXbHqzUn1Mi+nCzWIe+ZuUuWSXrZefpQWjumCDrJ16m0wZjvXrDeiaO7H86yc0WANs/HiEEAAAAAABAqPENLAAAAABAqPEIIQC+gQUAAAAAAIBQ4wYWAAAAAAAAQo1HCAEAAAAAoZYJIpZxQj22hTD1BdhRRIIg0LEhwDvU3d1t8Xjcdj3rGxbNH5k0lesETPUe3y3rmcVxWc/VIWSWcUJ8Clv0NF/wvzfK+uxvzJf1/jG6nZpFOgGma6pOsEnWZC/f8IRuI8hx0rfi+guUlUt7Zb19V512U9ip17vhCFm2+DInlSetx2bOmYtlffWF02W9bVcnJbBBt1/1sq637C3LFk3p8Sxs1vXumTpuqHCDvv+fp0PLbMCZO3XP6vFv3lfv3/pndDpZjkjOTMX1voo6KZvtO+vlK17T6yzo0GOTk3K2aX+9bzN6te5xG9WBaNahw7csiDqpWWm9z4dr9Aom3Kn3SV6/HoeNc/X2FjXr/gzU6f7EOvXy6ZhePndAL++Nc8ZJzouvzN6uwPlvrx4n9Ss/ofuSM+wct/vo9ktW67GveF2nhHqvJVl/mO5nkKf7U7BJr7e4SS9f2KaPla4per3JWt1O+WuybJ2zdD2315k7Cb38sA5RdAXO9/WjOmjP6p7TF+mB+uz0yVSJbtxLhitZr8c4WaHbiTifctv30cdtwQb9QaLxUZ1a2DpbJ2rWP6E/16w7Uqe3DtTr7Rp/vz6frj1Gb2+0V9czTsJk0Xq9fNVSfWxtPNg51rv0/krr06AlG3T75Yv0+F/5udtk/WvXn5VVK9mox3L9+5xrWalOD8z/e6msd8/Qcye+TI+Nd83t08G5FnXSAr3PuMlx+poVXzQygjc9mLRlN3/VEomElZXpeRhWm/9t8eSSBispDc8DRL09GTtwl43b5ZgC26vwnAEAAAAAAAAAgUcIAQAAAAChRgohAL6BBQAAAAAAgFDjBhYAAAAAAABCjUcIAQAAAAChlrYcS4fo+xc6FgDA1kQKId51m5NC9j32CsvNG5nOE3HO9E1znbQ0J4llqFRP28oluv1cJwFmoEpfBBdefIOs73qdTifM0YE0lnFuEce6svszWKm3NeK0HdHBRG5qXuWLeoxznRSpwQonlW+q3ollb+j283r12HsJU96Y1bykE4sGavQvDJbr9gcrdPteeqCXYJXO1/XBKic5TwdYWWRY97Nok25nuFAvPyDSzCqX6TZSpc46W/Wk6pjl7FtnzMpX6DnYvrPeV3XP6wSojhkxWc/vcVIFM7reM36UH3ZH+UqL6pf19iYm6e1NzNLLF6925rIzp7zzackaXe/c00mN7NP7t2x59rh5Y99f75y/nD4mq3U7xet1OzlDevnSDXqbuibruK5kjW4n1jm686+XxujJF+d8M7P4Kj33Nx6gk+3KVutjNM9Jnhyt9Uc66Yob9QZ7ycK5fU5/xDDnOanC+b16W/tr9PEccxIvW47TY1z2hB5j75roJTdWvursw7m6fS9F1VtvYrpzzV3uJAI7nw2SVbpest45b04Y3YkwXehc+wZ0O0GOXj6/Ry+f55x7ktXZy3ufIwZr9QFdtUCP5aDzOcU7r6WcELpUud4pDU84Ka3O+W6gUvczrada9nKppC358cXbZWLe5n9bPLxkXOhSCA/fZd12OabA9io8ZwAAAAAAAABA4BFCAAAAAECoBUHEMkF4kv+CEPUF2FHwDSwAAAAAAACEGjewAAAAAAAAEGo8QggAAAAACLW0RSw92qSVrShMfQF2FNzAwlbTvlOuRWMjp1jZGp3EUtiiLwAFHTqJZTCul8/v1dEwfWN0ckv/GN2+lzb48ud1OuE+X/2UrCemybINl2T330t0i+qAI4smdd+L1urD2kv88RLpytbotJ6IE++T0UNs3ZN03Uuvyk/oevN+OlWsdI2zXXGn/W5dHyzX9cples52znCSsDqcuekkZA0X6vWmnDnujVtha/bywzrEz207ktbbFF+hxyCT6yQ9lul2CtqclLA9dUcL2vXyQ8WybOkCvd7hEicRzSmXrNN1LyWsr85JhnLGv+5J3c/8PidRb4o+5uIr9fkuWa7bH/OI7udwgd6PyersWtpJwfQSwnKcxLW8Xl3vHeuc1zbp9fY7KaQFHXrODjnpVW5irJd46aUrOqll3lxo2t9JwnNSS71EXW+fR1OjSycse9VJHPVSBZ1yVIfGWn9d9vgMlTjL1o6uL11T9BiM/aXeuR2z9L7y0gYLnfNXf52OpK14XU8SL/3YO7a8ZyVU8qyZWV6vc+1wzl9D4vOImVnFa/oYSuc57TufSbzPHv11esMC57OEl8CbI+ZaoZPiW7paN54q022Xv6H3Yfc43U78DS8hV5ate7xup2iTkzba7yQ9OufZvoaRY5we5GYLgO0fjxACAAAAAAAg1PgGFgAAAAAg1NJBjqWD8Hz/Ij26L7kCeBeE5wwAAAAAAAAACNzAAgAAAAAAQKjxCCEAAAAAINQyFrFMiL5/kfGSLABsNdzAwlZTtjZj0fyRSSrtu+oElNJV+gKQmKKXj3XpdeYmnZTDNt1OsZNU0zNWJ8N4aYPPXXWjrE++55OyXrEo++LrJcN17ebEOeXpvjfcP7qUwLwBnbLTOlu3U7ZydBfrxgfaZH3VSTWy7iUZla3S7bvJR1EnschJdRx/f5+sb9pPR955aYleSlD6fZ2yHv+pjkvccJhuv2qh/uA26xNLs2rPPLazXHb8/TribP1hOhFtcECPZePDOjqz+YBSWS9q1sdnLKHrHTs7CU1NTvJkmSy7cz9wjqHaZ/TOTRfrtLE1R+vYskig2/fmbOse+pgr3qCXzzhpYN4cbD5WR1UVL9b7XSVnjnlwo1z29XMbdF+cRLRxD+oYwr4GHUnnJcPFupy0sbX6QM/k6W1N613rphOWNenEyPY5Tjppq56EUSdtsPplva9Wn6K3t/wZvQF5Tmqpl05Yuk5H1bV8Tne0Z70+6IICfV2Zdlv29SxdqAe5Z6zepvxefb7wUjkjziVrsNK5hj6ur7mrP+wkzLbq/qfq9ByZdKfuZ6pUz5G6Z/TY563eJOurz5gs68Ubnc9ZU/V23fmFb8v6h3/wJVk/+4y/yPqCxERZf/2WWbLetrfevxPv0eO56iPZ49Y3zbnWbNBpxlEnobH7NB1bXPC7clkPTtafd3oGdAxp+lV9rRwQaZ1mZo2P6zFITNDb1Tt95FzODDifJwFgOxKeW9gAAAAAAACAwDewAAAAAAChlraIpU1/Q21bCFNfgB0F38ACAAAAAABAqHEDCwAAAAAAAKHGI4TYajLRiEXe9CLt3D79VdvOvfULa+OLnDfrOqID+sWd5rwctWuqrkf0ezItMU3XvZe1r/zgzbI+Z3H2y+AjTtcL14/upaMte+oXtRY16bEv1O8ctYJWXU+Vei/W1xuw5oP6Ze2puF6+d6y+r+69ND2t341qhc16HHL0+3Ot6QD9svZkrW6n/indUG+9nlM9y8tlPVqpxzP+iq5H0ro/CzaMz6pVLtHL9tXr4ypVrvdJTkrvk2Rtoax7Bmp0OwXter25+r36luu8mDpdqLc3v1uPZTqm6z1T9YupCzfpF4OXL9f9SVY5QQLOPix0QiW8kKNIRv+gt9F5a323Ppd4ouK0nCnTb1P3zu3euXRgjH6ZemGLXj53QG/rsLMPo0m94t5G58X3+p3y7gvAkxV6jKsmdsh6/4ZqWS9/Q59H+mv1x7PSl/QxNKTfBW1Dzvk6x9kveb16u/pfLZf1mBPwEHGSE3rHZW+XF77iHScD1XoMvOO5sE1vrBfu0DFTnx9LXtfLp53TYH6TPt6Gi/Q+33iobqdwo742ZfL0y9oHq/R45vXpcfM+exz1l8/JerRO/8L3FhyuG3LOO8F+ehxKVui53z1J9/++92a/bP6j3/6iXLbgaH2CaXmjStaDVh0q0X2ofhl6zmtOO/lOaEK7nrN9jc5OcWScj8qlr4wc+/Sg8wFoO5IOciwdhOf7F2knrAXA1hOeMwAAAAAAAAAgcAMLAAAAAAAAocYjhAAAAACAUMtYxDIhSv4LU1+AHQXfwAIAAAAAAECocQMLAAAAAAAAocYjhNhqhkojlskf+dXastVenJaOUBnS4TtWsl630zVVt9PfoL/iO1Sqk17KnQS44RJdr1ik7wWrtEEzsxcuvTGrtvfX9LJespKXOuWlDeb36DHrGa/7Xtyklw+cb0t7SU+dM3UCUcUy3VB/nW7f46UiDlbq/sc69PJesl3xeiepbqw+fUaG9XrzuvU4B1G9fGJnnRZUvFpHZxU+kD0hkk7Coadwk64XOYmOXhJbxrmyxNfpbeqcptuJr9THZ2Ky838vThpQjg45ddP9uifo/iTLddxYutA5RnVgnyXjuv10gZOoN+gk8DnL5/Xq5cuXOnPQmSYDtdk/6No5rvtSpNdZ+6Kud4/Xk6S/wUmS7NKdLN6ol++cpdPDql7Rc7B5X2dsnKlWvkK30/WAThscrnESQev0XIh167nvndfyep00U6efOc55qmOGvoYWb5BlyxlyrhM5uj/Jiuz6cJGeCxknNLOwVa8zE3XO1Y26IW/MvEQ3L7nRkrrsnU9zUs61qV2PgzfHvX6WONcs74QXRJxja71znnI+k2Q26GRR7/yS2++cr505lazRDX3ii9lpiXmlzrb+Rqcix8uctE4ngbeoVR+fA841N9eZI90TdT3WrtfbV6fbL3WurYkpI/dhsP2HEFrGciwdou9fZLwPEgC2mvCcAQAAAAAAAACBG1gAAAAAAAAINR4hBAAAAACEWjrIsbT3bPc2kHZeXQBg6wnPGQAAAAAAAAAQuIEFAAAAAACAUOMRQmw1eUe2WbQoNqKWvlsnNMVX6ESX7on6HutguZM8V6H7Urhnu6zX3KYTtTqn60Mjr0e3n4rr/kT0ZsnEweevzE4mNDPb7dvzZT1n7y5ZTy7V29Q9U8fPVDQmZL3kezrFKzFZRx89cNvNsn7kJ86V9ZY5OhlqaJaOA2y4Rc+FFafpek63kxLYrvdV93S9sybcp6OnmubqcfCSpzJ5+mvmg0d1y3rlX8pkPXGYHp/kuuyEvOHKId32GL3Pi35RKesl63WEUtNcHbOXKtPb2luvU60K2vXyha26/y3v1/uq8gEnBStHtx9xvvnfO85JyKzXy2cK9LEVKdfxh3l9Os0wo4fHok5qmZdC2L6vnrNFK/Ux541/w1HrsmorNulzePV9euzz+vTYlGxw0gmnybINVTipX16KX5tzXhjWy0ecx0Aiegpaf40+vySrnXYyel91zXZW4Ch5Te/DVLleb/suzvh06vajSedY7NDj3zFLt1/kJOflfrg1q5Z4Xc+pkon6PNXWoeOJi5Y7CYpOou6Qc55K1urjtryyV9d/pK+5Gz6q29FbZdZwp5NmWqjncvcUvXzJGt3+kJOi7KU99k7Q9fhyZ453O9e48lH+X7mTWli1xEk6Fp/Xilr0fB0q0o3HuvTyyQonDXCMruc7Y1C2Wl9DNx2o52zt0/q48pJtuyc6F4//QhnLsUyIvn9BCiHwnxeeMwAAAAAAAAAgcAMLAAAAAAAAocYjhAAAAACAUEsHEUsHznOm20CY+gLsKPgGFgAAAAAAAEKNG1gAAAAAAAAItUgQONE7wDvU3d1t8Xjcpn3xKovGRiZTJat10kv93/U07PMSprp1O0FEf5U34SRb1byk20k4iS7RQd1O1246SapwvY73iYhgLq/txV+4QdZ3+a5OJ8zTQUmWO6DHOHDCa/L69PID1fq+d26/cypxyoMVel/l6KAhq3jdSaRz0gxLV+sV5/XrfR7r0ivumBWT9eJmna7mpRZ5yZl5PU5yU6Ve3vu2enJ6dspRpF0nHI15RrfRvJ+ul6z1Et308oM6lMsGq/TYl67W7Zeu12PcMUNP2sD5L5lYl6576Vs1i3RiVMtsnbTXM10PRNlr+in9ok16HLzUUu+Yi3XqXxh2kra8uZN20gzzerPnZvEmva0bDtbbWrFMr9M773jnqeiQc5yU6bHxzl9J57iqeF0nxiWr9CQpbNHLrz9Mz5HCFll2zyM9Y50BcvZhYZtzXkvoejpfN5Sb1Mu37eJcy5w5O+V9K2R9002T9C8I/U7Sm5qXb8WbU+o6bGY2XOh8jpiul/d64z1YNOFPA7Le36DnzqCTchxfqedgy2x9zSpfoTc4MUnPtZ5Z+ppb9aw+1tv3ctJYU7r/Y/6u650z9H6vWqbbb90je/mcGfqDUPFfdbpyjhMG2jlL16sX6b3eNd37fKTbSetdZUMluv3aF/QBV9imN+DTt9w54u/9PWk7dfbLlkgkrKxMJx2H1eZ/W9y+cHcrKg1P6mJ/T9rOmL1ouxxTYHvFN7AAAAAAAPgPuOGGG2zSpElWUFBgc+bMsSeeeOItl//lL39pu+++uxUVFVl9fb2deeaZ1t7e/h/qLRAu3MACAAAAAGAru+OOO+yCCy6wiy++2BYuXGgHHXSQHX300bZ27Vq5/JNPPmmnnXaanX322bZ06VK766677Pnnn7dzzjnnP9xzIBy4gQUAAAAACLVMkBO6P6N13XXX2dlnn23nnHOOzZo1y66//nobN26c3XjjjXL5Z555xiZOnGjnn3++TZo0yQ488ED75Cc/aQsWLPh3hxPYLnEDCwAAAACAd6C7u3vEn8FB/WLbVCplL7zwgs2bN29Efd68efbUU0/J35k7d66tX7/e7rvvPguCwDZt2mS//e1v7dhjj33XtwPYHnADCwAAAACAd2DcuHEWj8e3/Ln66qvlcm1tbZZOp62urm5Eva6uzpqbm+XvzJ071375y1/aSSedZPn5+TZmzBgrLy+373//++/6dgDbAx0lArwLBmcMWE7RyCSVsqcL5bLtu+o2vOSW3AGdXtM3VtcLd++Q9eSqCln3kpWiSSdvKM9JztJhQzZUml3L2btLLuulDS75rE4n3ONqvXzne3Rn6iq7ZX3g93WyXrNQt/PGGToVZsrP9WCuPk4n5FXPapP1VFO1rCdrdDLR8E46SS7/pWJZH3TSA700w5Y99fIl62TZPn7ag7J+09OHynr5Szr1Kz2vU9Zz+rPjjEqndMllvZTNsod0fKCX6FbcrBPp1p2q6xN+qtfbNUVva/E6fQJInKbbL/h9uaxHB53j1okJa99Jp4GlnHTFvLj+n9boYQlZH/xLpax7KapVS/VcHqjRx1D7YfoYHe7Syzc+rNdb/uns93GseESnyHkpe5WL9Rj0TtZpYK0n6r4PJfXHldgqva+8pzqiSb2tKz+q6w1j9YYN/UCfj/L16dQSe+s50pPvJLet1dfKdIk+nw44iX0lq/UxV9jhJf/qcY7qwDtLiWuZmdm6X02W9Z4P9GXVhhI6ii1SqFcaDOltLV6u53fxBlm2TYfr80gkpvfJB3d+Sdb/creOb43toz93rDH9uSMvoedgzWKdMNc1VW+vp8+ZI727ORHIKb1818xRhpeX6XFu20P3v+plPceHipxUyp7scSv6kz6/dM2UZTeRMq9P75PuSbqe3+W046Q0983TaYl5i/WBNViuxyCdr8fyK78+deRyyaSZvaw7uZ1IW46lQ/T9i/T/5ZCuW7duRAphLOZETP6fyJuu90EQZNU2W7ZsmZ1//vn29a9/3Y466ihramqyL33pS3buuefarbfe+m9uAbD94QYWAAAAAADvQFlZ2YgbWJ7q6mqLRqNZ37ZqaWnJ+lbWZldffbUdcMAB9qUvfcnMzHbbbTcrLi62gw46yK688kqrr6//9zcA2I6E5xY2AAAAAAD/hfLz823OnDn24IMjv5X/4IMP2ty5c+Xv9Pf3W07OyH+yR6P/+HZtEIzyG5HAfwG+gQUAAAAACLWMmaUD5/n/bcB548hb+vznP2+nnnqq7bXXXrb//vvbLbfcYmvXrrVzzz3XzMwuuugi27Bhg/3sZz8zM7PjjjvOPvGJT9iNN9645RHCCy64wPbZZx9raGh4F7cG2D5wAwsAAAAAgK3spJNOsvb2drviiiusqanJdtllF7vvvvtswoQJZmbW1NRka9f+/++gPOOMM6ynp8d+8IMf2Be+8AUrLy+3ww8/3K655ppttQnANsUNLAAAAAAA/gPmz59v8+fr0KXbb789q/aZz3zGPvOZz2zlXgHbB25gYauJP11g0fyRCVH5PfrLtrEu3UYmV39NOOI88h11wnSCv+nUr8qlPbL++lk6AaporT5kGu7X9ZY9dUeLmrK3K7lUR5wV6ZAaN23wpYt0OuHsK/XyXeVFsl7ermN52nfWqV+5OjzQuifqukoOMjPreaJWt++8o7JQpw5b4SK9XX2NenlvTuX36B9UvOr0f4Ku3/uNI2Q9d0+9fOVrejKvnVgu68Ubs9vJmB6DgQn6OGxYmJ0QZma2/jCd3Ng2WyecxZ/SqYLd4/RYxhK6PjBGH4fBk04iXbees7EOneLlpRD2jXGS7aK6n16yZdEK3c5wTLeT16/3S2KiTjOKpnQ7BS/p/T5YqZcf0sNsy5+YmFUr1MFq1teo2+6ertO0ElOc1LyH9Fh6KV5d03U943y6KdShiJbzmk7x6l06Rrc/S7eTKtf9KVms92HRJr3PO3fS7U/6lU6k3LS3HrdIRvent16Pf1Gr7k9xk06SyxnSyzcdqLc33Zw9N0s26L7kpPR5ZFhPbytsceaIkzxXuUBPksFyvd77Vuq0wca/632ywknaLBPXfzM//XjN8bpe8aKul67XDfWM0+Nc8bSe+znOaXO4QPc/OuTUB/V1wjtGvXEof1V/GEpMFePsnNsL2vQPipv0Sr0+Dpbrdko26GvQYFyPffnd+rgt6NSD37KnnpsNT+g5mI6NvAalnTTR7UnGciwTolc4h6kvwI6Cow4AAAAAAAChxg0sAAAAAAAAhBqPEAIAAAAAQi0d5Fg6CM/3L8LUF2BHwVEHAAAAAACAUOMGFgAAAAAAAEKNRwix1exz2iLLLxmZmPLCdbPlsgM1+l6qlzyVjukEmLQO07Haeetlvb1fR9JVOuk+QY6TeKVDdmTaoJlOtuueqdNrylbqxjvfMyDrXtrgwq/pdMJr2qfJupeaN1TmjH2x7n9Bp5Pc5qQQtp/cL+uF9+q0nupz1sj6skUTZL3xMZ02tPEgJ52oWacBrT9cT7aKZbr97ol6jh9+6EJZX/b0brI+fs8Nuj9D2XM5mKJTBT80/WVZ//sz+8r62Ed0O2+colP2Gk9YJeubfjZR1puP0AlnU2/Xc+qwk/WYPfKbvWU9Z5w+hnJ089Zfr+fsmF03yXpzu04QLZynozmbHhinl2/V6404/UyV6jn79PnXyfp7P/tZWe93zr+nf+DhrNpznRPlsu3f1fVo0km126D73raXXj4o0PVInhNZ5ugzfdwO1erjvLKuW9ZTj1fLeok+HVnXQfp83e8kW5YW61Sx5g6dqGsHdcpy75JyWc/k6vXmDDnpkBt0KmrLbB1hWdis2z/muOeyaqv6quSyBVF9Xhh2Htl5fskUWa97Ui/fMk9Hsu0zZbWsr+jU+7zvdb1PIs7nl6GD9JyKPVom67WP64/qXlJlykm8q16s5/i6j+pxrn7QSRwecCJ7HYNxfawP1Op2Clt0/3sbdKJpVBxagRMr7KUKJibpdWacz5RRfXhagZN4W7RRn8Q7L9bnhe4/6GPCW+/GA/VxmPum5dODTjzjdiRjEct4MZPbQJj6Auwo+AYWAAAAAAAAQo0bWAAAAAAAAAg1HiEEAAAAAIQaKYQAOOoAAAAAAAAQatzAAgAAAAAAQKjxCCG2mp1L1lthycgp9lz+nnLZoladJNVf66QT9umEmdx+nQZycM0bsv63znpZTxXr9XqpX3kDOmGmUIeQWc/47PYrGhNy2eBFnXBUV6mTjLrKi2TdSxv8ctVyWf9r28GyPhjXsTy9Mb0Pc/t0fahMn352rd8o65sSOmGqPF+n+AT5er15vU7KWa5OqosO6ISmIEePg5eQ6Tks/qqsLzOdQjh//KOy/pUFH8uq7T9htVz2hIrsJDAzs6cCnUJoEb1NQYGe95UxnVrYlCfLFunVcyGa1MlnkwtbZf1hJw005qX7OQF26XK9z2eUt8h6daHe3iklup9NEZ1CGHhppi16nAeq9C/8olsfK0XNejzTMZ02tm+xPm8q90UmynpBi5OyNV4nigV5el9NnKjHfmOHToAsKtAJc8ELMVkfmqH7eVDDSll/aZleb6rU2YmO3Fy9bzOBPuYyzjGUSuofFG/U7URTepxTerMs/zV9Xs6dMVnW0wV6vSdUPJ9V+2vurnLZPCd+c8g5UBZXNui+5JXIunXpMTugfIWs9w7pudNu+hodFOr+V5fq88VAnz4m0nq17ucdT6xNR9jl5jtzZNBJqnT+6ztnWC8/UKf3V9EmZ71JZ709er0qBTpw/nVT0KHb9p4CG3bm8bD+mGWxV3RKsBXplMD8XL3iAfdaoC9amajuZ1/DyHr6vyAwL205lg7R9y/C1BdgR8FRBwAAAAAAgFDjBhYAAAAAAABCjUcIAQAAAAChlgki7iPW20KY+gLsKPgGFgAAAAAAAEKNG1gAAAAAAAAItUgQBDqSA3iHuru7LR6P29z3XG65eSPTrTqn69Sf3vE6WaV4g3OP1Zm1Xjph2SqdSLX6g/op2rLXdARM2RqdTtY6W7dToEPIZD9L1us+DtTqMRss019bLmx3UvaclJqCtiFZf/hnt8r6Hv9vvqzHOvXY947T642vdNIJi/Tyqbiul63RSU9dk/U+TOvANat4TbezaV+93vJXdH2wwkkDmqDbn3ivnlPN++noqbEP6QSr7snZKUde0lj5gmZZX3lao6zn6oA2q3hd9z0Z12MfcY7bZKWTcugkMZWs9+a4Xj6/Z3TLb5qjf1D7om4n4lxGvXHwUsW8/kR1eKANFetxi3Xp/nRP1svn6wBUq3tOzDUnkbJjpk7ZGqzSyxdvcJJn6/Q5v7h5dOlbhR16bnrXIO8pkKg+LVvGeQFDqlzXvTHO6/USdXU9Mc0Zn3XOweVsl5cS6CXP9Y8Z3dzJcc499X/NTjPs2b1ON+JtkpMeGnFS8BKT9D5PVut2CluczxFrvXO1ngzlrzvXxLF6H3pzsGaxvkYnJujt8hLyvGQ+79o9WO4kYbpz30l7dfZjbq9uv6hZ/0KPDry0UhEUWrre2Vf76jEbijupxQm9rwZrdPvFa/TgeGOQ1+2MvXNNzO/S7SRrdb1s5cj206mkLfz1xZZIJKysrEz/Ukht/rfF/3v+ECsoCc8bcJK9w/aVvR/bLscU2F7xDSwAAAAAAACEGjewAAAAAAAAEGrh+Q4mAAAAAABCJsixTBCe71+EqS/AjoKjDgAAAAAAAKHGDawdzNVXX2177723lZaWWm1trR1//PH22muvjVgmCAK77LLLrKGhwQoLC+3QQw+1pUuXbqMeAwAAAACAHR2PEO5gHnvsMTvvvPNs7733tuHhYbv44ott3rx5tmzZMisuLjYzs2uvvdauu+46u/3222369Ol25ZVX2pFHHmmvvfaalZaWvu11dU3Ns2hsZOLLUIletuwNnbiy+xkvy/pOJdlJRmZmD5x3sO7LFB09F1+m15uYoRPjIk78zpuTXjZLlTrpaqKcmJwvl/XSomoW6mi49p31tg45qYWDcb1eL23wpa/cIOsHXHCurFctdVICp+ix9JIkK15zkpgm61Qh7/Z89cs6PWigUkfAVTj3bgdqvVRH3f/ql/U4tO2mI+nydNigrZtXLOvRZHYtt1+30X+0ThvM69XLq7bNzDpmOMfDap3o1Fc/ulRRL22sZ5xuJ0cPsSUrndQvpzuxTl1v3UPPkeKNTvqW05/3n/eYrLcP6X17SuUzsv6bzn1l/eFf7SPr5a/rAf34JX+W9R+lj8uqDTmXgLJVTkqgc3i2zdb1wk263l+jd9ZAnR77/AV6+XwnobFnoj6eS5x0v0yJk364SS+fjjmpYk4KmTfHC9pk2TL6NO4euwUden917OQkwzXpdry0xOFC3c5Gce7xkhtz9CnfenfSsZzVT+hB6Bun+xhfrtv3rtvpAr1PSlfpdrzzWkGrM6ecY6Vprj7Pxtqd9TrntfLl+oTUPUGf17w0QC/Zctjpj5fAl3FSVw/95LOy/tgN+nyXFnMt7ws6abforrGyHtmoN2qgRpatfJneJ16SpHct8HjHbdUy/YP1h+qDJdU28oSdTjkd3I6kLWJpbxJuA2HqC7Cj4AbWDub+++8f8fef/OQnVltbay+88IIdfPDBFgSBXX/99XbxxRfbhz70ITMz++lPf2p1dXX2q1/9yj75yU9ui24DAAAAAIAdGI8Q7uASiYSZmVVWVpqZ2apVq6y5udnmzZu3ZZlYLGaHHHKIPfXUU7KNwcFB6+7uHvEHAAAAAADg3cINrB1YEAT2+c9/3g488EDbZZddzMysufkfX7uuq6sbsWxdXd2Wn73Z1VdfbfF4fMufcePGbd2OAwAAANihbE4hDNMfAP9ZHHU7sE9/+tO2ePFi+/Wvf531s0hk5DPdQRBk1Ta76KKLLJFIbPmzbt26rdJfAAAAAACwY+IdWDuoz3zmM/aHP/zBHn/8cRs79v9/qeWYMWPM7B/fxKqvr99Sb2lpyfpW1maxWMxiMf0iagAAAAAAgH9XJAgCJx8E/42CILDPfOYzds8999ijjz5q06ZNy/p5Q0ODfe5zn7MLL7zQzMxSqZTV1tbaNddc87Ze4t7d3W3xeNzGfu9yyykcmYhX+6S+ZzpQo7/d5aUQ5Sf0tO2apZdPN+rklvjfdWJfJv/tpweamRV0eilkul7Ylp2E98BtN8tl97/007Levr8enNw2HWWULtapU0FM12sf1/sqd1Bv09+vv0nW9/r6p2R9sFIPZu8knRI45nH9hdEWHUxkeQm9fKpCxwHlOOk8VYt1PeWkOg7rKeUmTPVP0NtbtUBHNHXsrvdX8drs5YdKnXTMCTrFq+GPupNlSztkvfnQalkPnG9rpgtl2dJOglr9M/q4Xfkh3c/6x3U7mTznwHWufr2NTmqhk5rlJcCl8/UKStfo5b3+5A3oHwwV6e1q31fPqfKFetwKvUS6D2VHYQ62651YvkSfL0o36L6kSvQYd033rgW67s3xTJ6TTuicF3L0IWGpct1OrFP3J9bhpPI5+2pgjLNvq/X5vfwlPdkiw856i0d3bS3apOdCyVqdett0oE7OrFiu9/uGj2SvOHe1PmmmGlOybgNOat46PQfL39Dn/M7pup2BRt33SEaP5di/6bFv20X3JzVLj2Xxc/rYyu/R7XfsputVLznnBWf54vVOYqeTkDlY4Vwrl+lJlSzX4+yl0hY6Sb7RlK7nDGXXC1t1X1p313MtcP47v/plPQdbd9PH4ZhndPRv/sYuWX/jrHpZ9xIy+8fosfdSi9/8dFt6MGnLbvqqJRIJKysr078UUpv/bfH1Z99jBSXOB6ptINk7ZFfs+7ftckyB7RXfwNrBnHfeefarX/3K7r33XistLd3yXqt4PG6FhYUWiUTsggsusKuuusqmTZtm06ZNs6uuusqKiorslFNO2ca9BwAAAAAAOyJuYO1gbrzxRjMzO/TQQ0fUf/KTn9gZZ5xhZmYXXnihDQwM2Pz5862zs9P23Xdfe+CBB6y0tPQ/3FsAAAAAAABuYO1w3s4To5FIxC677DK77LLLtn6HAAAAAOBfCFvyX5j6AuwoOOoAAAAAAAAQatzAAgAAAAAAQKjxCCG2mjGPRi03b2T6TKxLJ8O0zNX3Usf/2WncSw/r01O69vc6MWbWhYtl/aWbd5P17kl6vY0PtMn6mg/WyHrnzOwElSM/ca5uXIfU2JSf67So7ol6eS8pMbdPt7NpHydpaKlOdPLSBhdccaOsHzz/f2S9dK2eC+276P6MecpJ2ivW9e7c0d23b9lPb2/lSzpZKcdJvCtw0slqFul6+066nQl/0v0p2JDIqqXqdEJYENVjkJik6z3v1fO4uEnPncIWndy05lidHFTs7PO2XXRi1Pi/6PNIb4M+/tMFTgqh7r4NjNE/aHxM16MDTrKlk0I6VKL7GWvTUXg9E3U6WWG77s+E38uy9TY4aanOOEy6Inuc+52+dOyk20hM1NvqJTqWrtZ9LH9dp3vlDOvOd03Xc79rum6/oE3PkYrluv1UsZPc5pxPg05ZdlMR8xbqcStu1gl2vY0xWfdSCNNOWmp/re5Pv3Mu8dIG0855cOxvss8BQa4+foIXneOkQx//PeP1pBos09sUdZIYq50E2OoFeid27F4h62Mf0XO2c4M+htr3cs7tzbo/QdSZm872BrlOgm2zrsdf65H1VR/SSWsDlaNLLh6s1vXGx3p1O9/Un7PW3Zv9wSy+RCfnDlbp42SwWo99yXq9TX0TnGTLTr1vh2cXyXrNQmfuOx9TUhXO+aLXSSfsHTnGOU6S4/YkHeRYOkSP7YWpL8COgqMOAAAAAAAAocYNLAAAAAAAAIQajxACAAAAAEItsIhlzHktwDYQhKgvwI6Cb2ABAAAAAAAg1LiBBQAAAAAAgFCLBEGw/UdSIFS6u7stHo/bnideadH8kVFH/XX6nmmODjKyYR3cYoEXKqYDZiymA2msZpFOdGreRyfJZJyHbr31puI63adiWfYG9I/RGxXVXbSBet12Xo8e46qXddpNxDkDpPN1f3obvIQj3U7F63rnPn7DLbK+y3fny3p+t5Po5qRsvTl9Z7PO3fU4RPv0dpWu0vWMDrZ052bSSVwqXaOXz+/Ry/eM1/0ZFlM2/oZuw0sgG3bS+qJOipTXx/xePTczubr9nGHdjhvu44xx7xid1lXc4vTHScIrbNPxZH1j9E73+umNQ9tu+mDxjnUvsS+vT9fjq3T/156g+5PTqrereGP2QMdX6uN5oFJ3Mtaj15ksd44r5zwyVKJ3ekYHW1p8pV5vblLXB8t0/73lN+3rpPuV6OXHPqCX76/R45CrA+wsVeqkJb6uEyzXHqX3bX5Ct1O6xkmMq3D6X6+Xr3pZ14dj2e0Udupz8lCRHhvvnJ/jpAqmnetzJqrbKWrV/ema6pxfmvS2tjoJtg0P6+1yr63O+WWoRNfLneTMln318uMe1P1s3lcfjIM1evmy150Uwj4nKTjunMidcvVivYM3HJq93jxnfnttF7Q5Kc1Jvfyg03fvc5D3ecS75nrXxCHn+M9PvL1raDqVtCU/vtgSiYSVlek0ybDa/G+LLz11rMVKnBP/NjDYO2TfnPvn7XJMge0V38ACAAAAAABAqHEDCwAAAAAAAKFGCiEAAAAAINQyQcQy3rsatoEw9QXYUfANLAAAAAAAAIQaN7AAAAAAAAAQajxCiK0menKr5RaPjP8p+E2dXLavXn8Fd7hYJ6vkpPTyxeuc5LnDdJRMJDO6tMH8hK7nJvV6e8fqe8T9YhiGZunYqbzndBRj9aw2We95olbW20/W7e9av1HWV902XffHSRTq2EMnE5Wu1WPgpQ0u+ewNsn74GefI+qoTZdmiXXonli/R9e4pTqqjt70T9Xrjy3W9dw+dEpaa5czNP8VlPbpfp6z3bSzNqiV375HLVhTpuLveu+plvbBdj037LJ3KlZym06LqHtDJQd0TdTtjr3pK1gcfmCjr6fsaZD1VPLr/q1l9jI4ty9TqfRjJ0XMkHtfHXOr1ClnPizhJmE4yXM9E59GFI/V+L79fr9ecJNL4hzdk1Vav0Ofwyhd1G6V/WiTrfWfvKeu94500rbF6zmY6dcreYJUem9w+ffzn7Nwt640V+qRf/puxsj5coNtv/oieC5E1zjVogt7enLV6+d6JehyqFsuyeTu9r1GPW3yFPr8P1DqpqE66Wu4JLVm1lh59jYvl68TLdEavs6+lWNYrF+rzS9cuuv3YRB1bPNCiz8klG/TY5yR1P7tO0sdn0Z91gpmXrjigD0VLTNXrLXtdL7/mA3rfVjjHdLrAiUV1JKbper4+5KxkrZ6biYleeqtItmzVbXTN8oLXnTRQJxm2v063U/e8k37ar+sbT0vJeuxFPZdL1ul2uie9vVTX9OD2/7hb2nIsHaLvX4SpL8COgqMOAAAAAAAAocYNLAAAAAAAAIQajxACAAAAAEKNFEIAfAMLAAAAAAAAocYNLAAAAAAAAIRaJAgCL5IDeEe6u7stHo/bnBOutGhewYifuWl9jTrVprBNJ67kJ3RqTuseOuWsdK1up2Nn/dXfhid0OlHzfrr9slV6uwbjb/+rxTWLdBrdcJEem1SprvfV6/vS3ljGErreNVU/YVzxmo5EGozr/nhjXJwdcGZmZuUrdPsP3/5jWd/vwnNlfahIrzeT7+wT50yYrNJ1L5HSnObzu/UKvPFv3UPvx9oX9fJ9Y7KXL2rRywZR3cm0DtOyVKlePqpD+VwFXU6C0gQ9dwLnv1gqXneOz310O+nC0V3m4sv19tYs0LFZ3VOzEyDNzIaKdTul6/UcT1bqY26wTLfjjU9+j97efjFHzMzKV+jxHC7IXt5LaPXOO14fq5foMegep1dQ0KW3qXuCXkFBm14+7aTj5Qzp5SN6ytqwc36JDup2StfrMW7dzbmmrPaOXd2fHN28JSt0P1POtanidX1tHSzV45wz7CQF62b08s7hOVDtpHKu1RvbNU2PZdUSfaJaO0+f8MpW6f7EEs6cynPOpzrM1AYr9fJ5znGbqwMs3X3obW/ndL29xZu8BF69E/vq9DhHU7r/BZ16f/XX6mPduyZ2TtPLl67PXt4773jzNeNcE/O79RgkJukxKN6kl/c+4+b16v5455HEFOccvlyPWXHTyJTD4eGkPfHEFZZIJKysTKdehtXmf1t8+skPWqxEj/+2MNg7ZD848J7tckyB7RXfwAIAAAAAAECocQMLAAAAAAAAoUYKIQAAAAAg1NJBxNIhSv4LU1+AHQXfwAIAAAAAAECocQMLAAAAAAAAocYjhNhqys9YZ7nFI2N4mu6aKJctW6NTagYqnXSycidtrECWbdZnlsr6q9/dWa+3xkm7WeOkBDnpil4KkUp1W3Gakx64SqetJGt02k1hs15n9TlrZL08f0DWM9+aIeuJybo/3VN1Cs6Yp5z0sPF6e1edKMtu2uAz194k61N/+SlZH/eQTj9rma23q26BXt5LIUrFZdnyenR95y8vlvVl/283WZ904Suy/vQT2XN54HAdX9VQoSMUO3/bKOtlTuqXfbZVljcldCpf/0JdH6zQc2T8X1OyXnBxk6znPjhR1usW6GPFS5hr3k+fXwaP0sunUnqch1NOquBL+kQVX637me/MHS/xsuRsHfGZ8yO9fzftpbe3Yd+NWbXAeVwi59Yxsp7fq7cp6ZzDu6fquTDQo88XmTy9fLJG10vW6P4npuvlgzE60a3iMb0Ph52Uw5Y99fliYLw+v/Q741C2WCfJdc/Ux2hBk/Mxz5k7/TV6nOMr9LHYtpu+yOX26/5XfCR7TrX2FstlG8p06mfHQJGs9yzXkbH53XrM3OTGeXq9PUN6zpb/Rfe/63Dn2tqpx2zM43qnRJyUxpSTTtq+i24/vkpvcMueeo4UNeu54KUxegmliYl67uc5cyTlJF4WOsmiPeOyl/dSCGNOmmk65qQWO2F3gbOtMSdxsWRNn6y//mm9r8pe1HXvWuBt79p5I9vJJAOzJ/Sy24tMELFMiB7bC1NfgB0F38ACAAAAAABAqHEDCwAAAAAAAKHGI4QAAAAAgFALghzLeM9MbgNBiPoC7Cg46gAAAAAAABBq3MACAAAAAABAqPEIIbaa15eNtZzCkUlNxTqsxzbt7aR+1eoEq4KNXmqOTph5YuUUWQ/21v0pXa1TRbyEuSCqly90+jNYmV3P6XaSD1frNoZ3Sup1LtIJTcsWTZD1IF9HsZVM1vvEu+2dl9A/SBXr/uf16nq0S4/DUJEeYy9t8I2P3Sjre67Qy+frYD7rrdf98b41XvmKnrPrj9Lb+9hfZst6zk66/fVLdDpkUVf2+PR36KS0la2Fsl5Y5aVgOZeK39bLcjBWL16zSCeubThYt58u1HNwRUu1rEcK9Bg37zu6uTxc6sQTLiuT5YyTNprTqFPIhvUhai2zdYdK1+rlI3qq2YplDbJe7CR/mulxW70+e5wLVumNLdABcFa0SafX9e2k470Wn3y9rO/2m/NlvWSNk5TWpfszVKK3dbd9Vsh6Mq372dk7XtZz9Oa66Yp7z1op62/8Yrpe7+465SzWoo+hfB2o56YQOptlqbje795cLl+hJ+fqxdlzM3AOz9fL9XnKevQ+iXXouTDk9HFonL6Gptr0L0SGdfs9E/Vg5r+i23HT+vTHFCve4KT+OQl5PdP0HIkm9UAnxzhxjBHnvOwk9g04yZ+eaEqPp3de88LeilrEep1TeM8kXR8u0b+Q26dXWqADeK1td+f82KaTMPMKdTphX4Nefsxzup9dU/W+jXWO/Ht6cPtPzEtbxNLeCWwbCFNfgB0F38ACAAAAAABAqHEDCwAAAAAAAKHGI4QAAAAAgFDLBGYZ73nSbSAzuidnAbwL+AYWAAAAAAAAQo0bWAAAAAAAAAg1HiHEVjPlzgHLzR353dpktU5F23iwTlCJL9NTNGdIf2e35yCd+lXxN51mlNBBTzZYoeteolPOoFN30nRiHdlff460669E5/XrRvJf0pGOfY16nY2P6fSavF5db95Ht1P9sk4sWn+E7n93rpNOWKm3q3yJ3ucZHcpj4x7SyXZe2uCLX9fphLOfP1nWO9bq6MncXr1dw8VOGtAmWbb4Cj2X0872Vi/R4xzrzJ77qcU6pipd4LWhJ3Jiku5MLKHnTu1TOtJx45GVsl65VI/BQKUey7pf6fNI93i9XUMlsmwR56v/hU16vcXNenvLVuokqd4JOoWsZ5xeb/FGXc9N6o4OFevtrX9C15v31/2veUGvN3g9e7/nDOk2vL50ztCpXIWtepsOvPKzsl6uD3OLBLqdVJnuT9duuqHCH+gIuOig3t5NR+j1VizV6y17Q58vlrTqVNFoqSxb2evO+dFJ8htykn/TTmJnYbPuf1Grl37mpUDqca59Pns+eCmEsYSTrNilox6jSX1t2rSvHsygX7df86zuUGGbvmblDujzZsueeu5HnPTAWKdznJfqfVJ37Dpdv1RHgn77FzfJ+hdO1dfKxBQ9Dl1H9ct66SNOeqOTCNg7Xm9v6Xq9fPteuqH4yuzxKdqk51/XLD343vFZ3Kz3ec84PTYFbXqbkk7Cb+4ifXGqXqzn8oaP6u2KrNPXxKolI/uTTjk7YzuSCXIs48VAbwNh6guwo+CoAwAAAAAAQKhxAwsAAAAAAAChxiOEAAAAAIBQy1jEMhaiFMIQ9QXYUfANLAAAAAAAAIQaN7AAAAAAAAAQajxCiK2maW6JRWMjk1EaH+2Ry8badUpQYZtOTOmv0/deS4qTst5Xr9NxCptl2bxQkcFyXR9/v04hazpAR0DlihCf7ulOQthLOo1msEJ30ktW23iQ/ppzkKvTdOof1+k7XjJcTspZsSPap/vfPcVJeluhl2+ZrVOF8nUQnps2uHDv38j6nn/RCU1e2mOODsiyfCdFreUw/QsN9+nTc+seul4l0gmHivSYtR2pj5PJN+t9mDug690T9VzoHavTBr2xSZXouVnQqedC6+56DNRxZWZWuk63E3FSQlvn6Hr3TN1ONKXPL93j9fh4iZpeqmMQdR5RcAKlNjkJovldzjkj4yTtHZg9QJECPWiN9zrpeM6nDC/Fy5trPZN0O7n9emy8MY4M6jHomqLr6ULdfn6nrqec9EAvaS81SyfnppP6F8bfo/u54TBn36Z1P9MFzuTJ0e00/na1rBd0jJX1/lq9A9o/kH2QDif1Obx4qU7xG6xw0kkX6G3y5mCOMxda5+prbnyJ7mfdc/p8OlDnpMBW6vaDFXrMBqv0du1Z3Cnrzev1Pj/h2f+R9TFx3c/4Cr1dXWv0+a7yFb18Jl+Pc3+d3r/FLfpi2dui+9lfl12reL5DLlvYXK/X2aTPa3m9up6K6zk49q61st5y5HhZH9SXSstP6DGIl+nPmoNdOmk7N/mmueMkeG9P0kHE0kF4HtsLU1+AHQXfwAIAAAAAAECocQMLAAAAAAAAocYjhAAAAACAUMsEOZbx3vOxDYSpL8COgqMOAAAAAAAAocYNLAAAAAAAAIRaJAiC7T+SAqHS3d1t8Xjcjpj1RcuNjkyZ2XhElfydyBE6MSZ4SEe05PXoaZvRITVWukGn/qw5TqeHlL2mn64t3qjTgPoanJSdet3PYpESVPmqjmjrnK6TiSLDuu18Z2yKm3WqTXRAj83KD+lUm4qlesxynES3lv30D8qX6jHO63NSyMbr9dYtcBKL6nX7HXvofVi+VO/DF79+o6zPuUynE/bqsCEbLtbbNfXXOlWoeX8dZzbmaZ3kqZYvatXbWrpGp0U1zdXpUn1jdTtTf6MT1CJpvfyKk3QqZ92zsmw9Y/U+GfOsjhvccLDuvzc3M04yXO2LTlyiIxV3zhcb9Dj31+v0rf5qvb3DRU7SnnO+q12o+7/hEP0Lpat0OzULsqM8I0N6MFecos/VUSclsHqpPu/0V+mdUv1it15+vJ5T/bXOznXEEk7S5ni9T6LOFBkq0fWiZt1+6VrdUHRIH0OJiQWyPqxP1+45IOmk2FYu1cfW2qP1sRUd0Pu3sEVvb9XS7PNdskZvk3eNK361RdYHJ+rPF0PF+vhcd7Tue9ULemyKWvTc75qm24916v5HB3W9+TDdfvXTuv3uybJsRc16uxKzvGux3t5Mnm6ne6puJ8jT25XX6SQXT+2V9bqf68m89hhZttye7ParFum+tBzpfA5q1p+zylbqdQ4d0yXrwwsqZH1goj7OK5/T5+RUuR77XP1xwcwJwivZMHJfDQ8l7bk/XmKJRMLKysqcxsJp878tTnzoVMsvdmJmt4FUX8ruPOLn2+WYAtsrvoEFAAAAAACAUOMGFgAAAAAAAEKNG1gAAAAAAAAINf1gPQAAAAAAIRFYxDLeS7+2gSBEfQF2FHwDCwAAAAAAAKFGCiHedZuTQsZ9838tp3BkutCk3+vkqY0H6VSunMHRrTtXh6JZ4ARSDetgJctxEqbSupuWnx3WZWZm8TV6e3vGZn/5MVmt26haohN/WvbU958rXtXtdM3Q9cC5jV32hq4nq/X/NuU56Tg5KX2KGS7W7fQ1vP3kRjOzHD3E7nb1O+1HnHZK1un6C5fpdMJZt8yX9XT+6JIzaxbq5bum6Q0rWZe9fPcU3XaqQs+pqb/WCU2JyTolLOMEAQ05+7bQSUTrcZLeql7RO6V5X31Alztz3+un6e5Y105OmlaP7qd3nkpVeO04/2PrXI1jnbo+qIP/bLjIOYbW6fUGznexeydkD1BOSrdR/5SeU16S2UClHstUmV5+sFJvU6xDL9+zq94pxa/qk3iyRk+G4nXOPneSLfOdNMPEVGfsc/TyaX3IWWGrbidZpdspf023413LkpW6/YJ23X6yRi9f+6I+l6jk34gzp3J7nQTIpJPK6ZxjY516+d7xep9HB/XypU4iXfkb+gND6x56kHun6vNa+WInzdRJP2zeX/ezZI0eN+984c3Boo16+d4Juu59ZhioHV1ysXcMeQm/dc9lN9Rfo68Rg066X46erjbkhMrFdHC2RZO6795n0MQ0XW983Em8nOIkUs7Qc6r6+ZErTqeStujnF2+XiXmb/21xwkOnWV6IUgiH+lJ21xE/G/WY3nDDDfbNb37TmpqabOedd7brr7/eDjroIHf5wcFBu+KKK+wXv/iFNTc329ixY+3iiy+2s846693YDGC7wiOEAAAAAIBQywQRywTheWzvnfTljjvusAsuuMBuuOEGO+CAA+zmm2+2o48+2pYtW2bjx+s7tSeeeKJt2rTJbr31Vps6daq1tLTY8LDzP6/AfzluYAEAAAAAsJVdd911dvbZZ9s555xjZmbXX3+9/fWvf7Ubb7zRrr766qzl77//fnvsscds5cqVVln5j69STpw48T/ZZSBUeAcWAAAAAADvQHd394g/g4P6MfZUKmUvvPCCzZs3b0R93rx59tRTT8nf+cMf/mB77bWXXXvttdbY2GjTp0+3L37xizYw4Lw3BfgvxzewAAAAAAChlglyLOO95HQb2NyXcePGjahfeumldtlll2Ut39bWZul02urq6kbU6+rqrLm5Wa5j5cqV9uSTT1pBQYHdc8891tbWZvPnz7eOjg677bbb3p0NAbYj3MDCVlP/uFnum15Qve5I/eLFwk26jbxe5wW3sdE9c17YpF/W2levL4Lei769Fwbn9TsvHa3Xb+6MDGcv741BssJ7abdevmeC7mPFMj0G3li6L/Nt09s6WOG8HNV5ibP32oD4cl33Xrifiut65Sv6JajDxXqfeC/u7x2vt9d7Wfsr/3ODrM/8kV4+knbGM64HKL9LluVL6yuX6rZTJXoM1hyt6wVtui/DhbovxRud42Gcnss1i/QbdDftrd9wX9Cq1ztcqNdb0Om8WNf5DBxr0z8odOZ+Ybs+toYLnBeMj9d1b9z665xjyHkxcNViZ/wbnZdlJ3U71S9m14ZK9LLJCt0Z73xUuMl50XyzHstCZw6WrtWdHy7Sb0FPO3O2oNXb57o/XdP18t5L672XPhe16nHonqDbjzgvvi5zXjA+XOjs8wG9Xu/F2mlnLhc1O9fofN3/yhez697Lub1rgffS8e7Jevn8br185RLnZfDOJ+OY007LXvpl7Xk9up2iNXoFUSfwpKdRH1vetcALAMjt1fWcIT0OESfjyQuhGKwaXX/ynfN4fo9eb3y5Xm9/bfb4eOf2Yef8ldet6yocxcwsMVUvX9TkhNM06nbqnnfm1Gw9R7zAoKoXnM81b7q0Bs7L6vHvW7du3YiXuMdiTlLG/4lERs6VIAiyaptlMhmLRCL2y1/+0uLxf3zove666+wjH/mI/fCHP7TCQufCBvyXCs8tbAAAAAAAtiNlZWUj/ng3sKqrqy0ajWZ926qlpSXrW1mb1dfXW2Nj45abV2Zms2bNsiAIbP369e/eRgDbCW5gAQAAAABCbXMKYZj+jEZ+fr7NmTPHHnzwwRH1Bx980ObOnSt/54ADDrCNGzdab+///zXK119/3XJycmzs2LGjH0RgO8cNLAAAAAAAtrLPf/7z9uMf/9huu+02e+WVV+xzn/ucrV271s4991wzM7vooovstNNO27L8KaecYlVVVXbmmWfasmXL7PHHH7cvfelLdtZZZ/H4IHZIvAMLAAAAAICt7KSTTrL29na74oorrKmpyXbZZRe77777bMKECWZm1tTUZGvXrt2yfElJiT344IP2mc98xvbaay+rqqqyE0880a688spttQnANsUNLAAAAABAqGUsYhkb3WN7W9M77cv8+fNt/nwd7nP77bdn1WbOnJn12CGwo+IGFraannFRi8ZGJqN4qTm943XSU0GLfso1r0+3k+Ok+KRK9QVmYIxePuqkcuUnnMSl93XKes/yclnP687erkyebju/W/f946fpC9m93zhC1rsnju6J4f5GHUdV/bKuD9TqhMmCjtGl+PTuMSjrVY+OLulp/VFOkqST9pjvpPMMFztzZEAv76UNvvoJnU645/9+StYHap0USCe5qfNQMWlb9ZiVrnSSbmJOWuc4PQbTb+2S9VUnVsh6+Wu6/RyRymlmNvZRPcgbDtJfmc9zUra8tFE3hdBJLSxq0XO/aX+dAJV2UhHdpE0nrSu+yjnmKvUGeMd6/zQdtVn+oj52e0QSXuNj/XLZde/RMaHj/6IP0J5JxbLedLje1txOJ5WrRydVlqzXY985U5Yt2Tgs633TdTu1j+n1eue1wUZ9gulvdZI2ndTCnqm6n8VOsl3xBt3/3KSTSuukB3bN1eflIKWXL31FzymVLFzQ7qTaVcqyn8S4ytlWJ3Gx+VDdUNEavU8699BjH3WuQakyL21U1725M+Y55/ivco7/Sbodb5x7Zut9m5Ov1xs06xNV7Sx9cYpFdTsbF9Tr5btk2Qaqdf9TFdn7t9h7r/XOzvmoQ2/TQJc+riL68LGu2focG8nTv9BcoI8Ty9HLF23SYzDkfMZNvikZMj0Ynhs/APBO8Q4sAAAAAAAAhBrfwAIAAAAAhNo7Sf7bmsLUF2BHwTewAAAAAAAAEGrcwAIAAAAAAECo8QghAAAAACDUeIQQADewsNXM+ODrllc8MmFl7feny2VL1+g2Bst1etBQsb5g9DXodo464kVZX3TVHrLetqtOFRvW4WcW/2lc1qOVup9BNHu7Bo/qlsvmPVAm6zc9fais5+6p13n4oQtl/bD4q7J+y3kfkvW23XSyXf8EndBUs0jvw0yePv2kZukIyFhCJ0Pt/OXFsv7YX2bLenyF7k/LYTo9aPqNur7ihBJZj6R1+17a4IuX3CjrR5x6tqwf9p2/y/pPHjo0q1Y0Uc+pK973e1m/9qJTZb2oSadUrb1cHyelsXZZ7+utlvXWvfRcGPeAnsu1B2+U9abndKpV/A29T8wptx6sE+MO3uMlWb9/xSxZH1+ZkPWm1rGyHl/pHCtRPQ75ItHNzGz/T+jz3fPf21PW0wW6nUvP+FVWbelJuu/d1x4k6wMN+qTZX6e/AJ7fpre1YrZOONswRp97Y8X6uC15pFTWE8W6P4UNOtpyqFifjype1WPZWqTneLpeH1tT9t8g62vumiLrdqSOLex5Tkf5RQJ97HrpajO+pdMnV39It+8l+V79pR9n1f7UtYdcNpajrykdKZ1g+cQqPTYlj+uEzIiToHjkh5+T9Rfbxsl6cHOtrHefpo//6n31nCq4tVHW23fS+ypVrndW8Tq9XfE1ejx7J+m5WfWsTsjLHdRzPHiuRtbbx+v+FDtp0kN691rJBr29A4PZ7Xv3FGKP6+O/pE9vU3/d6G5OTLlDHyeZfL0PE5fpa3T6Lj2WXjpxYYvu/3DhyOVz9GkRALYrPEIIAAAAAACAUOMbWAAAAACAUOMRQgB8AwsAAAAAAAChxg0sAAAAAAAAhBqPEAIAAAAAQo1HCAFEgiBwcpiAd6a7u9vi8bjtfuo3LJpfMOJnb05E2cwJRLKeiTp1pnS1/vJg7Qs6AaavQSfntczR7ZSt0v1JxZ30w3FpWY+/4iTP7Jy9fOVLui8DNU4CWZcsW+VrOtUqVTa6+9XtO+u+5znJQXk9+lQyWK77X7JR79shZ470TNTrrV2o2/GSm4qadT9jCd1Ob4PTTqteftCZI156UMOTen899PNbZf2Az35S1pv3z26//FW9zvIVOoooMUmnTqXKdDul650xKHX2eZNOwUpW6DHunuwk1XXJsg1W6PpQqZOaJdJAzcxqXtDtlGzU49bbqMetd6zuf54OnrKuvXT7hSt1+4NVevwbH3X2S5ke5/4xen8VN2W3U9SsExpXf1CfX0pWOOcRJ0HR60u+M2Y1i3Tc3XChc+6drNMDB3WYoeX36Hrpen3OT0wc3fY6QXtW7BwrGw7T4zzpHn3t628okPX8hG6/2zkHdM7S/a9YqvfXcJGu17w0kFXrHauvzxHn02lBm56DiSm6717yWkZPBSvepPdtf7XzQcX592vUWW805VwrnfNsfKVuaLBSb0BmtP817Yxz90R9/qpYrsfHu+bGOnX7pRt0O11TdTv5XbqjBaLu9d1rw5Mu0Puk/vEuWV97TLluR09xK9yk6xHnn2bly/VcaN7fOYbeNMTpwaQt/9ZXLZFIWFmZTrgOq83/tjjyvk9mJZxvS0N9KXvwmJu3yzEFtlc8QggAAAAAAIBQ4xFCAAAAAECoBWaW8b72uA3wGBPwn8c3sAAAAAAAABBq3MACAAAAAABAqPEIIQAAAAAg1EghBMANLGw19aeszkoKWf27KXLZko06jaZ7ir4w9I/RT51v2qdI1o8/4zFZf+TSA2Q9MVEfGrk66MmqFuovM0bSup/Fq7NTdhKH6cbzluptSs/T0T5rJ5bL+vg9N8j6/PGPyvrNp39Q1tfNK5b1nsk6+WzCn/S+bZ2tU2Si++ntqv2pTneZdOErsr5+yQxZr16i51TrHnqfj79Px5CtPbpU1r2EvIJWXT/sO3+XdS9t8O/fvVnWp9xxblat8qT1ctnj61+S9V9efqysV7ymk97WzHdSQkuyk8bMzIZv1zGBLfvq42TyPXq9+33neVm/546DZL36Jd2+l3LWfKies2Nm6GNoU0eVrE+v0jv9pcWTZT1/o04V8xL48nr1eafos+tkPX3TOFn30mE//JUHs2rLehvkssnv7CzrJev1ea1950LdziSdyllQqeNPV87W58eIE+9X9Td9nHfvp+daba0+H2VuqJX1wjY9qVoO1cl5kag+htr6nGuQk4q46oN6HErW6n07VKTnTrJKLz/9p12y3nSwPqa9hL9jb3okq/aX5l3kshUFeu5MLmqT9T+u1u1EniyX9b5xeuxnnL5c1tuT+trX8Ut9XPUdrw/cvk499yf81kk5btDXyiG9y62vUdcbn9BzcNVJevmKBXon9tfouVO6dnTJogNV3hzU7ZSucdoX/emd5Bz/L4wuSdKbxxsPLZf18fd16eZTuj+brtHtDz1SLeuDFfq8UNCqx6Z76sh6JqnnPABsT3iEEAAAAAAAAKHGN7AAAAAAAKHGI4QA+AYWAAAAAAAAQo0bWAAAAAAAAAg1HiEEAAAAAIQajxACiARB4OQwAe9Md3e3xeNxm3DlNyynoGDEz3J0uJcVNukLwLAO/bGoDqqyitd00suGQ3TyzNiH9fIbD9L3dgtbdT93P3GJrC/YMF6380B2gl23Dmi09Bi9sTl5Ok2m+DkdTZSs0Yd6xgnlqXpZL9871klcdMJtxv6lQ9ZXnVAp64M1ep9UvKw72jNJrze/S++rhr/rhLyBGp301NOo15vfo8cncL7X2nmoTjmz1piue2dm57PSipNuyqpNfvAsuWxsRYGsB85cKGrSncnVQ2nts/XylYt159N66N3zRY8+rCyS0e17aYOZPP2DCffpDWvZUx9bidkpvQJnvVVP62irvrG6/176adQZ//4GveLhEn2QFmzSO35gfHZqWf3DetmWvXRf4sv1NhVv0ju3bWd97g2c/27LT+h62Rrd/kC1PkCHC3Q/u6fpdsb/VY/lmg/o/hSu1fu80EkPS5U5iXRj9XrLVujtKm7Wy+cM6/XmpHR93VHOiccp5yT1DwrasvuZcfZtqlz3PT+htzWmLzUWX6XT95rm6hVHB5y+79su68lndQppzhw9OQv+ohN1vXGIOOfBmhd0yuHa98ZlvfExfSJ54+P6BLz3Litkff0Ppsl67adWyfq6bt2f4Yd10p6XQjjxTzqJdN0Xs+dJOq3nSLBCf6iMdep93jtFfx4pWaF3Vt94vbMiad1+kOMdh3r5iX/W15r+Or0Pmw4b2Z/MQNLWf/ZSSyQSVlam52FYbf63xcF/nG+5xc7npm1guG/QHj/uhu1yTIHtFY8QAgAAAAAAINR4hBAAAAAAEGo8QgiAb2ABAAAAAAAg1LiBBQAAAAAAgFDjEUIAAAAAQKgFQcSCED22F6a+ADsKbmBhqzlg/6WWXzIyGeXxx3aVy1a/rJP2mvbXSSOxDi+5SX+pMH9Sj14+XiLrlcucFC8n+OSZx3bW7SzR7SQrsy94w5U6KSmnXafLlE7pkvWM6aS0YIpO8Nl/wmpZX/HCLFn3EtG8lMNUnU79ib/hjM3uel8VPaTTXQYO1x3q79BJe6nFOg1sqEjPnaJWnYTVsbP+0FK51Imec9IGiybqJKn8v+jkpsqT1su6ShxceeRtctkD6j4k671/HSPrpRt0slLLHH0JqZ3RIuvJN+pk3Uvfqn1Sj03VyV2yvuleHU+YMzS6sN21RxXK+uBYnQD12Huul/WPLjtN1ntL9Djn6alvRZv0HExWOue7GXrc6m/Tx2LfGD0+8QOyY92aDtWJa2Wv6p1Y86LeqM6Z+tybbNBzLVarj/MBJ91rYIze1nwnbaxvmt63JVV6vXnd+niufVKfd1oO0e0POCmq0U4njTFfz4XuqXofxjqd1Fh9GrQhJ6Wx+gW9fM9EPZ6ZqJOutl9n9rLDOtmyukgnt7a2Z6f4mpkN9OqNKujQ7XtJb8lp+vNIsZMYF3VCSHvb9LW4fw+9D6f+Sq83Vaa3KzFDj8NgjW4/E9PjUNGg0xJfenK6rNf36WP01Ud1lPJgox6g8W/ohL/WEj3323fWx3TR/WLZObqPdc5nu5QeSitdrvsS0V23qhedzxFtuj+tp+vzy/DrukNDxbo//TXOAzX5b/pcmXbiogFgO8IjhAAAAAAAAAg1voEFAAAAAAi1jEUsY+F5bC9MfQF2FHwDCwAAAAAAAKHGDSwAAAAAAACEGo8QAgAAAABCLRNELBOi5L8w9QXYUXADC1tNVazPYrGR6TMNT+gklsRknbSXp4PzbLBCXzC6dUCWHTlhuawvGtxD1pMV+suJqbhe7/j7dVpSX73eLqVyjE4CKniwUtYTE3Wi0MAEnTLzoekvy/oJFc/J+uULKmS9/+hGWU9N0AlKQVSPZVqHdVlF0YCsD0V1Kl9DhR63la06SS5doPdh25F6H065SacWNR+o922qRO+X0pV6vVe87/ey/t0ffFTWj69/SdZ/8NhxWTUvbfDvu90t60d882xZj2ScxMjxeq4V5elEzeE+3U7bPvq8UP93PWbxmJ4jG505Vdyk+5mjV2udu+p+Hr3rElk//iU9bmUF+pgY0gF8VrTJSW7Tw2l5vXr5D0x5SdYfyT1At9Ov2/nuzN9k1V6aOEEue+vfPyDrltFjP6QDxSzI1ctXleqLQVu3bmjC3utkvfWucXrFlXpOTajITs0zM9uwm44PLG7WkyqSdBLgxuv2Cxt1zFnfn5wEy6NbZT3RWSPrOcP62Irp7tiY+9bIevIkPR8K2nQ7j57506zadR276YUdnXU63e+BtTNlPR3T147keJ2Od+6cx2X9sbZpst77ermuz9LHVf14va9a9tT7NqW7b0Mluv2S1U4yZK6uJxJ6PMc/ok88ySr9T4fGx/X5LjFJXyvbdtX9KWoeXdqjegVR7dP6eBvWHwssx0kVjOrTgg06nzXH/lYfJxZzPi8U637aEn2R6NhJj32sXY9Z5dMj15tOZUznGAPA9oNHCAEAAAAAABBqfAMLAAAAABBqQRCxIESP7YWpL8COgm9gAQAAAAAAINS4gQUAAAAAAIBQ4wbWDuzqq6+2SCRiF1xwwZZaEAR22WWXWUNDgxUWFtqhhx5qS5cu3XadBAAAALDD25xCGKY/AP6zIkEQ6OgK/Fd7/vnn7cQTT7SysjI77LDD7Prrrzczs2uuuca+8Y1v2O23327Tp0+3K6+80h5//HF77bXXrLS09G213d3dbfF43PY88UqL5o+MBTv6Qp3u87ufHirrg5V6eub26QvGuAd0Il3PFN33zun6Hm7lqzpJaqBSL9/XqPuTKteJWoWbstuJr9DLbtpXlq1she5LzUKd1tU7TsfvRJwzQMcs3X5er9OfNc6YVTkphPl6zHKTzj4f0PVUiW4nWaXr9c/opKScQd3/5v11QtOYZ3Q80ZqjdRReJqb7P+ZpJ+GvXI9bfo9evmOn7OVjXXJRq16sx+Chn98q63t9/VOyXrZax0JtOFQnLpXoYDg3TW/QGYOcIWcM9tD7sOx1/brHwAmAinU6iU5L9OTfeKg+v+Q6Kareer3tSlbruZyvT3dW3KTHIYjqdjbto9uZcH92NFdsox6Dzt3LZT1VqtcZ5Oj6sJNOWLpWnx+9hMzS1f2yvuZova8KW50ESCedzHR3rHe83i4vSbJqmd5XwzGnndNbZL3/jzrBzhNNOdvrJL11T3HaSTrXvjLd/oT7s889XVNictmIM8bDRd6c0suXr9CD31uvzwte2l1OWm/T1664Xda/Pf/jup2U3rCm/fW1o7DNSeXTwblWdNpGWc98t07Wm/fTJyTvc1ZBh+5Pz0Tdn+FSvb3lS/UO89op3qD70z8muz/e55qIkzybqtR9zEvoPnr3LNzzhSMnpRv6zTnXyfqFH9SJt5vm6qjKgdqRf08nk7byqq9aIpGwsrKyt9/RENj8b4u97r7Acov1OWNbGO4btAUfun67HFNge8U3sHZAvb299rGPfcx+9KMfWUVFxZZ6EAR2/fXX28UXX2wf+tCHbJdddrGf/vSn1t/fb7/61a+2YY8BAAAAAMCOjBtYO6DzzjvPjj32WHvPe94zor5q1Sprbm62efPmbanFYjE75JBD7KmnnnLbGxwctO7u7hF/AAAAAODdsjmFMEx/APxn6e9P47/Wb37zG3vxxRft+eefz/pZc3OzmZnV1Y38mnldXZ2tWbPGbfPqq6+2yy+//N3tKAAAAAAAwP/hG1g7kHXr1tlnP/tZ+8UvfmEFBfpdC2ZmkcjI/00IgiCr9s8uuugiSyQSW/6sW+e86AYAAAAAAOAd4BtYO5AXXnjBWlpabM6cOVtq6XTaHn/8cfvBD35gr732mpn945tY9fX1W5ZpaWnJ+lbWP4vFYhaLheeFigAAAAD+uwQhS/7jEULgP48bWDuQI444wl5++eURtTPPPNNmzpxpX/7yl23y5Mk2ZswYe/DBB2327NlmZpZKpeyxxx6za665ZtTrq1jQYrnRkTe2/nDDIXLZ4WrdRtUSJ3nOCURs20MngNQ826l/IdDJLR2zdCqPlxQ4OOAkRqX0lxyLmrO3q2S9jhTqq9cpeHl9emzWH6ZjvMY+4kSiOd+u656o1+slH5Ut7ZD1nvfWyHqu0//Cdj3GfXV6LMvW6tifSKBPb4lJOiHPSznsG6v7k5isv8VY0KbHs2+cbr+oSScCdo/X41/xmt4ByYrs/pRu0JFLXnKblza44IobZX3X6+fLeuUyPWadM/Q+HPuIHoOeCXqMx/5NJ+HFuvXcT+fr7c04V8DooJOyNVm3X7JOb2/pWr2vWnfX+7bESQ9Mx0aXoljUrGPU1hyrx7N0lZ6zsU3Z54ygQPele7Let7k6DNCGnLRBdW40Mytu1nMkt12ngXbP0uf20jW6/SEnLTHHOS94aWZ5zmk2P+G1o+uxbifB9it6H+ZM0h3KGdbtDxfq/dU9wfli/sweWY68qC/GOc74mBjm2mf0tcOTbHTW6aT7bdpHj1n5G8750dknPeP03L/sqjNlPbm7nlONf9Pxock6fW1KxZ3U5Yd1umLfzxpkPaMvxZbXq9tPO/8vmcnTyw9V6Gtxfqs+UaXKdDtjntH7xTtfp8qy2893XsXaPVW37SUi9umhtKIWJxFxrj4BvGfqa7L+xvkzZP28pZ+V9a4j9FiOeV6fB7umjJz7aSd9FAC2J9zA2oGUlpbaLrvsMqJWXFxsVVVVW+oXXHCBXXXVVTZt2jSbNm2aXXXVVVZUVGSnnHLKtugyAAAAAAAAN7Aw0oUXXmgDAwM2f/586+zstH333dceeOABKy11vvIEAAAAAFtZYGZBiL5IFqKuADsMbmDt4B599NERf49EInbZZZfZZZddtk36AwAAAAAA8GakEAIAAAAAACDU+AYWAAAAACDUMhaxiEqD2EYyIeoLsKOIBEGYniTGf4Pu7m6Lx+M24RtXWk7ByASUqsX6RF/9yDpZ7zhwrKx76TXdU3Sfhkt08szk3+l62646fqegQx8u5a/qVLRkbaGuV2QnyfSP0duUq8NlrPwNnUC05mgnmiyq+x4U6DEY9yf9Bc2OGfq+d363br+g01mvc81POGlmxU1OOtnJTbLe89t6pz86qap7oh63+id1qlDHLjpJrr9Wb9iEe3XS1trL9XrL79DvnWv9oJ4Q5fdn96dnku5LcrxOqZv0Kz3GrXvq4+HlC26Q9Rk/0WmG0aTuj5emV7bS6c++Turfct1QxXJ9rHgvr2jeT8/x1ASdhBdb4STDOav1lK3R25Uq8VLCdD2xk04Da3hEH1uDTsqZOp/mT9fxXvHf6PmaKnb2ufffZ84+GSzX7WTynGac9os26hUMVun2vdRVL6HNSxvsr3fGwfke/GCt3of1j+lf8BI+87t0+8NOCmSuk6LoHUMDVXqgk5V6e3vmZA9o7no9mEOV+tqU26WP86g+rVnhJt0XL8m3fTfnWtaqx7h6id5Xm/Z20vfK9XE+8wdtsr76pDpZ9+ZyrpOiGks4KcplersK2/R2xdr0NSglknDNzAYr9UFaulwnW3btrM8l3v5VnyVG+zkivkof6AM1OhkyoofScvudc7hISjQz6xvj9LNZt9O2m57LJfojtGVyRy6fTiVt6S1ftUQiYWVlOrU7rDb/22L3337BokXOCXgbSPcP2qKPfHu7HFNge8UjhAAAAAAAAAg1HiEEAAAAAIRaEEQs8L7Cvw2EqS/AjoJvYAEAAAAAACDUuIEFAAAAAACAUOMRQgAAAABAqGWCiEVC9NheJkR9AXYU3MDCVtO4S7PlFo9MCmnqb5DLFnTo+psTVLYs7yTb5S7Ry7e/V8fX5KT08uUrdPqOl9bTfIBOzfFkxJGXKtPblM7XfVx3qu5j/Cmd+NN4wipZr4zp2KlXn9hZ1stW63ScgSonyahFj/1wsU7lSU7TaVfFTToNaFNCj32gAyyt9qmErPeOrZT1SFpv75CTrlbsJEOtOrFC1ktj7bI+WKrbLy3RCVDts7MTL2tntMhli/L0GK8/tFHWK5fpMfDSBl8780ZZn/u5c2W9ZW9ZtlwnAW7mTjpyadOiCbKeyXMS4CKjS7aLOEmeVXObZT0xoFO58v8Sl/XcAd1+Xp8e/746fQztutNaWe+5d5ysp4r1R4Exs7O3a32znsf5TopfYZt3/OjzRWKaLFuqUp/vvHRVy9H1yLA+jww06sS7vBp9vFX8UaeQ9tXr7crspJNqhzbppFrL0+PWsZPe54ON+jxb0K63N+alw0b1fvT2V3+dXr5vgh7Phtqu7GXjuo/dPXpscqv0Pkl26eOtcqkes+a5smy103QaYGKc7k9TWYmsZ/JHF/K96dBaWS9d43w2cILYElP1vpp0h77WdF2tj/+Bx5xr1lo9ngPVTsqpkyCaKtaJbd75t2SDToHdtFf2fs/t1214SYwdM/Xc6dhdz+Oi9XrMylaNLjF24AB9Xuhbo2NCa17Qc2G4QLffP/FN/XCuqQCwPeERQgAAAAAAAIQa38ACAAAAAIRaEPzjT1iEqS/AjoJvYAEAAAAAACDUuIEFAAAAAACAUOMRQgAAAABAqAVBxIIQJf+FqS/AjiISBDy9i3dXd3e3xeNxm/npqywaG5nskt+jp9tQiZO4tlYnwJhzveicrtNxvESajA4/ssD5bmJBm5cSpusDNbqhko3Z29Vbr/veM0mn5ky4X6dydY/TET4R50j3En9yddCTJSudRDfdfetv0P2vf9JJ0ynU7ecm9fIdM/WKaxbppL3O6XqDc3SIl/VM1v2vflEv3zvO2efrnCS5Rr181RLd/+FCJ+kpnl0fLnLG0pmv3vHQ16DbyXGC4cpf19v61HdukvVDPvk/st41Wf8fS/lKb+7r5aODTiKdc0x4CZPJar181El2qnxNn7+8xM74Cj0JO6frHVPU6iSCOmlgXvvdE3X7BV3Z7XeP18ebl2rXO85JtYs757X79LxPF+ht6mnU+zziXDrynKTHoma93ky+Xm/XVH0eyU946X66P97c7J6k1zv+Tx2yvukAnRjnJcANF+v1xpfLsqV1SJt7PRgq1e0Xr89ePuJ8DM3Ru8Tye53jWU8pG3YS4LzrfLLaSdRsdU4YTjnX2bddU/SKvTkyMEWn70W69RwsXanbTzuBl96c9cYzvkrvmOa9nQuIM87eNddLOk5M1g2peRJztqmv0Uuedc4LG/Ty3VN1H0vW6T4OO8dP5av6ROWlT3tj4LXTttvISZVOJm3F//uqJRIJKyvTKZBhtfnfFjv95kKLFjkRnNtAun/Qlp187XY5psD2ikcIAQAAAAAAEGo8QggAAAAACDUeIQTAN7AAAAAAAAAQatzAAgAAAAAAQKjxCCEAAAAAINQyQcQiIXpsLxOivgA7Cm5gYavpb8xYTsHIpJYxd+lou67pRbLupXV56Tj943U6WW6ZjrvJf1mvd8xzOvWnZU+dfBJL6A4VtOt657TsuKGCdp2CU7raScGaohOIvPSd5iP02ER69WmgdJXzBU0ncSntBBAVr3WSg4adJLmJTpKkk4o4WKE7tOFgvV2VS/XyKScJs+5ZvV4vScpLP8wZ1utt3Uv3s3iDHoeWfXU75cuyaxnnDN+2j04sqntSb9PYR/TxsOFQHa3Usrder5c2+NjNt8j6/l88V9Y3HqDHJj+h11u0Sde9z51DpbqeqtbjVvq67k/rHno8a1/U7fSM1wdRnpOimjugzy8dzv4t6NATwkuH3XCMaCej246+qPteuka3HXUSyFYf58SiOnL7dN2b+yXO+ahnvJNq5ZzvvOS2vH69T7xUsebD9HjmdTjLH1Qp64mdnH3erOemdw0tanGiRZ3LQX+d3l/Vi53r0AHZKw4KdGcqx+gDuuV1PQbRfj1m4/+qLx5vnOEkWOY6Cbkr9BzJ65Zly0nr/niJjgXtuh5boNebdqZsfI3eh6kSb+7reoWToto1We/z2hedJE8nBdJNXnaSfDPO9hY3vf0w9ZqFemw6Zuq5MFys24m/rrepbI0eg6I39M59/bK4rJf+XUdGDsWdZMupzjWxa+Tf0/pSDgDbFR4hBAAAAAAAQKjxDSwAAAAAQKgFwT/+hEWY+gLsKPgGFgAAAAAAAEKNG1gAAAAAAAAINR4hBAAAAACE2j8eIQxP8h+PEAL/eZEg4NDDu6u7u9vi8bgdvuuFlhsdGRvTuatOXBkq1hej4UJd9xKmClv1dK56qUvWW/cql/W0k5qTm9Tt9453lncSskrXZqcuFbbq9JpUuZNSt05Hkw2M0ek1+V26/WhSp/JsPFhHsXnpVTUvJWW9bRcduVS2Vq+38N7nZL3pC3NlvXqRjtVJF+pUnoFKXY+m9L7tq9dfVC1fqfvfurveX2Mf1UlYQ0V6+Za9dNJTw5N6nLumZkc0VS/skctaRM/XTfvofZ7Sh62VrNdj5h4nzlgWtepJ9fS3bpL1I086U9Y3HqTnvpckF+ipYHUL9LEyVKz7X7xB79tMnl5BYoo+JpJVTmqZk75VuElvWPXiXllf+aESWY85iXf1T2afwHom6jH2zgu3XnOdrJ92xRdkvbBdJ5/FOpzzV7+OM+ydpLe1e7zeJ97xHHWSHhOT9PHpXTvqn9SJeonp+pgrW6XP773jdXJuNOUl3urzS56TPFnoJOd6icC1L+i51jJHj3/14uztGi7RY5nXpc/tqQp9QOR36uV7JukouYJOJ3HRkY7pMeiv1nMq4wRqFrc46X5TRvd/yuUrdP+HCnU/U2V6bpYv18fQuiN1smjNi0766U56HLwk0iEn+XdITx2Ldeh2Biuz28lzLn2l6/WYJSt03wfjzmdQZ9/mOomxXbvp9U66W49lf62eC8lKvW+jg3psCjpGtj88lLQF91xiiUTCysrKdGdDavO/Lab94isWLXKiPLeBdH/Sln/8/22XYwpsr3iEEAAAAAAAAKHGI4QAAAAAgFALgkjIHiEMT1+AHQXfwAIAAAAAAECocQMLAAAAAAAAocYjhAAAAACAUAvMzWXZJsLUF2BHwQ0sbDXTfrjC8t+ULvS3O/eRyxa26EtA/2QnWaVNP3OeM6yXT31bxwFGf1qu604i3ZAOM7KiJieNzUmkSUzO/vJjy/t1Gk1siZNkdppOtQme1If1YScvlPXJha2yfucV75X1nnH6i5srP6Rjecb/RaeHZfL1Phx8YKKsV3xfb2/BxU2yvqKlWtbrfqXTa7z0wHEP6Z24+n06ja1AD6dtcBLyag/eKOv5f2yQ9f2+87ys3/XHA7NqVSd3yWXjMZ2a1/qz6bI+9m86aWz56ToRbeZO62Q997qxsr7xAD3HvbTBB+/4iazvfs18Wc/rH91HzA2n61Su3DwnPSxHt79vw0pZf+LRXfWKM7qd0jV68YFafQxNv/FV3fz5O8n6hkP0iW3cd1Zk1V7tqpXLDv26TtbPP/U8WR/eTfe9/TR9ru7f5Jx8c/R5J6J3lUUG9Xk2eki3rE+r0gd06nvTZD2Tq/fhxkv0etNpHZfW0q8T4DI9Ttyj8336qhd0f7zXtmzaRzc07m/6PJ6YpvdLjjP+RVc3Zy/rRFgOOzGh4wv0mD21fqKsR57T29R0qK7P2UUfty+uGi/rJS/pa0d/o5Mwd6Q+/5bfrceyuEmfj1p3d9JMq/U+H/uobmflyU7S7iI9SfrG6P1SstZL8tXtxLr08sP6smLF+lJpEZE+7Z0bvb57dyHctEEdBmzlK/QYj3lSX0M3XalXPPBClW7nWX0cNu+rO9q528i/ZwbM7B65KABsN3iEEAAAAAAAAKHGN7AAAAAAAKFGCiEAvoEFAAAAAACAUOMGFgAAAAAAAEKNRwgBAAAAAOFGDCGww4sEQcChh3dVd3e3xeNxmzX/KovGRqbkDOsgNjetr2f2oKxHOnXiSqxdf6kwcL5rOFyip3/VIicZpkY3lCrT7acLncNLlMtf04v2jtXP15ds0G3HunXyUddknb7jBD1Z6TonQalOj0HJeh07NRjXy2ec2+fpAr29ySon6XFAL58ucBIsW53lY7o/XgpR8UYnQcmZ407QlvXqYCvLSTlJmzqEyNIikKqg/e0va2bWO1EnPdY/rvdh3xhdz3VS/zK5epv+P/buPM7Osr7//3X2bWbOmX0yk0kme0ISdllFQAGLa9WKSkVr0YLUtmitG7UiVfhSLeX79VtQWxXc6aJtrahEQVB2QiIQQvZkMsnsyzkzc/bl9weF729y3h/rWCN3mNfz8ZjHQz+557qv+7qv+7oPZ+5z3sWk7o8zvloiqIPq3C8+fIusv3H3hbIeDejj3XvrGlnPN+vjtdJPp47TJ711i25nYoM1Z/X28WG9fb5VD5w1bnkdLOj8YvkN6gA180V8qUHXl35/Stb3vz6l+6LDvcwxaBzQF8r0Yn1BZ7v0mFV1GKAL6SA8c+779VQzz/mi+/X2h8/Tcyo0ZSzkxr2vlNTr9eqv6BNspQ3OLLauCb1f9XUxVqJbZrmRzDthXA9GGnDHz3WS5I736qRaf17Phfiwrme79H4Th4wFzLhWAgX9D6FZXZ9eosfButeEM9Y9S/czYJyXQMnqj97eX9LtW+nTszqs1gWMe71Sjei2K8b1HBvRbVvrV1iHlrrouJGobSQxziw3LpSgPonxvcYBGI6cC5VC3u286WMunU67pibjhatHPfffFstv/5gLxI0XMS+ASjbv9r7z+nmP6S233OI+85nPuMHBQbd+/Xp38803u3POOee//b3777/fnXvuuW7Dhg1u69at/4OeA8cuPkIIAAAAAMBRdscdd7irr77aXXPNNW7Lli3unHPOcRdffLHr7+//pb+XTqfdO97xDveKV7zit9RTwJt4AwsAAAAA4G3/lULolR/5WOl/46abbnKXX365e/e73+3WrVvnbr75Ztfb2+tuvfXWX/p7V1xxhbv00kvdmWee+euOHvCiwBtYAAAAAAAcRcVi0W3evNlddNFFc+oXXXSRe+CBB8zf+8pXvuL27NnjPvGJTxztLgKex5e4AwAAAADwa8hk5n4xWiQScZFI/Zerjo2NuUql4jo7O+fUOzs73dDQkGx7165d7iMf+Yj72c9+5oJB/tMd4AksAAAAAICn1Wre+3HOud7eXpdMJp//ueGGG37pcfh8cz96WKvV6mrOOVepVNyll17qPvnJT7rVq1f/xsYROJbxNi5+q+JDOqGl1Gik/mzX0XBWElZoZn7JM5nk/NJ9rNTCqhEAFc4YSXIiUavmN1IFp3TbVmJRZEKnb/l7dScjo7qd8LROwcm3GKmCISsN0EhRPKxTsIoJI/Fuse5n52O6naHT9fFaqUJW6uJst3G8xpyKThrJSot0O8ndevuJ9bretlXX06vq2/cbaVGJQX2s/qK+JVTCup3mXXquWXMh26rPSXxYll22U7cTMpLerLTB76zcJOuVmh6Hc3P6RWJqXB9vtlOPW7xnRtZ9m3VSUTgzv0S3UsP80gathFKf8R0eKvEyoINhzeuqGNBtl5N6ba+G5pc2aqWohjI6tjDbaVy4RjKclZBrJahZ6arWemEl6rmaXteiQ3oHASOlMZzW/SykdDvjG/WJtOaalfAbmfjVU3KtNmp+fXKtND0rMXZmbYush4z7c9Ne3Y41SaJjeutgXp/DaeNenDASNa17erZTX0PWNVFoNtZTvUyZabXWXPNZ6Yrz3D6YNRIBm371ZOG8sR6FZnTbkSljToX19sl9elGeWqGvq0LKOLcjxuuyCd1OaNq4no1zGzni+q8UCZ4/Wg4ePDgnhVA9feWcc21tbS4QCNQ9bTUyMlL3VJZzzk1PT7vHHnvMbdmyxb3vfe9zzjlXrVZdrVZzwWDQ3XXXXe7lL3/5b/BIAO/jDSwAAAAAAH4NTU1Nc97AsoTDYXfKKae4TZs2uTe84Q3P1zdt2uRe//rXy3affPLJObVbbrnF3X333e5f/uVf3LJly/7nnQeOMbyBBQAAAADwtOfT/zzi1+nLBz7wAXfZZZe5U0891Z155pnui1/8ouvv73dXXnmlc865j370o+7QoUPuq1/9qvP7/W7Dhg1zfr+jo8NFo9G6OrBQ8AYWAAAAAABH2Vve8hY3Pj7urrvuOjc4OOg2bNjg7rzzTrd06VLnnHODg4Ouv7//Be4l4F28gQUAAAAAwG/BVVdd5a666ir5b7fddtsv/d1rr73WXXvttb/5TgHHCN7AAgAAAAB4W8337I9XeKkvwALBG1g4anyVZ39+FVZqjp1OZOxTh2yZfJV53niMAJeakZxViRjti82tRB4rWclZXTfqfuNcWGM233NijY0z2reSG+fLPOfWHDH6ac1Vs5/WuM1zzppzKqD/wZ4nv3q6kDUXrHNuJauZfRdR0M7Zfbde/1n9sUQDOhnKShsM+PRJsebUvPs/3+2NJNKaf37rlL9ipbHqdqpBXQ/k69sJGMmW+Ygey1rQOCZjjphru5HEaPEV9CS35r6ZHjjPOWit1/O9Z1n9tJjr4DxDx6x25nsfms/xmtebtcZal8M87/+Wef/3qHGs1nVlpYpac9C8Z833XJn3Gl2v6BA189xa21v3VnsdNNrRYYw6Zdpq2xhjqy/WWFrn1kobteaItWNrDOa7Lhy5fv2mXncBwAvJWlIBAAAAAAAAT+AJLAAAAACAp9Vq9tPNLwQv9QVYKHgCCwAAAAAAAJ7GG1gAAAAAAADwND5CCAAAAADwtpqbdzjFUeWlvgALBG9g4aiZXl1x/tjcyJTWzfqhv2KjbmO+yXyzi3SiS6lJN1RuL8p6eErH6TQc1PvteCgt69Mrm2Q9s7Q+CmamV/e9++d5WR8/Lirrs126nl1kJJOldCRSeEgvD5FJWXYzPfrc5rp0VFLrdh0ptP9VeuyTu/T4DJ2hY3XKjXq/sUG9/egpsux6N+k5cvAiY3zG9DhEJvX4j75Mj0Pn3br9ofN0DNGq2+vb6X9lTG47uVH3pe0xXQ8UdH3oDN1H6/qMHzauT+P673xMj82hd+pzsvfWNbJ+bm61rFspXj/7+y/I+rIfvlvWm57Ux5UdTsh6cZ3eb+KgbicxpM+5Wkeccy6zUh9Y7136PE6s1edxekX99lY6Ztf9ep+dj+r1a8+b9TpVjepjLTfosWnapcdg9+/rSRUblmWX69H79RX1fiOTut54SLdz8CIjbSyix20qry8ia86W9aXufGW936A+LS721iFZD3y1U9aLTbr91J6CrO/5fXG+jPt8aFyvpZWo/oVqTA/OhDGnAkN67sy8akbWYz9pkHUrGa4c12OTOVmPTW2LvvfV/HouzCwx0lXzer+xUV0vpGTZLbkrK+ujJ8Rlve97evvxjXpy5luNa6hfn9+Rc/RrlY4f1M+TcFpve+hleoxzHUZyrpEYOfwSPTc7HzXWEWOOj5yk2wnm9PZWP7OL9Fxo2jW3/fkm2gKAF/ERQgAAAAAAAHgaT2ABAAAAADytVvO5Ws07T5J5qS/AQsETWAAAAAAAAPA03sACAAAAAACAp/ERQhw1sa5ZF4jP/QbMxJD+8k9fRU9F6wsriynjS9kTut6zTn9zr//mNlkfPUmWzS/WrCTCsh4b1l/Wmk/Vf6lpdpFue+Qk/WXHxaTe3vyS5Y16DNakRmR9553rZX30RP3Ft0H9/a2u51795aKzXXrMqh16zNq/reuFV+r9uqf1F+gnhnR/MmuNb0c2hKb1+/+xMT3+8RH95a4vO3GrrD/19eNlvWvNIVnff/KKulphsf6y84s3PiXre25bJevTy40vI1+qz4nPmIP5ov4y32KbHpvSDuMLbkN6+3yz3j41rr8M3vpiXevL2vf9zj/q7Yt/pBsyVKJ6rkUnjC+5j+vjik7oA2i+UF/ThUf0F3Fb43DKqbvqamHjG6sP/kh/Uf5st/HF1EG90/C4Xl9KTXrMsj26ndDSWVlPPqjvQflW4wvDu/Q1lOvSx9V0QPfHX7S+kFyWXfYEfbNZ/G39hd79r9Lt+Kr63mp96uXgAX1PPO5B/eXu+9/SLeuHz9YH9saTH6qrHcqn5LZbBhbLejKm152pft1OLavnVDijB2Fxi04q2X++EbTyZX0vO/hO4xvAy3ouWF8GP7lW7zdgfBF/y9N6DgbzxjXUqftjXbtNB/VxZRfp7X3GcVmBBMaUda0P6X+ohOqPd+x43ZfWp3RnCk1GwFDS+EL8EeML6HfoQJ9qg54jpZfre2LzPXqMB16u22l7XPdnesnc/1/Rl86xh+Q/YEHjCSwAAAAAAAB4Gm9gAQAAAAAAwNP4CCEAAAAAwNNIIQTAE1gAAAAAAADwNN7AAgAAAAAAgKfxEUIcNcd3HnahI9L5HnnpOrntsn+bkfVKtEHWU7t1fE1Nhw25w+0pvd+sTnppe1I/EjzbqXdw4GKdbJWqD/FyzjlXidW3X43qdJzp1UbKVlLHyYS36sS4oXEdW9gW02ldvpreb+KwrluJkYGcPq6akfrj8+v2MysbZb1Y1PGHVR1C5Jr26uMNFPU5LCb1Muk30nxi43puDp6p584P9+hrItWj04aGJ1plfeak+rS0ey+4WW77u1svl/XSeXqMGw7qY4rs0UljrWfpxLLJbTpxqXGnHpvEIb0uTBlzxF/W9Wzn/JLYmozr30ob3Pe6L8r6ynveJestd+lx81V1/62UQH9B/8PwlD6P3aNGKlpNj8/20frUwuwBne4ZOUlfzz336Ouz7TE9FybXyrKriaQx55yr9BhRbHv0vSPboTevRoyxD+q53/ddnVQ3fmLKaF+345/Vc7+W0+M5tlFv7y/o9puf0euvlQDnf0LP/bGzdUyuMXVcrlvPtTv31qfbFgu6kaZGncQ4NanvcZYV/6z7MnqC3u/OHTpZsX2pPufDL9FzrTJlpKjO6HPYtF/3M5zR28fG9faHXqaPa9XtE7Kee6csu7GSvtcs+bG+5kZP1Nd0bpHup3lejtfrY/NOnSY7011/vNN9eoI37Zdl54x7gV/v0rx+Jk5qlvXYhD5WK4310Hn6/r/ofmMNNx5HGHnp3P9fzRkHdCypOW+lEHqpL8ACwRNYAAAAAAAA8DTewAIAAAAAAICn8RFCAAAAAIDH+Zz5mc8XhJf6AiwMPIEFAAAAAAAAT+MNLAAAAAAAAHgaHyHEURP2lV3YP/c90viQftR28jid4mMl21UDOpUnPKPjQFZ0jcr6wFlLZD2kg+pcxUi2sxL78q26/yUReOdL1afIOedc4+M62SdwflrW40YyXOyiMVlf0aDH5nByuaz7dKiVq4SNZLiKrodndIxPMqlTy0oJfVzlopES2KMTrGaW6rTBzBI9p7oe1v0ZOVWfl3JUn/NKTI/DkhZ9HocX6yS51a36fG2ZWFpXe9vT75DbNkV1hGLamPeN/Tp1KtOnxzKd0+eqZYeePKMn6r+lVEP6nJzevVfW7zmuPuHMOefiPTrN0LhsXXZ4filnVtrg7vO/Iuvrt10l62U9nK7zUSOhtFfP/WXt47KejfbIejWo5+ypiw7W1R4q98lt40/pNdz5dNvRKSOddIleB3tb9XVycG+7bj+t95szUgiD3Xrytyf13Mkt1glt1j0i3KHXkXJZz/HqTEjWCxv1tWt9iCXbrieVmR7Yri+Krkf0+cr4dUPJp3W94dX14zxW09dbR4Me+2hYJ6kN+3TS7uiJej3KHK/Hsm+xvlceHNUJcw16arpSgz63wRX6uII/1MlzLQN6+8GXpWS9GtL31twSPT4To/qcN2SMNOZFepIHjfuHP6/X96kVuh1rHRzfqK8Jv1gyIpO679OLdduhWSPBtkfXG/fpdqKT+joJ5PU5Wb/2sKzvHl6md2AYM8YmND63/9X8i+A/+0ghBBY8nsACAAAAAACAp/EGFgAAAAAAADztRfAsKQAAAADgRY2PEAILHk9gAQAAAAAAwNN4AwsAAAAAAACe5qvVrBwm4NeTyWRcMpl0x11xvQtE5qb/FHSIj2sY0NPw8g/+h6z7fXr7b3zoNbpPRlpXMKfbGTtNJ8l0/ly/5xvMzy+BL5+sTycqNOvUnPiITq8pJPX24Yze58xi4/1qI74qMqHbed0f3yvr3/vcubKeGLaS5/Q5KSb18S65qyzrYxt0cpOVZDTfhMnUbt3/iXU6YcqvA7JcSAdJuUJK1yMTup4+TvenZWv9+S01GCmYRmBcOKPrPj30rqhDrVx0XM8d47J18VF9TPmUHuOptbqd5E5d9+kp5WrG3J9ap+uVqG6obbO+tmZ79A62ve8WWb/q0BmyfnbTLt1OVqcK/ufXXyrrkUl9Al5/9T2y/q1vv7yuVk7oNhbdrydJza/H4PClOm0w/KS+cK3rqqID5lx0TPfT6k9mlT638UP63M4s18fbeb/efmKD3m/Tblk27welJiMxrj4w0jnnXK5NtxMb0e2Efm9E1it36PhGa42JTOnxTC+vH59K3Dim/bLs0i/Vqaixp3QybOhMvZgG/lO/IMm3GPfiId3Pqg6Ac1XjSzqsc2vda6ZW6nWwbIxbIK/bD+kgTLOfjf1GmmGrnuNWkl9ZnxZXCxgp0xdOynrsn/UNJ1Cs3+/om3QKccNPdeKl1Zea9Wd+494RmjbGIG4cqzF3rI+lpfbqdWf4MuN475p7s68U8+6J269x6XTaNTU1GTv3puf+26L37z/p/DFj4X8BVHN5d/CPP3FMjilwrOIJLAAAAAAAAHgab2ABAAAAAADA00ghBAAAAAB4Wq327I9XeKkvwELBE1gAAAAAAADwNN7AAgAAAAAAgKfxEUIcNeGZWl06jJW+k+3U9e6QTqPZntfpW/H+aVnPN6dkfbZb7zexX18a4VmdAGMl6sWG9bPFlWj9fqs6aOiXJKhZSUP6F2KjRiqXsV8rmWi8pFN8rNScyFhB1gM5vYOQT7+vnm/R2yf36+SmkZN0O4nDsuwiaT1u2XbjfX7jeBOHjRQiIzQnuVdvP3SBnmvhwzq2aHZx/XwI6cvBxY15aZ3zhkE9xqUpI5XTSPcMp/UxTS/RSZL5ViPqqarbn9hg7Dej+1nz6+0TB/V+oxO67jP6YyVhWmmDt/Q8JOsfHj5R1gvGCQtPGde6MZxPZPR6qpL/4oO6kclVel5GjL5Et+jBKaasJDMjca1gpPs9rudatn1+L3uqemq65DO6nUrYSPebNgbfiOZs3aZjF0ffraPkwk83yrp1TYeyer+Z+zplvaaniGs8aJ0XXW/sr6+XEnpsrNTi2riOjA2njWPaqRuKGmmDQR3oZt5bZ7v0TdRKELaScKtB3Z/mXUZKa7Ne1zLLjVTHAb1f83VZh27fSpO11mvrNYZPH5Y7vmNQ1ncFUrKukvwiEX39V2LG66YZfVBWimfDIb19tstIhzbWQSvF07p3xH+io4KXtuqY45Ho3HWhYqSwHlNqznz99YLwUl+ABYInsAAAAAAAAOBpvIEFAAAAAAAAT+MjhAAAAAAAb6v57M/DvxC81BdggeAJLAAAAAAAAHgab2ABAAAAAADA0/gIIY6aYK7mguW58Rw+41HbsJGW9v3JE2R9gxElV07pqLeGgaLePqYjpjIrdH+mVuhLJmEk0ljpJCqh6cjExufk2vT7zK3b8rKe7tMJTVbiT3xE/0O2Q0cHXdqik9IezZ0i69N9MVm3kokaD+hxKDTNb+409ut6MG+lMVppQLoe0QGZZqJmcp8e56qx39hePTfDOoTIVcTUjw/rFCyVLuecc1Or9VyrRPS8DxpJZqFZvd/J1fqYQjpYzVX0VHaNB3Q936L779eBVK5mJDIlhozUxfj8Urk6H9XtnP3mXbJupQ3e2LlV1q8fWyPrVsJcJaKP94LW7bI+cHBVXa1opGb5dAihK6T09lY6XuKgrkendD29XLfvLxupX0biXXRU1xv79Vye6dFzwbo+YyO6P7EJ3f50r3HN/Swp6+WIlQao+2Ol21oJfJaKkdJYbLSS+eqviWpQj2V0QrddMNIDQzqIzTXuN+4dGT1m1twJZ/T1PNOjjzVYMAbZSNqd7TISeNt0f5r26ubjh+eXlhqaNeaOfokh7zXO/ZJkZCuBz7gWYwF9gwrm9Hiqda03NSW3HZ7V14+1HlmvL4rG6xG/fqnpcu16+5Ydek5NrNFzKrdEp432H9Tp0Mkjh8yYkscSX82+574QvNQXYKHgCSwAAAAAAAB4Gm9gAQAAAAAAwNP4CCEAAAAAwNtqzvx6jheEl/oCLBA8gQUAAAAAAABP4w0sAAAAAAAAeBofIcRRk2/xuUB4bvJKOa6ftY0P6TYOZVOyfmCmRdaDaR25lFukE1qsVC5fRfczuddIkgvNL/WnHK3fXtWccy4yqWNjcu06/slKMyw26vZzrTrtxkoI+vbk6Xp7I60vNq77H5qVZTfdZ7QzbDynrTc3Uxet47LSeapGulpZTykzXTFnJOSFZ4zUxVZj3GZ0OwGRHmal8oWMfYbTsmwek3X9zHYaCWSj+pjMdKmQvkXlOvR+48YcKRnJeZbMUt3/6ISRWiZSRZ2zk+S2ZXtkvWBEYVlpgx9r2yHr/5J6uaw3HtQXxd0Ta2W9Eq4fNzM5zLjOI1N6n6MnGil7RgqeldBmzc2ZRfrCta7bUoOVfmolc+p2yjp01eXb9Lil9ujEtVyz3sH0Sj2eTXfr/daMP1NGJnU058ip+r6S0lPNTHW15oMaz3LMuPcZ6XXBrJEYG9PbZ1bpvjRv0+3kjbTRxKBuJ2Al2xqpfNZcbt6h50LVSFGcWDO/a8hKD8wa62n7E3qOTBupi/ERPT5WYp/1WuUXY92yXmk2zstw/TWxb6xVb2u8jLASe2c7rXXHSDM17hHWPajYML9k2/Ckjjns7tJxiaXpzjn/v2KM+TGl5nv2xyu81BdggeAJLAAAAAAAAHgab2ABAAAAAADA0/gIIQAAAADA20ghBBY8nsACAAAAAACAp/EGFgAAAAAAADyNjxDiqDnzsi0u3DA3CeqRvztFbptv1e+lHr6jTzduPLKbf41OA1l54V5Zn/n6MllvOGC0nzJS3bK6QzNGWo9KgRs/XSf+tD6iL9Px83XUUHRrXNYf/NObZP3rmRWy/pUbXifrd3/zNFmfPl0nKC39N1l2yX1G7N+FOk0n/E8pWW+4/JCs73laJxkt+pmeI8P6sNySu/RxDZyvU85anzCSsPr03DnzPY/L+hOfOkHW4392UNb3PrykrhZek5Hbvn7FVln/8adeqvc5pJOPdl+qx2Djcf2yfuib+nqbOE0nq635/Iysr771GVm/546XyHrQSLz0G2mjmZVGatmFI7I+PNUo68vax2X9P7+uxzlspK5Z64uVNvj4x2+V9XOv+CNZ3/OPOuXwbR/6UV3tp+Or5bbj/3eprAfy+tw29uu1cfQ0Pfa1hF4fw3F9fY4u13MzPKBT9kodup3EyROyXv1hl6z7jGUtv0In5O5brc9tU9Ok7s/PdQLv5Nt1hGj18aSsV6J6PUrulmXXsi0r64Pn6FjH0LQ+rldd8fO62lNpvVa3R/X1P13WCY0PP7lS1jt/ro917FX6Hvo7q7br9i/Uczz8bT2nDp+r7zWJPn1uM4WUrFtpjIVmI/3Qr/eb3Kevxcwr8rr9A/q1hF9fKmbSsZVCWNLLpot+v13WKw16+4nm+tdIjf+pN55ZovuS7dLrUdmILQzpW6tre1KPZWqnHvvcJ/Xrncp39PoyfLq+3qp367rviKGsFF4EiXl8hBBY8HgCCwAAAAAAAJ7GG1gAAAAAAADwND5CCAAAAADwNj5CCCx4PIEFAAAAAAAAT+MNrAXo0KFD7u1vf7trbW118XjcnXjiiW7z5s3P/3utVnPXXnut6+7udrFYzJ133nlu27ZtL2CPAQAAAADAQuar1Wo8/LiATE5OupNOOsmdf/757r3vfa/r6Ohwe/bscX19fW7FimfT6G688Ub36U9/2t12221u9erV7lOf+pS777773I4dO1xjoxEb8/+TyWRcMpl0r1j75y4YmJsWNL22Wf7O0On6vdTYsE5MKevAFZfr1fE4XffohJlCUrc/ebJOvLLaGb5Yp7S5jE7CSm2rP95CSvclOq4v0YkTdapNKKP72PGojseKD+l0rIMX6ASi1E7dTr5Zn8NAyej/2XrMUg/rRKdyXI9PwyHdn+kluj/ZRXr78JTevhrW/Y8fMuamHjY3c5w+3o579ByxBAu6P4Pn1Nd7f2SkVBkfHi8byWRjJ+pjbX9ctx/O6LnpK+uxL4gUKeecGz1Z96fvezoRbfREvTBEMnq/lbA+rviI7n/BSCGNjer1wkp6y7Xqa7RmBET5dXdcbMz4B6Ode7/wRVnfeNNVsh6dqD+/rVt0/Fb/q3TaXTGl50jPfbrvYxv1XIgP6XYSg3rsywk99pkleuytpDcrVXDaSDMrJfUvtP5Cb59rN9a1Ad2OmehmrI8lI7ktZCRzxof1fofPMsb/oB7PoL5EXcPh+vOe6NedyfboxTQ0redOdMegrA+8uU/W8+36mLoe0u33XyzLbtG9eq4l/kgn5GY/r1MXJ1cbc1MHTLrkPv16pxLW/Rk8S9cX36OvodHL9UnMDejXgbHFOlEvf0Bv7y/pOdv8tCy7qn5p4CaOr5+zbZv1sU7pwFUXG7ESFPX2pUbjntKg6764HuP2TTpRM5TT7Ry6QM/Z1s167hz58bZKMe+euP0al06nXVOTcXAe9dx/W/R+5lPOH4u+0N15XjWXdwf/4i+PyTEFjlV8B9YCc+ONN7re3l73la985flaX1/f8/+7Vqu5m2++2V1zzTXujW98o3POudtvv911dna6b37zm+6KK674bXcZAAAAAAAscHyEcIH5j//4D3fqqae6N7/5za6jo8OddNJJ7h/+4R+e//d9+/a5oaEhd9FFFz1fi0Qi7txzz3UPPPCAbLNQKLhMJjPnBwAAAAAA4DeFN7AWmL1797pbb73VrVq1yv3oRz9yV155pfvTP/1T99WvftU559zQ0JBzzrnOzs45v9fZ2fn8vx3phhtucMlk8vmf3t7eo3sQAAAAABYUX817PwB+u3gDa4GpVqvu5JNPdtdff7076aST3BVXXOHe8573uFtvvXXOdj7f3O8DqNVqdbXnfPSjH3XpdPr5n4MHDx61/gMAAAAAgIWHN7AWmEWLFrnjjjtuTm3dunWuv7/fOedcV1eXc87VPW01MjJS91TWcyKRiGtqaprzAwAAAAAA8JvCl7gvMGeffbbbsWPHnNrOnTvd0qVLnXPOLVu2zHV1dblNmza5k046yTnnXLFYdPfee6+78cYb57WvqeObXSA0Nylk7AQj9euwrr/2XT/T2/t1ottPrn6prBdarIQ5XffP6kSXclT3M/HE/BJRVNqYlTZYMfbZc7eROhXT+8y262OtRHTfw0by0ds//n1Z/8Z1r5Z1K8XLP2pEChmPY6f26BSf4VON9B2jofbNemtfVXfUSvey0gaDeV1PPa6PtxLV/bRSKcsxI61yuL4226XbDmV1feRUWXaN+/Q+Czp4zhUT+tZSM05VeFr3JzKh93voXJ02WNWBTs5nxPtVg7o+sVb33/yogBHraLX/+qvvkfUnMj2yfkHrdlm/e2KtrO/5Rx21ZaUNPvmBW2T9jA9dWVcbO0X/gSK1e37Xz+BZejL4jdRSnxG4ONOjx77xoE5oC83odTC9Srff0K/r1ZDuZ2xYt5/XAbwubKQfWibX6e07H9b19HIjHdZIMx09Re83OjS/5ExrHS+J9Wv4DD2nAjkjwfZCvdNF9+qvL5hdrOdmaoduZ7ZDH2vvXXoSjh+nx7j47cWyHi/qdgI6ENjVjD81z3TruT+1Vo9b6hndzuQanYTre0Qv8E053U5pWG8fN0Ka/foSdR3v2ifrY/+4VPdnV/35Cr9Vf+VF+Kddsl787wO250gMGOe8SddrAX2uKhFjjm80Enj/Tb8OGnmP/u5Z36Nzz0mlYF2wx5CaM9eXF4SX+gIsELyBtcC8//3vd2eddZa7/vrr3SWXXOIeeeQR98UvftF98YvPxqv7fD539dVXu+uvv96tWrXKrVq1yl1//fUuHo+7Sy+99AXuPQAAAAAAWIh4A2uBeclLXuK++93vuo9+9KPuuuuuc8uWLXM333yz+/3f//3nt/nQhz7kcrmcu+qqq9zk5KQ7/fTT3V133eUaG+f5JyoAAAAAAIDfAN7AWoBe85rXuNe85jXmv/t8Pnfttde6a6+99rfXKQAAAAAAAANf4g4AAAAAAABP4w0sAAAAAAAAeBofIcRRc86fPuwiDXPTbe694Sy5bbZdJ6N855/PkfWAkV5TOVvX/+itd8r6dz98kaz7yvrSyLfp9sNpHUMSMNJ3ch31x9v9yoNy24lv6GSl1Pt0PNaun/XJ+jtff7esn57YLes3XvZ2Wf+HymtlPf/GaVlfdp0+WTM9LbKefNMhWS98aZGsd59+WNb3D+iTVdup0wCHX6qTodZ+fkbWd12mk7PaHpdlN71U/73gE3/wTVm/6bq3yfqbPrJJ1m954OV1teTZE3Lb/73227L+kSveK+uR4VlZ3/O2lKx3naQToKr/0CHrh16lx37VP+i50/t3e2T9oX8/XtattKtAXl+30yt0/ZRTd8n69tFOWT91kb6mv/Xt+nPlnN3PgYM6Iq8S1uvm2z70I73fm14p6ypt0DnnHvqbz9fVPjx8otz2J39/pqy3bNeRZZWIjkvNvExv33bOiKz3T+p4v0pAz6ngvxnb9+r40I7T9X7HvrVE1q10v7GTdb2hT8e9GrcOF3lU9z93qb7Wa4/odbZspEM29BsJf3fr9g/8rm7fShb927+uT7z88fQGuW0ymJX1nVmdJHdXi07lbPmRnmuTr9Rz7dL1j8p6qarTCR/4y9NlvfA+PWa5im4n/L1WWa9E9DnJdul6cocsu8Sgvib6f9dIaTSSc4NGOmRsVNezHUZin5Fie/C7y2S9oaj7qa65/L/oNTlqRMZZSY+FZiPBVgc3ur5/n5R1X1ZHTLbcrufI7lv0XJ7u1a9No3fp1yN1aclG0uWxxOd+SSLwC+BFkOsIHHN4AgsAAAAAAACexhtYAAAAAAAA8DQ+QggAAAAA8Laa79kfr/BSX4AFgiewAAAAAAAA4Gm8gQUAAAAAAABP4yOEOGq2Ti52wWJkTi1+WCc9BbM67SZjTFErvabYpKNJHphcIes14wqwEpQqMf2ocNcmnYRXbToyAuZZU+vrD2DPsE7NWzxclvU99+iknpgOtXGPTPbpf7D49LGWGvXmhXGd9JTt0/XkXn1c+/fo9KBO41zVjMe3o/sisu4v6SQjX1QnNPlKuu4vGuPTIMuu516dqLXtLYtlPT6kI+menumW9UV31ydbDZ6nU6229i2V9chhnbhYi+rBD6/OyPrAkE5Ka1ii07dcVY/xtDF3npnSaYZBHSrmAkbyUqBkJFIFdD3s1/3MHtAJUA+V+2S9mtDtxwf1nCo2GHMtoes/HV8t661b9PkaO0X3XyUO3ti5VW574TP12zrnXGZZVNatFKnQDr1m7g3quVxI6/ajKX2viRhj6Ub1erGjqNNPm4wUv+bt+jrPtevjKi3W10QiqnMIo4f0wI1OJPT2xiVnreN+41qpPvWMrMfO1umTCWP92laoX+8OF/QNvT+nEw6r88z9shLjfP16fdm+RKccPrp9uayvGdFz7fAWvU6tPPOArGf79TiMHa8PoNCq72XNRgphKaH/Zh0d0Ot71336xUShy5hrm/fKenKlvseNb9A3y5JxjRaN9a7l6frxT6/Q60Jqp3F9durtm3fqeTy1Uq8X1V9sl/VASp/bh/bpOdV3SF//g2fofloajlgvKkUPxff9umr/9eMVXuoLsEDwBBYAAAAAAAA8jTewAAAAAAAA4Gl8hBAAAAAA4G18hBBY8HgCCwAAAAAAAJ7GG1gAAAAAAADwNF+tVuPhR/xGZTIZl0wm3clv+ZQLhOcmplTCOkWmHDXqOrjJNRwykuSs2WzUc+36PVxrvyEjnXC6T28fnLWOq76d1qd02+MbdRuxEV3Ptet2uh7RY2aE+Ll8So9NKKvbz7cYY6kDi1x0VLdjJUYVk7qjjf36uHKtuj8BI4UnNq7bGTlVt9P1kE6kyzfr2K/MMt3/5G5jv2cZ5/E+3c7IS+priQEjdWpct+2r6npmuW6neYc19rqPAR3W5cpGuqd1Tqz1opAy9muc80pEb58Y0vsNzej66En60/jxQb3fhsM6gXNylZ78Vv+ttNRAQdcnV+u5mTLmYLGxfnyan9FRj5v+6TZZP/ODV8p6tkPPKev6j44ZiZHGFyFYyZPWemeNca5N97NxQF//s516e+tcWawkNr8ORXNlIxWxab+ea9Y1F8rquTBwvp47Df36eK37kLrPxYd14pqV9JYYssbeSHQc1ttPrNWTp+mAkTbaoduv6G66mvEn4ran9EkcPFNP/qAOznNdj+gFNd+q2/EbqauTq/U4VI1ry7rnZpbpA/bpzV3CSNT0V3Q9cViPW3pZfYp1zUjftPrStF/PwfQKnZBtrS9pHXjtouP6egun9bFa13NoVm/f2G+kFp45d3JWCnm3+zMfc+l02jU16fRZr3ruvy36Pv1p54/OL43xaKrm827/Ndcck2MKHKt4AgsAAAAAAACexhtYAAAAAAAA8DRSCAEAAAAA3kYKIbDg8QQWAAAAAAAAPI03sAAAAAAAAOBpfIQQR01y54wLBuamxswubZDbWslNjQNGQouRHmalB7Y+rdN6KmGdZGKlk/l10IsLzejtfToAynU8Xn9coVmdfNT8tL5MW55Iy3pmdaOsB/I6fic6olPF0it0moqVEtZ4SB9suk/3PzKt+9P4n7+Q9YN/drKsh2f0uFnJVpNrdGSUlbgUyOpzWw3p+vRSXV/yg2lZz3XHZL1hj+5Qw4COpCqk6ttpf1zv01WN5MOX6HNupWAVE0Z64Jhuf2KdjoZqPKCv8y/deJOs/+llfyzrh16mx7IY0P2sBfV+Ox/V68Vst547PfcYA+TT+y0m9UUUmdL9sdIVI1N67gfyul40kkVLRuJVy/b6tSGzTK+ZVtrgg5/9vKyf/uH3ynrjgI73Co/Mynq2z1qn9DFNrdDXVdeD+hzGR/T24+v1XKjo0DLX+eCUrGd79XodndRzITSr19lCSs+psY26/1aaYes2Y13eq+dOyw59vkZP0OPTuG+mrlYN63XBSry00objA3rNn16px7h5lx5LK8XTYr1esFKOc636eKNjuv2iEWyWa9eTzUobtO7FPXfr1xJ7LtE7rh2y1lNZdsmd80sK9lWNe25QH2+2u3772LCRZGgkUs4u0m1b60i+RZZddELXZ5boMVhyl+5PqUGPTWapnjuBgr7+k3vn7rdSMmIYjyUvko8Q3nLLLe4zn/mMGxwcdOvXr3c333yzO+ecc+S23/nOd9ytt97qtm7d6gqFglu/fr279tpr3Stf+cr/QceBYxdPYAEAAAAAcJTdcccd7uqrr3bXXHON27JlizvnnHPcxRdf7Pr7++X29913n7vwwgvdnXfe6TZv3uzOP/9899rXvtZt2bLlt9xzwBt4AwsAAAAAgKPspptucpdffrl797vf7datW+duvvlm19vb62699Va5/c033+w+9KEPuZe85CVu1apV7vrrr3erVq1y3/ve937LPQe8gTewAAAAAACe5qt572c+isWi27x5s7vooovm1C+66CL3wAMP/EptVKtVNz097VpajM+yAi9yfAcWAAAAAAC/hkwmM+f/RyIRF4nUfxfg2NiYq1QqrrOzc069s7PTDQ0N/Ur7+tu//Vs3OzvrLrnkkl+/w8AxjCewAAAAAAD4NfT29rpkMvn8zw033PBLt/cdEfJSq9Xqasq3vvUtd+2117o77rjDdXR0/I/6DByreAILR83MkoQLhuYmVk2t1AkqESNxaXK1kVJjPLLbvtVKwtPJWYGibijfptsP1QcoOeec692k/yHXpfebWVJ/6TUc0n2p6SFzM8t1omN6hR6zhJEclFmiE5oSh3RazdhJuj/hGb1fq/95IxFt9nKdNtj2lI7Nyqf0DmaP06k8sVE9ztO9up22bXpOZdv09lb60fSyhG7HSOAMzeh2xtfrpD2VrjS5Vs+Rku6Kq/n1HLG2D2d0vZQw0u6Sek4FjHTPd1z357JePl73c+n3p/T2SZ2IVjNeLO55s75urdTCtsf0OYkaKYGDl+gDjm7RMapWQuboifofGvv13Oy5z+jPWXr7SqT+uKy1txzTY2mlDT58o/6uj+M/e5WsJwZ1SlixyUgJa9X1pv16Do6erCe5r2Ik4RqJtz136+TPQ69olvW2p/RcGF+vj7dlu95vbFAn9oWNlMPIlB6HNZ98StYfv/VEWc+36nXWbyTwDp9e359Cq962516dBnrwfH09B2f1SdnwumdkfeQTy2R9Yp1uv2FQXz+VsJESaryusVILrdcdfecckPUDoaWy7jMSJuNDuj8DFyRlfdGD+iSWYnp979hspJ8aiXr+su5PQAdbuti4bj8sUqCtPuZajBQ/I7kxZAT5BvTlZs77xGFdt1IOy1Fdb96hd2CmJR7xOqti3OOPKTXfsz9e8V99OXjwoGtq+n/JnerpK+eca2trc4FAoO5pq5GRkbqnso50xx13uMsvv9z98z//s7vgggv+hx0Hjl08gQUAAAAAwK+hqalpzo/1BlY4HHannHKK27Rp05z6pk2b3FlnnWW2/61vfcv9wR/8gfvmN7/pXv3qV/9G+w4ca3gCCwAAAACAo+wDH/iAu+yyy9ypp57qzjzzTPfFL37R9ff3uyuvvNI559xHP/pRd+jQIffVr37VOffsm1fveMc73P/+3//bnXHGGc8/vRWLxVwyqZ+gBF7MeAMLAAAAAOBttf/68Ypfoy9vectb3Pj4uLvuuuvc4OCg27Bhg7vzzjvd0qXPfix4cHDQ9ff3P7/9F77wBVcul90f//Efuz/+4z9+vv7Od77T3Xbbbf/TIwCOObyBBQAAAADAb8FVV13lrrpKf+fjkW9K/fSnPz36HQKOIXwHFgAAAAAAADyNJ7Bw1Ayd7Zz/iBCrxn162xkdpuOKrTpxJTqop25mqa5Pn5WV9dqwThtr2q0TTmYW62eFZ7t12ltsRJZdtru+ncwqvW3nA3qfo5foGJyGn+g0rbFTdepULaTbb9ypxzI2LMtuarXRzn4jiUmHbLmZJXp7X8U45yv19k+89WZZf+mn/kzWgzndTrZVpxZZ6WeJIT3Ogy83EpTGdDv+gpEqtExHNOV2139haL5b77MW1H1s2K0Txaz0KuvR+bQxl5feqeOx9r9W77fnHt3/8XfM6nbaUrJeNeZ4zfgTTjVqnKtxPRcm1+p2akt0wlzkSZ2WVkzpfiYO6vaDRhLW6Gn6/MYO62vIbyRwZV5Wv4PQDt33oF5iXeOAnq9W2uATH7xF1lf805W6/T36OrHmbLFRb7/ubTreL1PS94iJW/VNK7NSr78zK/ScOv73dsv65NePk/UDr9aTNjhj3IOGZNnlW3Q7P/3Ribr9Lj1u00ZaWtfD+lrvv1js1wgU2/eH+hxWp411zaevz11fXSPr0+/W60gpqzuUXq/HLDagt6/qZc3V/NZnjnR94vYlsh5O6VZmlunrPz6s+zm7XJ+rSkwfQHRM73dynW7fWmd9upsukNPtZDuN1yQiWdhqe7pP10v68nFBPUVcOD2/FLyGw/rcHn6bvkf49+hk27Yn9WBO9xqJ3UeMQ8V4XXEs8dXsNNwXgpf6AiwUPIEFAAAAAAAAT+MNLAAAAAAAAHgaHyEEAAAAAHjbiyCFEMD/DE9gAQAAAAAAwNN4AwsAAAAAAACexkcIcfQkS87F5qYCWSk4USOJbfx4nSpkpdrkW42+1HT7Dft1Q1Yql9X/sg7mMpPtwlP17ZSadWxOoKT7WMrryzeUNRLXorr9vj4dlZi/b5GsZ9utMdNjk9qp48mGztCDVluso9WiW+pT9pxzLjet+3P8t/9U90cHLrnpZbq+7F8zsr7vTU2yHjPmcnBSn6/mk0ZlPXdXh6xHW3QsUj5YPz6RDj32rY26jerdep+JIZ0kN/QSnZRUbNHpoZXo/P5mEpnQJys7rJPe4jrQyQWNVCuf7qYrN+jtS03zS/LsbU3L+mRJz/1yTLcTnZJlN9ulx7OW0AcWHzKSqnSom2s7p35t2BvUi2z0BzrGKzyi51piUMeQWmmDey75/Ly2t5LMrCTcB7et1P8Q0ue8p6LPVWRUj31kVK9fD+/vk/XKOiNpL67rlZSe/KWsvkatlMbYiHGvHNT7HTlZz6lyXNdbl03W1dIzOumxIzUj69ONeiwzAWMOPq1fR/h36nUkvMZIJwzqNbyx30gn1UGSrmSsj4t/oMesEjZSkY0k3Pgh3U5iWO93vGK0YyTnWamRqZ1GiuIG41rco9tJrzLmpvH6K5iv395aG60U5YYDul5oNvo+oNeFcEZfJ/7y/D5nFh03Uj8X63quXbffcERCZs245x1TPJZCyEcIgd8+nsACAAAAAACAp/EGFgAAAAAAADyNjxACAAAAALyNFEJgweMJLAAAAAAAAHgab2ABAAAAAADA0/gIIY6aaKLoAvG5CSilhE4PajhsJDdNhGTdbySphGb0s7z5Lt1O804jks54azfbri+ZyJTebzmiE2MSIt0n16mTjApG0lBkn05umlqt++Iz0rQOTyRlPRUw0m46jZRDYzXxl/V+q/qUuOqkTifLLNUnpWokwDUcMBLXanr7YFYfb3aJTqqKTBjpRP15WQ9P6wM+1KXHf/kvdDt7T9IJdo0i8C5npEuNZfQxtVaNsRnXyZDVkE44cwHdznSPniRBHfrlAlkjVtCvxzI+bMxNfWmZmnbpX8j26PYrPfpcHdzbLusxfem6QEGfr/RyXbeOKxzX61piUF8TM8Z56Z9srqsV0rrzDcb1n+3TaZ1FY11r3KPr800nPO7Wq2TdZ6QHhkf1AVSievuplXosQzPzm2z+vfoaqiT1utn0pF4fZ5Za66xxLfbp/iSNJLn4oE4iTQzo9Wh8vR6HckZsf1CPwVBFt1E11rXYgF4XrHTPUoOuV7O6neCIHntrTvnKRlyfUQ7k9TnMtei5aYQrm69Hio16zsYHdD2S0f0pNuodh6f19i1PGffuoLWu6f63PKNf+OVa68enrAMpzTYqxmu1UpOeg1Mr9DF1btYphLGnB2W9nNNpz9ZrWeu1bzluTIYjT4k+RccWPkIILHg8gQUAAAAAAABP4w0sAAAAAAAAeBofIQQAAAAAeJqv9uyPV3ipL8BCwRNYAAAAAAAA8DTewAIAAAAAAICn8RFCHDW5qajzF+YmVnXt0aliIyfrdMKmAzoyxV+ykqF0YoyvaLxX69OJMVPLdQpRdEL3p7FfJzQF8joyZnJdfUROZMxItZrV+6wZh1Sd51Udj+pzEpvQ5yT8mN7x4XN0Cs7Uap14l9yrj6vQqtuJjhkJk+26HpmSZTP9rKoDply2Q8+p6Y36nJfjRkrbgNHPhB7/shFV5zNiiJoO1M/lXJce+6UvOajb3i/LLrNOJyVayZPOb6Ry6cvNnLMzy3SUlNVO44BO3wtl9Bj7Crqh3b/fqNtZasQl7tH9jKaNBNFJPT5Nj+tz6y/r7WcW6XVq1Fi/ygl97TYe1ONWCdSPTzSlExcDBT0G1ZAeg7xxnceH9LEGcnp7K23w6ffeIusnfUpvbyVhViJGsqUR+hUdN9a1Zj324VndULFdt9O8U9dnF+t1Krlbls3+F1JGMpyxfTCvxyc6ZqRJXjBQVxtIpeS2I3taZd1XMhJyl1v3YX0vs5Jkc8Z1Yt1zU89My/pMr143ix26nfH1+rq1PqIUMEJarfXRSg8sx/UOYiN6XUgv0+PZ+qReG/xFvf3QGfp4+/5Tn8fxdfqemDxQ38/YqNzUVY20wWy7kdA4pK+39HIjuXFcj0FhVaes+zP65teyLSvrh8/V93RrXTgyCbtS5PNuAI59PIEFAAAAAAAAT+MNLAAAAAAAAHgaHyEEAAAAAHhb7b9+vMJLfQEWCJ7AAgAAAAAAgKfxBhYAAAAAAAA8jY8Q4qiJ7w27QGRutNtMj37WNjSj66W4kYjkt+q6L10P6PrA+foSCOaM/jTqHVRDOh1npkf3s3V7fUyQv6xTpPItuo1AXtdjaVl2s07H7NU264SgydW6nfCUHpuwkbg2tVpv3/moTs0JzupzUtFD7BoO6P2WGoykyuN1spKvoM9t4pBRf0aPWyUmy25yra433KMT79LL9fatP9bjk2urr4Un9diM/nOvbuNivX3jAT2W8cNG2mBZz7VQTp/zhn49xpklRqpoQbczvVinWmU7dX/8RlpXbFjXkw/GdftGqljOqFvrV7Zdn9tSwkgP04FULjygjzezRLcTmtHjH/y35rpapMFKqTOutxX6mJr263NoJaU17pNl56vo/Vppg1v+UqcTbrxZb9+4X49NUV+2rmKknPl0wKS5rgUa9To1dLqeg9Y4ZJbr/lTCRvKcMfen+3RHE8P6wKZW6Gtxz7frbyzWPDZu/2Zqacv9xvVjpOylVxntPK7biY/qOTt0tk4bTBzS+60G9Ng0HNLtV8LGOn6mXsCCWd3/9PE6trDtft2ffKtup9Cm+zlxnD6RNb2Mm4mjg2fouZY3kjkrsfr+RyaM1OI2PZZWCqkVARnUYYNu7Hidxmo9LhAw2jl0vh7LUqPuz8gpxuvEIwIdK8b+jiW+mp3M+ULwUl+AhYInsAAAAAAAAOBpvIEFAAAAAAAAT+MjhAAAAAAA7+Nje8CCxhNYAAAAAAAA8DTewAIAAAAAAICn8RFCHDXZlUXnj819jzS5V0+5zAr9XmqhTafsBLJ6++Zt+rniyXV6+1pIp9pEDhtpg8YVU9GhXy40o+tDp9e376sZaX2P6eSgvW/TqTP+HbozpQ6dalVak5P1wP06WWm6z0pFlGUXHdPbF5p0NJF/fUbXDxlpfUbK4fGn7ZH12P9dIetTxhyMpPUcmVqj9xsd1e3ke3RaVzqht48O6fHJnKEHuvHh+vjD2VV67rgWfc5jm5pkvWQkw5V1IJrL9ejrtuthPQbTS3SiY8szevvAuXqOZMdadIeMjxtY17PV/3yrsS5EjKSqbh1tlTlsDJwhOjq/pE3rWm/ap9PGrDS2Sq+Ya6P6XHU8otvoejAr66Mn65StdW/bLusPblsp6+FRI0nWSBWz0gafvFqnEw6W9SL+u9f8hd6BobBBX3NNjXp8yk/puVw10gOrIV2PDBhRfk7Xcx26ncSQbmVmkZEyeUBfu0Nvq59TpZyel6GYnsfhsL4+D3foe0TLE7JsXj8zL9fnZGannrOpnUbinZEgnO/U/a/E9fqS3CXLLvWUkUhrnMOl39X96X+zvk+kHtKvJazk32ynLLtCizE3J4y5aZSjY3p8QtP17VeN12SFVt2XQn3gqnPOuUrUSCHVt0rXvEOf23LMuIcaaaYx4/4fH9TbTx5ntDM8d7+VorUeHENqzlsfIfRSX4AFgiewAAAAAAAA4Gm8gQUAAAAAAABP4yOEAAAAAABP89We/fEKL/UFWCh4AgsAAAAAAACexhNYOGpC0ZLzx+Z+EaW/pL+YstCiv/jS+iLr0LTeZzmu/xRSO07/QnSL/gZNn/7+WRcRXxbqnP1l0NZfZmrirWOf/r5al2/VX3DbvXhE1me2dcl6S6f+4utzuvfK+r33nCbrDQf1QVlfBN28S38Jes34LtGe5rSsT1b1uap1FWQ9X9HjFijo/lSML1nNLNHv8ycOyrKLjen2Z40vm4916y+JDu3SX6Lf0TEp6/2r6r+1tqFVfxnx0mbdxlBZfzOtP2dcV349ZqF2/YXV1bD+AnDrS1ADOT2Wq1pHZf3JsP7i66AeBlfVy4vzGV90W+nSX3bsC+p+tif1uU0/2qD7Y3zxcGO/br/QZMzNkydkvVjV37Lc0K/323F6/Rqzo7hIbptr052Pj+jF0VfRJz1TiurOGIEblahup2J8sX7jfj1m1pe1Lwrqc5UY1gt2tt04XuNmUKroSWgFA4Qyuv+lNn3TSgzLsjOWR1eJGWEWU/p4Z3r0eQ/N6nbaU/XjPB3V60I8rPcZ9BtrbFh/ybrPuNCrCf26Y/0i/U3ZW3NLZL22R49BrtNYNxuML/quGAEp+hbnika4RiBnBLwY9z5LLWh8CX3rvJpxNSNgILtUj0PzL/T5KseNMAsxDolB43WHcc+KTOq69Rqu1KjbD83o67AaNi64Rj3HawE9Bj7jFLZt1R2d7TniS9z5rz4ALwIsZQAAAAAAbyOFEFjw+AghAAAAAAAAPI03sAAAAAAAAOBpfIQQAAAAAOBppBAC4AksAAAAAAAAeJqvVqvx3jF+ozKZjEsmk+601/21C4bmJkrlk/o904oRTjbbo+ullI5i8ed1+4seMFK8jP4UmnUiTXhKXy6JEZ08k2/WSTLRyfr0HSu9qmm/jiAqNejtJ9bN78HK1qd1Cs7kKiM1x1AxwsPig3rMJjbqemqHHvuykRIYNBLyQjO6PnymrocnjXM1LstmGlCuXdeTe4wUMh2c5RLDege+qm7HX6qvhzJ6Xo4dH5P1QF63HdDhey7bpc+JlQBVSOnrzVee320oNqG3n+7V7cdG5te+dU5yxvH2fVenOuYW6wS7A6/W7SSf0dduWZ8uc90M68BRV9Qhk65qpIQ1inTCkpEE1tSvE8Wme61EMd2Xpn3G2m6kFk6t1O1bKaeWhgFjbTfSBu++7R9l/ZRPvlfW/cY1ZCer6e2Ds7peMJLhTrnoaVlPhXRS6D3fOUXWrTlVSOl60/5f/Z5bMeZ3dNxI/TXSQ62U4MnVel2oGre4xGHjHpEx1hFjruWb9X7LxvoSHzKSOfuMNMBuvb6nntTrSHqtvkYX/3h+6+Nslz4B1vhE0nq/4xv0CWg4aCSOho3URXHvCxr3sunFuu9F43qz7n2lRislVPfRmsulBiPJ13j9MnamPue+sB6zpd+eOwfLpbx74MefcOl02jU1GTcEj3ruvy1Wf/B6F4gYLzhfAJVC3u387MeOyTEFjlV8hBAAAAAA4G2kEAILHh8hBAAAAAAAgKfxBhYAAAAAAAA8jY8QAgAAAAC8jY8QAgseT2ABAAAAAADA03gCC0fNzKKAC0TmJr5YyVOBvK5byW3+sk5uUUlsztnpNbExnY5TaNaXRr5VtzN+in4vuLVvQtan7mqrb7vNSCBaptNWzKSxlG6n4YCxfaORypPS28eGdfvBrN4+PGskCjXodspRPfaBgrW9MReM9KDmbXp7K4WopIPkXMNBIyErpNtPrzT684xuJ92nz0tsTG8/8tL6dKKOn+u5kxjS837seL3PkJF8ZqVyzi7S14OVshXK6jliJUZVg9YcNM6JcaezUsgaD+nxaTqg2x8/MSXrVkpg5/3WOmWln+l2rHRCKyFztle3HxvW50tdc83b9YU+vkF3phLWfem5e1rWMyt1RFtkVKdvhWas9FBj3YnML57QSoe10gY3f+JWWT/p01fJesNhPdcs1jXR/Iw+3m2jx8m6lWbauUun3g6dqSdzJWrct5brOdX2ZP15LEf0tsG8PqbQjB6zUoMem0UP6iTJ4VP1MQV1QKPLduh++vXUdNN9emw6Ns8vXTE+pOuN/foXrGTI1Dbd//RyfU1ML9fjnDhobL9M7zcyphdanzFu2S7dTyvdNn9pfQps9h4dy2klzEamdD2z0khFLeoxqAX0uc32GCmnxlharzW77tHnfHaRHuPxIy7/SqHi3I/lpgBwzOANLAAAAACAp/lqz/54hZf6AiwUfIQQAAAAAAAAnsYbWAAAAAAAAPA0PkIIAAAAAPA2UgiBBY8nsAAAAAAAAOBpPIGFo2amr+r80bkJLlZ6YHhS1ysxXa8GdL15l06MGduot4+O6UvASlezUsUiozoZJnuoPm3QOefK7fXt+6pGUuKI3mf6JTotquEJ3cmpc4xoJUPD40aq2DxTvGr1AUHOOecW36XbGfo9nXLW8w2dsjNysq5nVupz2LRbv29fMxOgjJTAlbr/ER086Qo9OglrNK7nYHKnkTZ4nm4ntrc+7m3kXB3F6MsbyW2DsuzCaSNZaZFxfR43I+uxH+gIKCsldNHP07J++OP6Og9/P6X7YyTh1Yw/4Ry8yEq21L9QjRj96dBzubpHR1uGpq01QI9/vs1IsFqh14b2u/VA5Jtl2Y2dXL/fXLuOko0P6THofHBK1g+9Qu90ZoVOPouMGouvodCsz5WVfFbYoNdHn/ENvalNen200ga3XHOLrK++TacZVuJ6v7WgHp+ZPj0XFt+t14tSQq8BAxfoORI17kOhjN5vrlP3f+AVYnsjNTMyqdfGYkqf28i49TdZ3U5usR6b2TVGWuqwkaZnBEnGB/XYTKyb370+OqkHKLNUH2+2Tx9X6yN6HDLGa4PIDiPm1DhfPr1blz3BaH+nbr9mvMSw1t/Cw/WJgz4dwOuKSX1ufRUjVXB+L3dcOK1/IX7ISnrUg2n1p3W7nmyZvl/tdU3FeJ0DAMcS3sACAAAAAHgbHyEEFjw+QggAAAAAAABP4w0sAAAAAAAAeBofIQQAAAAAeJqv9uyPV3ipL8BCwRNYAAAAAAAA8DSewMJR4+/IO/8RgVVL/0G/Z5pZqhOmckbKVsBIwYlfcUjWa6M68Srv16lo7b/QKV6DZ+pom0Be9ye1WyfGzHbWR8FMnaQjfNqe0GM2HdZtx4f14GQD+s9EQSPVKjSjtw9ndH3sJCNhMm0ktxnJcL4DOplo9Hgj7WqJHreXrNsr60+NrpH14jqdlNTxFWPOLtMHEB81EvtGdYJVZZGea/6n9TXhMyZ/TOw3t0xu6pqX6GjI+E/0deKr6GOa7da3kNKwPoeBgm5n6Hwjxss1ymqlMi3rExt0+5EJI5HOWEdqRqpgxUi28s/qaKdyWddTu3U71p9yYxO6P6k9eu7vW63bybUb16iRutrQV58CWVpsxFh9VycrZnv1OWx7SidkHv97enAe3t8n6/69eq6FZ41kW+McNjXqxMiSEdtVjus0xobDei5baYM7/+BWWV9xx5WyHhkxEkRP0fGnB1L6vASiRortw3o8k3t1fOPoCXoN6LlPb5++KlNXy8zofbav1Smkh0ZSsl6Z1Sd38U/0XDt0pZHSaiTPFYy1t+0evVZPbNDb1zr12EfHjdQ/4wmPUpP+h6579RyZWWykMT9hrdd6v9ZrgGBet1+aNdo3gpH9xu1gttc43ofqf6HmN1L/jPWrrC9n17THuHcYfUzuM6IYjTlVvnBW1qP/kZT1zBX1149zztVEEqNz9Um7VvIuABxLeAMLAAAAAOBtpBACCx7vxQMAAAAAAMDTeAMLAAAAAAAAnsZHCAEAAAAAnkYKIQCewAIAAAAAAICn8QQWjhqfv+p8/iNSeIwIFCudLLVXp/jMdup29mzrlvVag46M6dghy+7w2TrNKGikDbY9qdOMsh36EotkjPgzwUrN8fXrZJ/J43Q7jQnd+WpNx+MEs/qcTPfqsS+16TEIbdFjUCnr/VaX6miipu/pc5Jdqfu5++urZT2gQ9FcJa/HOVDSc8dKM8ss1eMT1SFhbsWZOjlz6ttLZH1sVo9nsal+PAOTettYj04IK0f0ObHma6FDt+NCensruTE0offbtE8nNI1kdTuL7tfdcTV9Dq20q6m8TozMnqDnZi1nJG3O6HYKzfp4W7fpBKvpXn0ec806/aypSadMxgb09hZ1RSei+jovNRgJZ5P6+hxfr8/h5Nf1AlZZZ1yHST3Xiu26HmjUY1x+qkXWqxHd/6ixjlgqcd2OlTa45y2fl/Vz3neFrKdP1uOf2qLHudgky2ZKWXxgRv/DCSlZHn6JnvsdIv3QZzzCUKrqzqRSel2YyOrrJLNUj0Flr64HlutjDQzr6yeYNxJ7J3X/F504LuvpXI+sj54iy66S0NeEzxi3yITuZyFlrEdP62t9cqUet6YD+n5gvYbx6+ZdOa77k9ypty801rdfNgIdw2kjqXZKb28l8Baa9RiHp/RBBWZ0pOPsQZ02mCjq/U49o9ep5LDevhKdO5YVY8wB4FjCG1gAAAAAAG8jhRBY8PgIIQAAAAAAADyNN7AAAAAAAADgaXyEEAAAAADgbXyEEFjweAILAAAAAAAAnsYTWDhqwlsbXCAyN6qt/LHDctvs93V6YPllaVnPH9ARUMv+TafgDJ2u04Mm1+k/nbQ8pROsgkZa4v5Ldb1xq36PuNBSv33DDp3a5HQgj6s06D4u+6ZOGxyaMFK2jN2mV+l6dEzXU1t1MlFiSCe3ja3XMUF+I12xFtBj3PSEkWZ2gp4LTTv1srfku/pcpfv0AMVG9YnxGcl20yt1fw788wpZnzlfH29wWrc/u7h+PtTCRornf3bJevydQ7Ie+4iOXFx0r44ymzhOp04t+U8dxTh0jp6bM0visl6d1sd1+Dxdjw7N71bnM0JCF39bz4Wxjfp4Cxt18lSpSfdn9N1ZWQ/+TCdVTa/Uky3xcz2exSY9p6x1MPJoc10tekhv6zf+HBaa1fO+Zbve/sCrdUO1uD7Wpif19d+8U5/EodONORXWxxXK6P4EdRCembhWC+r+R0b09lba4M/+7xdkff3/vUrv10hLDRnriBEI6A68JiXrlaj+hdYnjRTb4UV1tVyHXkunjeTGYFZvb0wR56vpdmoho/3H9euLkBG62vRH/bJeuEMnyU58d7Gst+3U98qO7xzQ7Vysk3bzl+oUUt/39bow22ukzLbp9S5xUJbd0Bl6Lhe7dfRd6/362p05U6+D4W362m0YqD+PU2uNZEjjeq4Y17/z67nWuE9vf+jchKxHJnXfgx16IXnDRx6U9Xv+4DRZ3/9hY93c2TDn/1eNxEwAOJbwBhYAAAAAwNN8zvy77gvCS30BFgo+QggAAAAAAABP4w0sAAAAAAAAeBofIQQAAAAAeBsphMCCxxNYC0y5XHZ/+Zd/6ZYtW+ZisZhbvny5u+6661y1+v++xLNWq7lrr73WdXd3u1gs5s477zy3bdu2F7DXAAAAAABgIeMJrAXmxhtvdJ///Ofd7bff7tavX+8ee+wx9653vcslk0n3Z3/2Z8455/7mb/7G3XTTTe62225zq1evdp/61KfchRde6Hbs2OEaG3U6j5LbkHP+I1KEGr+k08+qOqzHRX+kU84CDfprE/e9Xqfm1CI6Pih2UF8CoZxO5cmn9Hu+qYd0mk7JGK7QTH3/iyn9Z5zmZ3Q916X7MvwSnYLjztHJRMW8HrOmTbqdqj5U869QMz06AbJ5p05om+nTO/AbCVCZtfofIiP63FZ1UJI7dL4ez6Zdevt8q5GKuFdvnzhgLLcX6mS+Zf9Lj9u+N+g0o6Y99f3PrDSS1S4elfXs9/T16V+m470m1xgpmz06dWr47PpUO+ecSx+n22/cZCVD6XJoQp/cgO6OmTZY1kGYrv9VRncKuiHry10bjBSv8NN6wShHjLl2t25n8u06vbV0r04z7HzYWGMurZ+boxN6XUht1vO1kDJSPAd14lpwpkHWKyl9EmeWGkmbRhqgr6KPtWok0pXajIXHp4+r+Rndn5k+PRuip+jrP32y3t5KG9z2vltkffl3dJqhayrJcve/G8lzg7qZ0ZP0xZhvMVJaXzVeVwuU9drYFtdz5OBhnaaX2KHnYHKfTuadfa2eU4VFegzKGX1vGvuWfgGTNpLwah26P+W4Xniiy9fI+tRaWXaNP9DjY613kUl9DhsO6P4X9DLuIhP6nNd8etwyK3U7DQ/qe9zsYt2f2e76/bZvNlIwjdeaQfGazDnncl160KaN67ltq96+EtHb+/26n1//6oWyPvNuvR6Fd+j1LnFE8HfFuBcCwLGEN7AWmAcffNC9/vWvd69+9audc8719fW5b33rW+6xxx5zzj379NXNN9/srrnmGvfGN77ROefc7bff7jo7O903v/lNd8UVxothAAAAADhKfLVnf7zCS30BFgo+QrjAvPSlL3U/+clP3M6dO51zzv3iF79wP//5z92rXvXsowX79u1zQ0ND7qKLLnr+dyKRiDv33HPdAw88INssFAouk8nM+QEAAAAAAPhN4QmsBebDH/6wS6fTbu3atS4QCLhKpeI+/elPu7e97W3OOeeGhoacc851dnbO+b3Ozk534MAB2eYNN9zgPvnJTx7djgMAAAAAgAWLJ7AWmDvuuMN9/etfd9/85jfd448/7m6//Xb32c9+1t1+++1ztvP55n5ev1ar1dWe89GPftSl0+nnfw4eNL7gBQAAAAB+HTUP/gD4reIJrAXmL/7iL9xHPvIR99a3vtU559zGjRvdgQMH3A033ODe+c53uq6uZ7/EeWhoyC1atOj53xsZGal7Kus5kUjERSL6y1MBAAAAAAD+p3gDa4HJZrPO75/74F0gEHDV6rPJKcuWLXNdXV1u06ZN7qSTTnLOOVcsFt29997rbrzxxnntK7E15gKR6Jxaza8TWhoGdD2zTD8kWDPivYKdWVmPbNbJVkEdcmQKFI1UN71bV2rUHU3uqU9dG9+gU2QiaZ3Q1rDfSNmq6j7OPJWS9cRhYzCNb6YM6AAlVzBSp8oJXR89SScTtT6h2883Gyleg3oZCxtfxVYyQhp9Fd1+fFTPzUBRz81yTLeTOGSkIj2iE6Oy3cZ57zf6OVLfTytdKj3ZLutG+J7zl3Xfw1N6++i4PreFlLH9kJ7Lk6v09q1GwlRmhd4+nDb+RGqUfWUjQa2q51rzM/pcZdt1mlauTe/XaN4FdGCnqxnPUFcf12mDVb0MuvRyY50VczNqpHg27dfpWGMbjeuzVycuxoZ0+6Wsnp1WemByt24ns1yf28iAcd0O63aWXf20rG8bPU7WF9+tU/8OpPRJSW3R11AtKstm2uDeN35B1n+a0+f8gz8zglqMBLvwlB63YNZY7zbXT36fHho3GkzJujEELrVLX4fpPuM3Nus5FTPucVaqsLWQ+At6bMJPGWmD48a9u1e3U41YiXdGMqSx7ljJmVZib0yH2JrrUcOAcVyL9S9EjPXaukerZORIWh9TLm8k56Zk2YWm9fZ+I80v26H72DCo52Zlr77+49N6DBq6ZmR9tmgkdu87oj+kEAJ4EeANrAXmta99rfv0pz/tlixZ4tavX++2bNnibrrpJveHf/iHzrlnPzp49dVXu+uvv96tWrXKrVq1yl1//fUuHo+7Sy+99AXuPQAAAIAFi4/tAQsab2AtMJ/73Ofcxz/+cXfVVVe5kZER193d7a644gr3V3/1V89v86EPfcjlcjl31VVXucnJSXf66ae7u+66yzU2mn9+BAAAAAAAOGp4A2uBaWxsdDfffLO7+eabzW18Pp+79tpr3bXXXvtb6xcAAAAAAICFN7AAAAAAAJ7mq5lf0fqC8FJfgIXC+MpFAAAAAAAAwBt4AgtHT83VfdFieEYnw8x26Lib2Ij+04aV9BZL6PigckknvZR1SNi8WemEfh3MJVPdIpN620rYONYJI9lnkX5fuho0UgWNvleiRurfhD6HpZLevmIEQIXTRvqh8e2cxaSVlmg0Y9QrUet49XHlm43xDOn2gzndfjCv2/fV9NwPp/XkKcWNVCQxp3xGH/1Gyp41F8oxI3HRSHSMTBrtWAmQRsJZ1Eq7Ms5tKamTngqp+d3qgkYKmbVfq/81Y7fWuhYyktus9iOTeo5Uovp8RceM814wzle8fnsric1ak/1GwlxkyrjeWnTf40NGql2fbt86V5Ww9edyY/0yrqFUSEfYWimwpYS+zgNRHTFphIq50LSuuyY90Fba4HkxPf7W+mXdh6x10FpL1Imx5nfFuGeFZq1FXwvP6h1MNemxsdLuouO6fSuZ17rHlRqMVFcjOde6hqwUwmBW7ze7SLdjnauAcQqLDbp941ZmP6Fi1M3XiYv0DkKz9bVAXt8Lik16Ua7557cuVCN665qRSG2pGuuRdY9uaxAH65zLlfSCcWQypJUUid++W265xX3mM59xg4ODbv369e7mm29255xzjrn9vffe6z7wgQ+4bdu2ue7ubvehD33IXXnllb/FHgPewVIGAAAAAPC2mgd/5umOO+5wV199tbvmmmvcli1b3DnnnOMuvvhi19/fL7fft2+fe9WrXuXOOecct2XLFvexj33M/emf/qn713/91/nvHHgR4A0sAAAAAACOsptuusldfvnl7t3vfrdbt26du/nmm11vb6+79dZb5faf//zn3ZIlS9zNN9/s1q1b59797ne7P/zDP3Sf/exnf8s9B7yBN7AAAAAAADiKisWi27x5s7vooovm1C+66CL3wAMPyN958MEH67Z/5Stf6R577DFXKhmfMQZexPgOLAAAAACAp3k1hTCTmfsldpFIxEUi9V+WNjY25iqViuvs7JxT7+zsdENDQ3IfQ0NDcvtyuezGxsbcokXGF9wBL1I8gQUAAAAAwK+ht7fXJZPJ539uuOGGX7q9zzf3i/prtVpd7b/bXtWBhYAnsHDUBIo1Fzji2w3HNuopFzES9aaX67b9RmpO03dadV+M5Lmqkaw0cKHR/jM6BafxoE6kCs3o7SfWhOtqgfz80utmO/VYxkf19v6Sfr+6mJRlF87o/kwcp8es9Um932yHkSo2qNuf7dHtN+/UqULZdt3+zBJZdrEh42bv1+20bNOxQgMv15F6ft1NVwkbiVdGAldmWf0ccc65fKuRkPVU/XiW2vQ+rcRLf9Hoy1LdTlAHIrlaQPcxuUuf8/iIkbjYoPc7fJqur/6Kvg7HN+oUUmvsY2/VfwU9eKBN1v1P6OPNtevjbbl4RNYz93XKelAflhs5Vc+R5G69fTijD3j0FL19Q3/9cfl1aJ4LZXXbrdt0fc0nn5L1n/7oRFmPjRhzaqce40LKSG8dlmWX6zDS94wEznu+owetc5ceoIEL9LlqeDgm61ZamPXkQfe/6zjAD/7sClm30gYf+pvPy/qJ/+sqWU8c1u1E0nohDE3XH5gRoOaW/lBP/MMv1fHBoyfqQbvxrV+T9b/98O/LemaJvm9Hx40kWWMdCad13QhFNgWMay48rvtZMlICrVTXmW4jBXpMH5iVPBkfNVJgjbTHoJG6am1vpTonhur3O7VSX29N+4zUv5LxGnGeKZs5455baNT1tq1G+0Yy7OzXu2U91m68rqkd0Y6Hnlx6sTl48KBravp/i5l6+so559ra2lwgEKh72mpkZKTuKavndHV1ye2DwaBrbdX/3QO8mPEEFgAAAADA217oxEEjhbCpqWnOj/UGVjgcdqeccorbtGnTnPqmTZvcWWedJX/nzDPPrNv+rrvucqeeeqoLhYx3WYEXMd7AAgAAAADgKPvABz7g/vEf/9F9+ctfdtu3b3fvf//7XX9/v7vyyiudc8599KMfde94xzue3/7KK690Bw4ccB/4wAfc9u3b3Ze//GX3pS99yX3wgx98oQ4BeEHxEUIAAAAAAI6yt7zlLW58fNxdd911bnBw0G3YsMHdeeedbunSpc455wYHB11/f//z2y9btszdeeed7v3vf7/7+7//e9fd3e3+z//5P+5Nb3rTC3UIwAuKN7AAAAAAAJ7m1RTC+brqqqvcVVfp7xa87bbb6mrnnnuue/zxx3+9nQEvMnyEEAAAAAAAAJ7GE1g4alqfzLpgcG6KzYGLdXpQ0UgbjI7qZBV/SW/feFDH9YTTOl5t4BWNsh47rC+N0Kz+U8vI+/Oynn0mJeuJQ2KfEzrxZ2yD/oLGgJEYlxjUUT0Nh4yx2XFY1ve9Z4Wsxwf1fhv6dVpftlOn9RWajVSxPUaSkZHik9yjB6KY1F+gaaU09vzLflnf895luh0jfasS1cc1dZYe/zWf1eO28w9Ssr769ilZ3/Hu+iivts1yU9d15wFZ3/NHRnTj2mndzm1RWS8l9LnKtxh/MzHKuVb9D70/1gtAepWea1Yql5kw9VWdBHTcgzqdcOzsRbLe9Yiey7k9HbJe69H9saR26LqVnLn7Un2+okM6hWzR3RN1tepTz8ht93z2DFlv3KvP4eO3nijrwS59rhoG9VjGB/V1VTNCuab79Bgk9Kl1kSk916yUs6Ez9boT1cGTLrlXr9fxgRlZP/CalKwnjHXZGQl5FSOB10ob3PqRW2R92ffeI+sNu/XF1fsVMWnbW+S2pTYd19f7Qx2jmu3V9/NPDr5D1p0OdHM9d+qoyoHX6nUh36bvBY37dPt939Pn9uCFuv9N+/VJXPwjPQ7b/1hHC7du1td5rkPPhcoFOkax+lCzrIcvGZP14QF9fqP9+hqKjsuyC6eN11+n1q8xgbw+pske48Wj8RRNqEmvL4336HvNjz78GVl/x65LZH36872yPrVSr5ut2/R6kW/Vr1mPfJ1VKRgLIwAcQ3gDCwAAAADgbf+/5D9P8FJfgAWCjxACAAAAAADA03gDCwAAAAAAAJ7GRwgBAAAAAN7GRwiBBY8nsAAAAAAAAOBpvlqtxnvH+I3KZDIumUy6dVdd7wKRuYlPfh2g4gopXY9M6XpFBz25qvFMoZU2FtLhaq5mtBOe0pfLxEk6JSgyqlN/YsP17eTbdTpMQAccunJM1xc9oFNzxjfoQQtm55emF5rW2+fb9PbNu/RJHzpdj41Ph4255u16v9lO/T58qT6U79n2jTnY9YhOMxw+RSclWXMkPqT7OX66Tj+KDuj2Ewd1O+W4HufMmvqBi4zpMbbmvXVd+Ywks8Qh65zML/XPqi/9ge6olTY43avnQs36U40RyBSZ1MdVSOlfsOaCtV8zZStjXIt6irhgXm8/2z2/v01ZiX3qvMRGjT5GdCOt2/R6lG/VJ318ve57NaT3mxjQ+7XGJjGsF4CZRfokFpt0+9b6W4nr/UZHdDslHbRnqsTm95ItPDW/azFhpKuOnqXHbd9r/0HWT/2r98q6uq9Y8y/bM79zPt2nF6qOR3X7g+fq7eMHjbmQ0v2JTBhjbFy31j0uOqbbt9KPrXTVGR1s54JZvX22V59bX8VIBN2r7yszS/V41uL6gGP7jUlozIeQDm90+db68anosFFXjes++orGOUzqsWl6Up/cmVNysh7ZrheMQqvx2nFCr4NhHQzpisbrncgR21eKebftCx9z6XTaNTUZv+RRz/23xfF/cL0LhI0T/AKoFPPuiduOzTEFjlV8hBAAAAAA4Gm+2rM/XuGlvgALBR8hBAAAAAAAgKfxBhYAAAAAAAA8jY8QAgAAAAC8jRRCYMHjCSwAAAAAAAB4Gk9g4agJFGsucMSfJnJGOln3fTqpamqVTnoJ6M1d0z6dJFdo1lM9MaAj/sZOiOv96iA5V4vqlB1fVaf11Pz14xA30p8Wv2OvrB/85nJZH3ypjpKLGel4Vtqgv2ik4MXmlzZYCRnpZE8a7Vv9MZKbrBTF1B79C5EpfRKzHXquxUZ0+w1DxvGG9d8FGrcbc9lKmTTSBq30MH++fvtqwEhEG9NtTK4z2jbGPt+i+zi7VP9CcFqPTdsTup8jp+iINqs/VsppZEK3b6UEpvboBebw2Tr5KNetd5x8Wq87kSmdPBUo6H4WG40003HdjpUUWgsY8V7GX5DDop3EkL5+Dp2jJ+boCXo9ss5V18O6/XJcn6zx9XpsomP6WKdW6H42HdAdCs3OL9kys1z/Q65TD3LPfXq/wy/R/bTWTetatNbHgLG+R9L64mrYrftjpQ0+dt2tevuP128fNlL2QjPzS25cfLfue7ZDX4ddP7POrb6uJo01udBsjHFBb7/kJ7OyPt2nk+om1hnt/Egn3uXa9euXxXfrGD9rnZ06QV+Lzbv08U6vlmUXSOtrtP0Xeu6Pr9fnq/NhPW4HXlV/vJWUbnvxnfqc542E2fFTrPXFSKrdo89hqUlv3/KUcQ/tkWWXGNJzvPPhrKwPfmzuOFSyBee+oNsGgGMFb2ABAAAAADzNV6s5X807n9vzUl+AhYKPEAIAAAAAAMDTeAMLAAAAAAAAnsZHCAEAAAAA3kYKIbDg8QQWAAAAAAAAPM1Xq/Htc/jNymQyLplMuvfe9wYXaZibXLT5r06RvzOzSD8MWGrQCS1WAlS2W6cHveq8zbK+5fqTZX22U+/A6s+i+3U6zkyvTqTJN9e3E37dqNzW97U2WR9/vU6dqQzpBKLfPecRWX9z86Oy/teveKOsH75Yx+NkztKJSIu/rdOrsu063Sd4yYisB76kxyFy5aCs73+iW9Y79OGa47nsZr39zj/QiXQtj+vjckYA3A1/8Y+y/pl3vV3WX/35e2T9H7/2qrqa/4xJue1Dp94u6697+5WybvV977t0vbtjStZnYu1RlQAAcSVJREFU/6NL1tPrdLLSym/piMb4DUOyvud7K2Q9uc9KCZVlN/Aq/Q9vPFmvI3fuXS/rrY16XRh/QI9DY7+Rxjar+1Mykvkuev/PZf3e687S7RjJon/717fU1bYVFsttb7v2dbLeuE+PwfDpjbKeWa3PVesyPZenMnq9O6F3QNb3fFtHpc2eoxPa2lO6njXmcuNhnX428Ao9xqmlU7LeFNVJmNP/skjW3WvHZTm7Wa+b1lMDoWldX/zVHbI++NY1sh7I6R089tf16YQfGz5e79SQrepE1037dV+idzXJ+sRJeq5d9dKfyPqPh3VMa+Fv9Tk58CY9Br2L9bnKfF+3Y6UuFlr0utDQr9eF5D49N/tfq/u5/A7dfrZT39MTgzoFOr1MJ5HOdutrInHImJzGfUglmvrLVqLr/F5TWsmt+Ra9/bJbd+l/SOqTOHSTkX78tZSsT67Rry8aBoyU6SOarxTz7smvXOPS6bRratLXhVc9998WJ7790y4Q1q+/XgiVYt5t/fqxOabAsYqPEAIAAAAAPM1Xe/bHK7zUF2Ch4COEAAAAAAAA8DTewAIAAAAAAICn8RFCAAAAAIC3kUIILHg8gQUAAAAAAABP4wksHDXb010uWJ6bPjPbqadcJWrEyxgqOtTGxQ/r92SfmNDJecUGvX1IB2eZaUCVmD6uYF6n+JTj9dund+q0qA69S1dK60FoOKSPad9sq6z/KLhR1qdP6JT1Ykr3J7hfp8LUgjrpKTap6yPTOlWszfgr1+hMQu/XCAO06uW8TlbKG2mJvqKeszNLdPvRcb39f06dqNtZrM/vD4Y2yHpVTMFqWff9pgmd+jW1Qu+z46EJWQ8O6Cim2aROVvIZobe1qHGdNOhz4jfiA4M6tNBMmLJSCK2/qB7Kp2S9WNDX/1hNz81qXO+glNBzpBrUB1A20gOfSusEzkS/kQh4hk5O+vF0/Vw7XEjKbePDOoGsGtZzsKCXIzNpLD1jpE4d1EmvA6mUrJf1KXGlnJ5r01HjZqN368oRY7IZcy0zoxvyGd8MnOvQAxQo6znoK+n9WnO/ZIVotetrvWacr/Cs7r9KHLy+8wm57e/tuUDWs2W9vlSreuytY/WVdec3p5fK+s49OiWwzXhdE9KBui7fZbz0NtYd655VadGpgsVJPT7FRmsh1PdiSzWox60cNe6V1vgbu7Ve35WN9TExWL+DqpEe6NND5maX6O0b9xsnpdWY+G0pWa42WKl5et2c6dFjGR801oV23Z/gEeHKVeuCBYBjCG9gAQAAAAA8jRRCAHyEEAAAAAAAAJ7GG1gAAAAAAADwND5CCAAAAADwNlIIgQWPJ7AAAAAAAADgaTyBhaNmY/NhFzkiRezhIZ3iM2uk8swsNhKXdHCLy7frP4Wc3r5f1n/YqtO6mg7oeJxsh06GmV6sU3/8Fd2fqgi8auhL630eaJZ1X0wPgr+o07SiAR2/E7KigIy/KvmNVKtij+5P7XF9bstG8mQkrPuZa9Pvt3c3ZWR9Z0qne0XSuj+JbTr6yFfWBxyc0XMhuUuWXUGHeLmIXx+v9cWgzdGsrO9J1ScxtcWNWD6DmcpnKLXouZOZ1mPfbMydli4990NT+pyUjViuzHJ9ADX//NKxQuN6rm0ZWCzrTY05We9omJH10bt1nGlBX+ouqkMgXWRKT5L2qN7vjh6drhbI6XaSR0ZYOef6c3oiT63U56r5GT02PffqubnvD3VfOlL6mIYq+tyO7NExh3EjhCsU05MzHtb16rjup5U8G5nU6077Wj33S0ai3rSRYNkW1+M8GkzJeiWo21n6Q91OqU3P2WyPbic086unnVlpg/+y4sey/r5Dp8v63lF9zjt/MijrmZfrRM1kSI9BY4eegzV/StarIT02Mzl9rTQa17O4DJ1zzoWm9euOihF419Cvrzm/kfBpvd4J5nU/8616ezMhz7g95Tp/tUS956h1PG/sM1DUfQ8Yfcm36XbC+mWHK7XqmNPwPh1JeVKHbujhyPxiWq3kxiOTsyvze0kAAJ7EG1gAAAAAAE8jhRAAHyEEAAAAAACAp/EGFgAAAAAAADyNjxACAAAAALyNFEJgweMJLAAAAAAAAHgaT2DhqPnFZI8LFudGo2Tb9ZSzgvDyS3WyXSCmk9tSd+v0s3sHV8p6w4CRNtiu39sNzeo/tYRndPKUlZwXG61vZ2xCp9e0zuh91kq67XJcll25prcvGYluVkLbzHEF/Q853U5kQqd45Vbp2JyKkb7V3K/P+UTOOOBpncYYntJzqtCs+594RqcHBV7SI+s1vz5f1hyfKOrzHh3T47Y8PibrT6TX1tVGxxvltpOdeszKRkRbvke3E5wyUqpadYpX2JjLIzt1sl1Tsz7nS6LTsr57Qs+dcMa4hoygtErUSOWL6bk/NWmcQyPBLv1SHQVVG9fXRKHFSuXS9emybic0rSfhxIW6nZ3Zrrpa1UjBSgzptq0vuD14vu5j1ejjdKOxfUX3x1fS9arxqicc1vsN+vVCmNdT34VmdDvFlJ6bh0ZSsp5Kzer+GOf84GF9DRmBdC40q9s5/FK9NvT+cFLWEwP6nntk+tlzstX65LxsWafpWWmD/7fnYVlfvWeNrA9doNOPa/2y7HJ9+t4xO61HM2Ak6lqJvfmsPt5ws5EwZ5xEM3mu0bgHVY3EyB4913xVva7Ndum5nBg01gAr3dZYGwrL9Drb9h/64p3tqO9Prks3Hhsy1gujLxV9qlzAeBkUyOmTXkvqC+L+fp02aARYusSgHsyplfqcBI+4FfuMfgPAsYQ3sAAAAAAAnkfyH7Cw8RFCAAAAAAAAeBpvYAEAAAAAAMDT+AghAAAAAMDbarVnf7zCS30BFgiewAIAAAAAAICn8QQWjpqhTJMLHJGG5W/TCTDhKf0XjKYndARMLaDrsXGdgjM4pRNgks36PdxIWvdnaoXePrlX77cSMZKwAvX1+C4j7saI6kkY28dG9PaPPrVC1p9o6Zb1rrJup+1ner/ZTiMRbYmO67ISmmZHdPJRcJVerqZ36RSfiJFIF8jrZLvOx3S6T6FPt18N6/HJLJdl17RPb/+zffq8NK7Q4/y9/RtkPTJRX8vN6DStu/rrEwudcy5g/EnDX9RjE9CBji4/pWOzrDSqgJGsFp7UkUkPDPTJenxQj3FVD4NzRn+qMSPpqT9lNKQN+5KyHn9aj0/YWHdCM7r9ckxv//CTOnX1uB0Dsr7o3l5Zv6tFzxMl1amv8/iAniTBWZ12V/PpdjIBvYbHBvTJzS3Xc6flfr2OHO7QSZuzYb0edU/rsS81GGms4/riqszquTCR1f2MG2mmiR06ki61y/gFw+iJup/ZXj0+0336Wll8t97vpv31SYFVI3l276hee620wZ0v+6qsn3j/VbJuXVcPHeiT9fAenbhoJf+2bdVzZDClz210Qo+ler3gnHPFpK7neoxz7tPbFyb1HEwc1tdQsUFvHx/S13olbKSrGq+/Grfo7Wd0mKQLiXTb2LA+VitJupzQ28eHjARb47+eis16bGIjab39ULOsB4z2GwZ0gm2xSc/N6hHLUaXI00IAjn28gQUAAAAA8DRfzVsphF7qC7BQ8BFCAAAAAAAAeBpvYAEAAAAAAMDT+AghAAAAAMDbas76atgXhpf6AiwQPIEFAAAAAAAAT+MJLBw1Tf+ScMHQ3ESWtJHQZqWEZbv1nzaCRmpZOabrqXt0Qotl5LU6fWfxN/QlY32JY2xMJ95N99QfcMJIUPMbaYCJQ3qfU0ZwWOfPjRSskE73Si/TYznbq/vT/rhOPio06f1aKT4tW3SKV2qXPifhjE7rKxnJUMOn6zStqtGflJHaE5k0kvMyxpzN6XrDfbqjfiPhz/fzlKwn99XHOkYn9FhWIkY63oiOhhw+zUhWGpZl17JN77dspHIu+VFO1qeX6QQ43yN6TnX8fETWZ9a2yLplIqrnci2rj2vFP+vrfPREPW7+80RkpHMus1MnUjXu1+OWWaVTy6xrfeDNfbI+u1i30/Kj+nXTWqsTw3rMplfq623D656R9V1f1Qlz4aeNOWUkMQbyOsmsFNfbtzwhy853ZIzXf5lcrc/JogeNeFXj5dbin+gLPbNUr2u+mu5/cp9OJ0v3GYmXs/qc3/jWr8n6JwffIesdj+p2sh1G0t5dTXU1K5208yeDsj50gY6js9IGt370Flm/4Pf/UNYz/Xrd8Vd0R8MzRmrpcj0GLVv03KkZf1KOTulrq5jU7Se36frgmbre/WPd/uQaPXesNWCmV19zNb8+XisFNlgy0mSNNEY1f6w++vVS7VK7dWdyrXqfESM5e3y9HoNwr056XfIj3SF/SZ+T2W7dfjmq+xnMz+1nbX6hpADgSbyBBQAAAADwNF/VftP7heClvgALBR8hBAAAAAAAgKfxBhYAAAAAAAA8jY8QAgAAAAC8jRRCYMHjCSwAAAAAAAB4mq9WMyJtgF9TJpNxyWTSLf30p5w/OjfFpuNR/TtDL9PTMDymE6CshLZyo26n0qMTmqp5/RBi82ZdLyd00kuhxUrNkWUXmqlvp9Sk22jboutDL9dxMi2P6b5Pnq1T/NyUjuuJGGPfMKD7M7tIj03ACOUKzhjd2aBTeYIZYy4YqUKlXn28taweH3/BSEsMGUtkWR9vy1O6Pn6q7qivqPfb/KSuTx1npByKOeUv6r7kl+gLqPVBPRdik/pbSq2EybGTjLn8uO7P6Dl6kiz7J1l2+96g92udw1DGSMEyVHQAnAsb7QSzevvMCXoOtj6gd5Bv0e0nDhvrmg4Jc1Pn61THwD6dxtq4X7eTFu34+nUbkTHd9+ZdxvU8q9evgXfrueDfqZPhSg1GSuiEngvVsN7eaqea0P2MDOlrxZoLs8v1cUWa9b2pslenw1rrUaRvWu94s04cte43nY/oa32mW6+/U8fp89v1Mz3+Q+fWt+8z1tJgqx6bWr9OblX3Veec6/65bufH3/iyrL9m58Wyvn3LUllv2K+PNdtjXLcdev1teFInzCUG9TkZepmuN+3Q97iZpXr7mrE8xg8bx7XYuCbG9RypBvQ4FDv13GnYra+tmT69fWS0/nibn9HHOnyW7ksorY+11KzbiXbO6r78tD5l0znnAkYKcfySIVmfuFsnbVpJlfkO3c/2x+b+/0ox7x7/p7906XTaNTXpvnrVc/9t8ZLf/VRdwvkLqVzKu0f/7dgcU+BYxUcIAQAAAACe5qs9++MVXuoLsFDwEUIAAAAAAAB4Gm9gAQAAAAAAwNP4CCEAAAAAwNtqtWd/vMJLfQEWCN7AwlGz/pR9LpSY+2XFh7eskNsGp/XDgD79XaHms4PWl7ufv+YZWb/vzpN0f4wv3Czr74513ffpL+idWKu/rLkqynnji13LMd2GL6IHp5DSX4B62or9sn52ao+sf+Vzr5L1YqP+xtdcj/6C1bbH9Be7hqf1l45G+iZkvfTv7bKevygj68UxfbLaH9b9GT3L6P9DepmcWivLrmqsqvED+rxc+KZHZP3xH58s62veuUvWt965rq6WX6W/RPzKU+6T9e/ce4Gs+yr6ehg/Xtc7Vo3Jera/Q7cftF4A6rl2yoa9sv6L+1fJepPe3Pzy4plX6YSBxS2Tsr5zR7es9y3W4zDa0iPrQf3d685f1uOTj+uF8HdWbZf1J791gqzPduhr4tL19akb25d0yW0P/e+Vsh4o6L5PrNNfWF3K6pMSXqO/NLma1ddVLqHHpuVx4wuuX66/fX39okFZP/C4Pl7rHM6u0ePgM+ZgYLmeg8HHG2W9sMgIYNDfX+58Fb3jzBI9F3ruHJb1YmOnrNf8en2/6qU/qattTusvR0+G9GDm+vSxPnSgT9Yz/ToAwPqy9v9c/QNZXzd6mawHdugv3K9E9Rgs7dHrwtBevS5kO40XPMYLpKLxPdKdD+r6zNvSsp66R881X01fQ/FBI+ClR8+1orHsW6/7wpN6bkb0siwFckYAiBEk4M8ar02NLz5a9JNRWa8kdfjFWFHP5YCRuWO9xvUZ3+6eO+KWWzGCTgDgWMJKBgAAAAAAAE/jCSwAAAAAgKeRQgiAJ7AAAAAAAADgabyBBQAAAAAAAE/jDSwAAAAAAAB4Gt+BhaNm93i7C+TmJk0F2vR7pokB3YaVfubXgXEus1zXcxWd9NLzUx3RZCVkxcZ0f/a/SSfYNOzU/VH9T7Xo1Kn06hZZf8P6rbJ+594zZH3PZJusz5T0sTb160GuRPU5nF6lx6DtMR0R1P9qfVy5kaSsd6X12E+XdDKRr6z7GRvTEUfJp/QciY8Y4xA2EpEyup+TJ+p2Hh/rlfVsm25/PK8TtaKnj9fVEn7dl3vHdFqf37jepnv1rSKqA5dculcnLjWNGumee/QcrESMMdu3RNYbh41INze/L6mI/USniu0/X7ffvlTP8YOjzbLeMqT7E8rq1LJwRs/ZxKDe/uELdarbmA5dc7136fZL1fo5+Oh2vcimjCRDS8Og3md6vb5uS0E9B4MjOqXVCOVy8VE9ZjM79XW1NafnWqdxnWc79I5Dw3p9KQR0fwLD+poIGfe+ckaPQ0kHyblo/XLxX3Xdn4HX6rTBYspY7+L6WvnxcH1a6s49i+S2jR36njg7HZX18B697vgr+pi2b9HXiZU2uP3sr8n6qT96r6xfdu7PZf0bd71M1ptG9FgGjOS5Fd/W19Do8UYi5ZhOSx4c13M//1b9+qhpk95+9BW6ozUj4S9ySM/ZsHGvb3laT/7Bs+vXhmrYuA514KKr6SFzlQY9xsH79OuUA7+r2wkb+82k9brZPKvHoNRgvM56Qp/bQy+bOzbV/IvgC5tqbr639KPLS30BFgiewAIAAAAAAICn8QYWAAAAAAAAPI2PEAIAAAAAPM1Xe/bHK7zUF2Ch4AksAAAAAAAAeBpvYAEAAAAAAMDTfLVajYcf8RuVyWRcMpl0p1zyKRcIzU0LeukHH5a/8+Mvnynrsz16ekbGdRJL52M6NWdqpU50KjUaqWJbdTvZTp2aM75RtxPIW/X6WsszOmHn8Nk6pSY0rdvuvl/3fbZb990yuVa337hPbx+b1Gk9hUbd/5oRWubTgVFm0ouVNjbdZ4zPzwuyHpzVKT5DZ+pEutYndTsjp+q5lm/TB7boAX1guRZ9YNb4zC6qP14rvap5p55rH/7br8r6tde/S9bjo/qcD55lJCs9rfuTb9HnKmwkvRWa9fa5TiO96im9X2vuVI1LpbFfz5Hhl1hpWrqdYM5IY4zp47KulYCRKBWeMdJbdfddeoUeiPZf1P9CdESvL4fP0XF38RE9YSthfayz3ca606+PyUqqTT0zLetDZ+v0sMikbscc+6LePt+sxzK7SG+f3K3bDxrntumPDsr62Ld0WqJF3YOcs49r7ETjGp3S9UKzbqfnvvq1Z7ZTf5uFdX1Wonqf5bjevnmXXu/SS/V+A4X5pR8/dt2tsn7BpX8o6z7jZffQaTpFMW6klkate+5VE7Ke+KyRnHexXr9iI3qc48O6P5llxlxo1f1seUKf4MxKWXapZ3RdJfPldeiyC+R0PdttJMBO6T5a1085biTMzhhruzHHv/FHfyfrH7nk3bI+vlG/Tsl1zN1vpZB3O2/6mEun066pqUnv3KOe+2+LM151nQuGdBLpC6FcyruH7vyrY3JMgWMVT2ABAAAAAADA03gDCwAAAAAAAJ5GCiEAAAAAwNNIIQTAE1gAAAAAAADwNN7AAgAAAAAAgKfxEUIcNWMnOuc/Iijknr8/Q24bm9UJMIGCTm6p6KA3t/+1Ok3Ht0hHz6y4SccK9b9SJ4k079RpOsVO3U54MCTrseH62qG36cg4f79OJoqcppOG9izXaTS+rJGyFdPH1PlTY3kwHpce26C3X3xPVtZ3XabPlT+v31dvfkrPhamX63Mb3q4jqUZO1pMn16nPVctT+oBHT9TthHT4mSs26f5n3qGj6qLfScn67O9mZF2N2syYHoOZdfqY/vaqt8t6/gTd9+k+HdFWDev2gzq40fkruv2qPiUu26PXi4YDeu4E83qOV4NWmpmuH3ynvs4rRlJVqUGPT+N+WTYT+4IFXa/5dD8Pn6vryzcekvXitxfLeuF99WvM4S0dctuIXo5crl2PjZX6Z53zyeN03VfWxzrTqxPXEoeM9EAjCdNKtkwc0sc13ae3jw/q9ic2GOlnk7r9wh06bTC91kjOM+6h4bRVl2UzfTbXqevWvfvAm+r7GRrRbVRD80vTbNuqt59aru9NuS69fSWqz8ll5/5c1q20wR9/88uyvvq298p6x2a9TuXa9FwoVnQ9fpOe+5NrjLTBUSMh70w9GfI/0+3ne/SJ8c/odbAS0ftN7tDnpeGwbn//a+vbj4zrfVrpgd336X2OnGrcy3K671EjIbusX8a57BJ9T/mzP/kT3Z9X6bncsl3P2anVc/9/1Ug3PabUnPk69AXhpb4ACwRPYAEAAAAAAMDTeAMLAAAAAAAAnsZHCAEAAAAAnkYKIQCewAIAAAAAAICn8QYWAAAAAAAAPI2PEOKoaV097gKJuUltie/PLx0nqAPmnK+sn9n1lYwEmKye6gcv1CltAR0I6HKt+j3fZf+k04PKcV33F+v7b4Q/uaX/qQfhgGuW9SYj7ap0jk6va2uclfWJxYtkPTqqx764Tvdz8pCO3+m+20iMeouO8Ssc1nOnOqnTAKvG6uYzUs4qLToNKFDQDc2s1Oc2fkBvnzisz0vb6TOyPlvUxzs7qcez9aH6A8ueqJOJFi0ZlXV/MSXrPT/Ws3Pnu3TipWVqhZFGFZVl17FFj3H2QmNh2N8oy9O9er9+fcpd5mQjLrFspBwaKVvBFfrcFtK6nyF9KTrn0/ud7dL1RN+krGc/3y3r8aKRflapP66VZx7Q297Yo+ut80sgq/n1ulAyrk+nm3FFHZboqgG9AOQ79RjUGoy1fUrfszo26/5PrDOOt1PPtUUnjut2vqsTI2sdOl4t/JReL0oNxjgbl3Tf9/RcHrhAz+UlP9GTOf+J+vtQvstYY3N6bc9n9dgPpoyEti1GUmWHvtEv7RmT9W/c9TJZX1bTY2+lDe78g1tl/YxtV8q6lZw3dKFO5eu6S8/xcsx4bZDQ7Xd/Xs+dzBI9d1Z8U18rmaX6vBRSer+RaX3fGjxDn/dF99XvN5zR53ZqhW4j36zX0tYn9bGOnSDLbsU/6ddZzkiM3fEePcblmO5PzXjsYHyDbn/xT+eum+VS2e3XTRw7qrVnf7zCS30BFgiewAIAAAAAAICn8QYWAAAAAAAAPI2PEAIAAAAAvK32Xz9e4aW+AAsET2ABAAAAAADA03gDCwAAAAAAAJ7mq9VqPPyI36hMJuOSyaQ77bV/7YKhufFi5ahOSvmdj9wn6//x9+fOa99WslVkSk/z0ZfotJvkTp2cVTUS7Br7dfrO4fP09pHx+vbbt+qUrUpYv888tULXQzosyvmMKz04q/8h22WM5aTe3hr76dV6bBp36TEOZ6z2ZdlFJ/T2aWN8rP7nW3T/c0t10lNqq54MAZEw6Zxz6ZWy7NqeMFIdG3R/Gg/qeZLpq/9EeNsTOq1v5GSdvmklkOU79XWy5hadZjh8no6Ay3XoYwobwU3W9ZY4rPtTbNTtR43r30qqzLbruePXU9k17dfnJJjVv5Bv1TuuBnX/s526P8079NxUc8E5e44HjNDF8HT9uDX262MdOkOfrKgOdHP5Nl23Ugg7HtfnPJDX9fH1uj8Nh/T2E0aKVzmu+9NmJNv5Knr7QspIFdPLoAvmdDvNO3Uk3dBpOs0sOj6/9dRizZ2YkUobntH1XJsYB+PeZN23C83GdT6hz23Nb6zt7fNL5YuNGMmNxrqT3GskWBqvgx76zOdlffl3r5D18JiePBEdQur8erlwOSOxs/kZPZ6jJ+v+B7O6HtLBwu4Vb3tE1rd84mRZHznVWDcD9edl2Xf0TWX3X+h1IRjU5yq4Wadszq7Vi2bTE/rCMkKFXdsTRtKuuk6cc8UmPcbtW3V/So1zx6xcyrtHvvdxl06nXVNTk+6URz333xZnX/BJFwwa0cUvgHI57+7/8SeOyTEFjlU8gQUAAAAAgEdMTk66yy67zCWTSZdMJt1ll13mpqamzO1LpZL78Ic/7DZu3OgSiYTr7u5273jHO9zhw4d/e50Gfgt4AwsAAAAAAI+49NJL3datW90Pf/hD98Mf/tBt3brVXXbZZeb22WzWPf744+7jH/+4e/zxx913vvMdt3PnTve6173ut9hr4OgjhRAAAAAA4G212rM/XnGU+rJ9+3b3wx/+0D300EPu9NNPd8459w//8A/uzDPPdDt27HBr1qyp+51kMuk2bdo0p/a5z33OnXbaaa6/v98tWbLkqPQV+G3jCSwAAAAAAH4NmUxmzk+hYHy55K/owQcfdMlk8vk3r5xz7owzznDJZNI98MADv3I76XTa+Xw+l0ql/kf9AbyEN7BeRO677z732te+1nV3dzufz+f+7d/+bc6/12o1d+2117ru7m4Xi8Xceeed57Zt2zZnm0Kh4P7kT/7EtbW1uUQi4V73ute5gYGB3+JRAAAAAMCxobe39/nvqkomk+6GG274H7U3NDTkOjrqExY6Ojrc0NDQr9RGPp93H/nIR9yll17KF8zjRYWPEL6IzM7OuhNOOMG9613vcm9605vq/v1v/uZv3E033eRuu+02t3r1avepT33KXXjhhW7Hjh2usfHZpJWrr77afe9733Pf/va3XWtrq/vzP/9z95rXvMZt3rzZBQJGXJIhmKu4YGluwkrNaOM7t50n6+GyfjQ3s0zvM5z+lbvnnHNuyQ91yk7/7xi/YLzl2/mQToaKHdZxRonD9cdViunGS0YaXfsTOlLowO/Ksuu4T1/uVhqV1f7gWbqdpj36XEWH9DmvGWNpJSX5jAQ4K10xcWh+iVGFVj0X2h7UxxuZ1h2a7tHH2/WI3n78OGP7h/Rf72a7w7KuxqfYpBOXrESk+LCRiJjUY7b/LZ2y3njASCBboY8p8pgxCa0UwsGirNf8emwiE3pSWXOn5tc7nlxrpSjqc9gyoCNBh05PyXrzLiO1sM1IUdw/v9TVWkBvb12LKll07HgjxSur2ygar5n7zjkg6xO36484VMJGklyLvj6tc2u1k9ylt7cSGqdW6Xbixn9XRCf1+mIl8I2eousd39HjFl1e/3ES55yb6dX9tNZZ63ib9hv9N0ysM5LqRDCqmcRozKmKEUBWNeZ3dEpfV/6ynvhW6mdALzsuNDSPxEXnXEC/XDDTBve+4QuyvuZL79X9mdXtW+mHjft1/yNpPW5dDxuJmrp5Fyjp9jf962my3tCst+98RE/ayTX1a1J6rU4PbLzfOidWmqae9+W4vmfFh63r3EhFNu5N1j0o32okZEeM14+JuSelUjRO0jHEV7PX9xfCc305ePDgnDeJIhE9R6699lr3yU9+8pe2+eijjz7btq/+fNVqNVk/UqlUcm9961tdtVp1t9xyy3+7PXAs4Q2sF5GLL77YXXzxxfLfarWau/nmm90111zj3vjGNzrnnLv99ttdZ2en++Y3v+muuOIKl06n3Ze+9CX3ta99zV1wwQXOOee+/vWvu97eXvfjH//YvfKVr/ytHQsAAAAAeF1TU9Ov9JTT+973PvfWt771l27T19fnnnjiCTc8PFz3b6Ojo66zU//x8DmlUsldcsklbt++fe7uu+/m6Su86PAG1gKxb98+NzQ05C666KLna5FIxJ177rnugQcecFdccYXbvHmzK5VKc7bp7u52GzZscA888ID5BlahUJjzWe9MJnP0DgQAAAAAjjFtbW2ura3tv93uzDPPdOl02j3yyCPutNOefVrx4Ycfdul02p111lnm7z335tWuXbvcPffc41pbW39jfQe8gu/AWiCe+7z0ke/ad3Z2Pv9vQ0NDLhwOu+bmZnMb5YYbbpjzue/e3t7fcO8BAAAALGg1D/4cBevWrXO/8zu/497znve4hx56yD300EPuPe95j3vNa14zJ4Fw7dq17rvf/a5zzrlyuex+7/d+zz322GPuG9/4hqtUKm5oaMgNDQ25YtH4DDRwDOINrAXmyM9N/yqfpf7vtvnoRz/q0un08z8HDx78jfQVAAAAABaab3zjG27jxo3uoosuchdddJE7/vjj3de+9rU52+zYscOl089+AfDAwID7j//4DzcwMOBOPPFEt2jRoud/5pNcCHgdHyFcILq6upxzzz5ltWjRoufrIyMjzz+V1dXV5YrFopucnJzzFNbIyMgvfVw1EomYX1YIAAAAAPjVtbS0uK9//eu/dJta7f89AtbX1zfn/wMvVryBtUAsW7bMdXV1uU2bNrmTTjrJOedcsVh09957r7vxxhudc86dcsopLhQKuU2bNrlLLrnEOefc4OCge+qpp9zf/M3fzHufoyeGXSAyNxWs5RmdajOzVCe3NOzXDwla6US5TiNFLWX0MaXbb9qhk15yHbr90P76L1p0zrlqaLmui7C0zAr9lFvPvfqx36mVOnGt+XFZdpPH6Xowq/dbCesUnMi4bmfieH0OawFdj4waY2x8N2XikO5nsUnXq0aCXeer9ROCJycmZf3nsxtlvRI3Eumm9H5zrXquFVN6fAot+gBKcd1+x6P13z2XXqOTmEoNeh4HdMCZ671bJyVlenUfrWRLX2Z+26f2lGV99AQdQ1Y2xibbqXfgMwKjZpbof7DSw2Ljup+DL0vJejmuxz/fbKxHe/V+J9boW3jBSPHq+Zk+jzPdup1sV/0ct9I6l/27Xqdy7XqdOhBaKuvhlCy7GeM6N5PPjE9LjJ6p70Gpp/QYFI3U0ny3PueN/Xpdyyw1UsKa9LmqJHQ/Jy5eLetTa2XZVSP6fFn18Lju/+If6fVx+KUtsr7kRyJu0Dm373frr91Kix7L0LSeO9Z6YaWlFpP63KaP0/u1Im9XfFvXSwlj7lT0OR+6UF+HkX59YFba4I7Lb5X1Uz+ht+/7vT2y3v9t/TolvlnfEJ65RsdAr/nytKyXUnq9zi0yEkH36vqBN+prpeGZ+lrqySm57e53NMt6aNpIsHzaSCFs0PXUNh2FHZ1okPX+i/Q5b3tCH2vZuHcPnKfn4JIfzV0Iy2UjfvQY4qvVnM9Db9J4qS/AQsEbWC8iMzMzbvfu3c///3379rmtW7e6lpYWt2TJEnf11Ve766+/3q1atcqtWrXKXX/99S4ej7tLL73UOedcMpl0l19+ufvzP/9z19ra6lpaWtwHP/hBt3HjxudTCQEAAAAAAH7beAPrReSxxx5z559//vP//wMf+IBzzrl3vvOd7rbbbnMf+tCHXC6Xc1dddZWbnJx0p59+urvrrrtcY+P/e0rj7/7u71wwGHSXXHKJy+Vy7hWveIW77bbbXCCg/yoLAAAAAABwtPEG1ovIeeed90s/++zz+dy1117rrr32WnObaDTqPve5z7nPfe5zR6GHAAAAAPBrqP7Xj1d4qS/AAkEKIQAAAAAAADyNN7AAAAAAAADgab4aeZv4DctkMi6ZTLqVH7reBSJz02fazhmUv3P4KR09Vw0baWlZ/d7ryk89pdu/XCfJZbuMVJuDOpGmpINkXM14KzjXpZ8tbv1FfftWmlah2fgHQ+OA3memb37vV/uMgCbrbe/YiJEAaaSHxUZ1P9Mr9Q4W3V+Q9fENOsUnvU4fwMpv6Hiy8MCErB9+9WJZrxlfC1fRgUuukNLjExvW4xM3xmdind4+kBeJce3zS/dsefUhWc9+tVvWrfQd6xyGdZCZSx7Q56oU0+1MHKfHIDSj61baoHXdFpP6uFqe1vXxjVYSpt4+Mq53bCVMxQ8ba4BRLiV03UqBHXypkQa2o74endJ99FWNut6lGz9OX0DWnI0f0mMWsfpj7LfUYKQKthn3mpyRNlof+umcs9NPM+t0+lfXvXocrDmbv9S4iH6g0wArEd3/YFYfrzU+0yv1NRqe0P1X65FzetyKOizV+Y1zWGgxEtqa9C8kt+lvy6gZX6JRbNJ1K2E29soRWY/flJT1XLueJNlOPcdDs/N7mf7YJ3U64cve+0e6P++ZkvX8fW2y7jcSPrOLjPNipEz6Z/Tc8ReMOWvMqZJIBAzO6rEsLNGvI5b26Hjl/iF9XblJnZBZC+sLN7FfT7ZyQo/ZceftlvXsy/X1v//jp8l64IjDrRTybtdnP+bS6bRrajImukc9998WLzvnr1wwaLzQegGUy3l338+uOybHFDhW8QQWAAAAAAAAPI03sAAAAAAAAOBppBACAAAAALyt9l8/XuGlvgALBE9gAQAAAAAAwNN4AwsAAAAAAACexkcIcdT03DvrgsG5qUCFX7TLbasX6mdwU0/r91itZKUdf79K1lvv0e3P9Ol6vtVIwcnJsksc1u2EjCQc9cyxlf6U2qOTlWa7dNvTvbre9oROwYqM5WX90Mt1NFRql5Fkdrbufy2oU3mml+vtm3bKsptcrVN/kvt0wlEgrxOO/vbrn5f1Nz+sE5pKo/p4I2O6/eCMLLvouJH0ZiXwxfV57PmZPo+BbH071YjuYzVopObtNtJA9WXr4mP63C67w0h0er1uqNigj7WU0P1c/FMdg2XNETPJ03j0PzZqpWDp4111u06wzC3RKWQT6/TxNgzo/lgJf1biZXKfnrOHXqbnQ+oZ3U5isL6dUkL3PVAyEin79MuM+JCRuGikciaG9XVSbNT9KTbqdtLH67mz9Lt6e39Bn/P9r9fHldqm+9P6iN5+ZrHeb2TCSFf8vk5FM1MLdZCcyy7S9eiorrdu1nMn12lco3frhTDfXj9prXPY0K/vTdb14Hy6L4Nn6rHPLtaD1vmgbj42ptde96S+zifX6PWoHDOSZHVAnitH9fZ9v7dH1q20wftu/aKs/87rL5P1qTXGvfsN07KevFMnsEXT+vwOnSHLru0X+vyOvkbPh6af1c+p1u36xdqe39Pn5PBj+oJYtEWPweQaIxV10nrNKssuMqHP7cT/6pP1A19YKuvBcT1mjQeO6EfxRfB5t1rt2R+v8FJfgAWCJ7AAAAAAAADgabyBBQAAAAAAAE/jI4QAAAAAAE/z1Z798Qov9QVYKHgCCwAAAAAAAJ7GG1gAAAAAAADwNF+tRnwCfrMymYxLJpNu8a2fcP7Y3HQY37T+1Gp0VCccVcJ6ekamdHJL9306HWf3JQ2yHjMSr6JGApSVFJhvlWUzGSo8VV+rhubXxszxOrKo+UGdsjP1Up3gEwzrxLKGuxOybiXDWRJD+gAiab3fA6/X7Sz+gX6/fex4PXfyXTq1bOU3dZJUMalPwHSvbt9K8YoYaYPTJxkRUzP6mui8X7czdIE+LleqH5/m7rTcNJ2Oy3rwgI61C83ovjQc1Oc292a938CPUrJupQR2PaTHbO9b9VxofEafQ78xZDV9al0hpeuViF4Xmtbr1MWJUZ3K1bBdX6N+I+QsNKv3m+3Q41beqBPgur+qo7Am1+hxy6yvT+yLDui+B2dl2fXcrefCwAU6uW12uTEIFX2s8QF9/ZTjxrnSwW1u/FydTmhZ/F09edLLdX9mT9WpaNEnYrLu08ujm+011lMj/az5Gb19wEgjm+nWx1XUobQuu0RfXKmn9DhMnSDOr3FL8c/ovoR69GQrTOr1q/vHemwGX2qsa0v1nJ0e1/fEwIS+fqw005JuxtS4f34ppIFX6/Wo9ZP6+v/hv39N1o+79SpZtxJEM8t1fyq9xmuP/foAfMa1njhkrIPd9dtba7VVt+4FtYSe375ZPb9jQ3quWQnWmQ163fEbr5VXf2VK1gfP1emkR76urBTy7pn/+zGXTqddU5O+P3nVc/9tce6Zf+mCQWPyvwDK5by798FPHZNjChyreAILAAAAAAAAnsYbWAAAAAAAAPA0UggBAAAAAJ7mq9pfrfFC8FJfgIWCJ7AAAAAAAADgabyBBQAAAAAAAE/jI4Q4atrvDbtAeG5i1eQ6vW1kUtcrEZ1GY6V1zfbqdLWWp/T28RHd0NAZOlWoeYd+Vvif/vxvZf2VP3i/rCcG6iNvZpbKTV1hkRGhVtTvP1tj07ZJp7YECkaiUJ+R+mUkEFkpiskdOhly/+t1Wkvz47qd0Kw+sLiR+uN8enlLr9BxQ8k9OimpaqSKxQ/rcfAZwa5+I+2x9WGd6maNf/NjeqBX/v7OutrWn6+W2y65R4/lyMl6nxUdXuViY3pu5u5tlnVfVY9N8w49Ngcv1GOT+oURW2Zk6lppXdZxLbkrK+uz3foXxko6hrQho/vZ2K/XkWyHnssBPTVd+xN6/AsH9Do4erm+Fn2P6ETA1OP1499134Tctv+1OgVrzyX6Ol/0oO57Jabnt3W9RTJ6LGPG2p5v1ddz6iE912pBK3VV9396uZ7LkR06bTBghJO2Pq3TyQptenwaDhjrspGuFjCuldiYHs/KBTqZzzegz69MG3TOLb/jV/+8TbZDd95X1TF+icN6MCfX6AUgflif29Q9OnIx/1Z9IUaeMebOmXrMuj+v50LOmJtWYm988wFZP9i4Utan1uixt9IGn37vLbK+/nN6+798wz/J+r1Ta2X98YeOl/WZxXpypnbra2L65fVzrTSlz3lwSs+pYNZYq1fqc1j6frusp95wSNbHZow5+1BK1mvGy5rZZfp6C0/rMRs7f+41Uc0ZN5NjSa327I9XeKkvwALBE1gAAAAAAADwNN7AAgAAAAAAgKfxEUIAAAAAgLfVnPl1AS8IL/UFWCB4AgsAAAAAAACexhtYAAAAAAAA8DRfrUZ8An6zMpmMSyaT7vTXXOeCoblJMNWATnopvEvHEBbuaZN1K/HOSuALZ4ykveVGO0Xdz6a9up1ch94+16lTfxr31r93bKXIWElpU2v19qpt55wL5vT2wbyup5frdhoOGWPQrsegmNLbF1t0slJwWqcEtTwpyy5Q0u1biW7ZM2d1Q0ZyWzmuz2FwVrcfmtbjkG/T7XQ9pLtjJfZl2/V+o5P124dm9T6LjbqNYqPuezWk650P6oSmmb4GWQ9P63M+tVxf0LFx3f/ZLiNJypjL1iP+VtJT1Uieazqok+fCGb3wzC7SF2+uxdixUbaSQq2EOWsdnDhet9O0x5rL9ds3HtRJYNlOfQ5rxprvN67bfKuVrmqkfhqhdrk2415jXIcNB/R+8zpg0iWMVMRi0kgtNPoZndDtlKNGO0bZTAodnd9LPOveat3j/Ho6uOZd+lpRa491vVnX82yXcY+bNa4THRLopo7TJyVxUF9YkXHdfsC43vKt+rjUdeWcc1NrdDtdD+t+Hn6Z3r5xr+5/+Ry9Xsd+qJPtrGto25/odMI1X3qvrIfTxn3FSGm0UlFn+4xEZtH84rv0Pmf/YErWpw6kZN2f13OtarwuiIwai7IhpINhzdesVjJ3QQf/1iV8V4p5t+0LH3PpdNo1Nenz7lXP/bfF+ad+zAWDRrTwC6Bczrt7Hrv+mBxT4FjFE1gAAAAAAADwNN7AAgAAAAAAgKeRQggAAAAA8LZa7dkfr/BSX4AFgiewAAAAAAAA4Gm8gQUAAAAAAABP4yOEOGpqPp+r+eYmpoyepN8zLe3VESpRHQznfEYYTWzESqrS9fCU7k+hdX6JfZf/wQ9k/f889nJZrx6qT1DxGakz46ca8VWGQMmIqTL4y0aalpEeWB7X7bQ+raOYci16mcm3zW/5CRT1OFSNZnLtRkrjPXpStWzPy/ruS3UsV9Nuvd+CkVrWsW5U1muPtMv6xFqdZtTYr4+r47376mrP/HSF3LbnvoKsj2/UcV2lZn3BNT+jk4Bybfq6so6p43E9d4ZP02PfYIyBlSrqM57wt5Lb+r6XlfWskSo4emJM1oNG4GXUSDOzUsuOXEefEx+xUib19rHFOvKqNKxTv1SCXXTzXrnt0B+vk/WacX12bNaJlJPrdN9TO401fFqPQeuT+nqeOC4h69lOWTZZKWHTy/T2PiOpLpg3Ei8P6Gtu6AwjIW/CmDvGnylrRlhafFSfl/AlY7I+uKND1qdX6/ZX3FEfW1iO6s7kW3U9Maj7GB/SkYgzvfq6jYzr9uOD+tyOvkK3H9mn28/36JO+4pu6/zO9ej2tGbf0NV/W1/Put+nrOXmnTkjLrNTt/+Ub/knv10gb3HH5rbL+b7M6lfYDd75d1sMJPf7J7cZriZfWj8PABXpN7grp6yrQqu+Ja7qHZX3HI32yvuK8+vuwc84FjbjU/f+q79EzvbLskrv12FhphqNnzp1r1Zzx4vlYUnNmqusLgk8QAr91PIEFAAAAAAAAT+MNLAAAAAAAAHgaHyEEAAAAAHiar1ZzPg8l/3mpL8BCwRNYAAAAAAAA8DTewAIAAAAAAICn8RFCHDX5Vr8LhOe+R1qOGwkq6fm9l+o3glT8Fd1+Ka5jfCo6qMYFclaik27/sXSfbiijU9RUqlAhpcfAVzQeT24y0nQKOlmpkNTHlOvU21uPRVuJbvmUbidYMBIdjYS29Cpdb92mjzfdp8fYYoQBuWpYj39oUh9XrsOYUzpIykUCOnlqfIneb2RSt5Pt0vs9mKlPnir06NSs9DKdNlhu1IMTHjXmVIuR4pkyYrOMy7wa0ds3HtBzZ3aR3t5vJL0F9DA4nz4lbnyjXhis7XOL9Nz05/UBB7PG+mIkw4WmjKTQJt2OVc8faJT1uDE+2Y76/idXLpbbWtdVcqeRlNigx8ZKzZvYoI+p5Sn9C/6iToazxrjQose4FtL1SFpPhsiYXo+yJ+RkvTSr59r0Yt3RYrc+WTWfvqYbBua3jhea9HgOD7ToX4jrcQikdf/Ty+rPizV3cu36nFvbV8LGOffrdqoBY33pMa7Psq4XWvUY+Gf0GGSW6pfeVpJcoGS8rknpm025Ra9HUeN11mSvnlP3Tq2V9XBaj4OVNvi7iRlZ//CMbqdsvC6z7q2FMfELxjpSruhzUhnVjY8k9TFVjXXh6f5Fsh4M6TkS0qGortBuzKnt+sDUWv2iVXPOeeljex7qCrBQLKAVDwAAAAAAAMci3sACAAAAAACAp/ERQgAAAACAt9VqHvsIoYf6AiwQPIEFAAAAAAAAT+MNLAAAAAAAAHgaHyHEUeOr1Kd2dTymt/3H62+S9Uu+8OeyXjaSW6wklpIOknH5bh1bFh7Wl0a2U7e/84vrZL12hk6SCWZ/9UeOu+7XST1jJ+rUqapxVec69D7jw0aaXthKbtLtW8lwhTYjxWtcbx/O6PazHUZykzGWgaI+VzNL9PbZTp1g5V+po6H8j+lEt/CoLLvDj+l0ooSRxtgwqOdOrtWY43e31dWW7NZpVGMb9dintum2rVS7xl36ZBUTTbJuJTfOLNKTqhbQ20eMVD4rDchKXFNpoM45l2+dX/rZin/W4zy1Qs+pipG6aKUclhJ6+4CRUFrSU9P5S/NLbyzWB1u68Q16MU0c0n2x5qu/bKTjGWPcuEfXq0F9TENn6DTA+JCxHk3odrJLjfTQDbp9n5GQG9mpo9UCOpzQ+Y1kyNb79bqfWam3n1ls/J3SuCase1O0X+/XmrPtv9ADMXpi/TputRHM67rV90KzFXOqy8VOPfGt4N/IISPp8aD+Bes6L6R0+6942yOyvulfT5P1nJXGaqT7DZ2h9xvcrxP4Hn/oeFmvnp+W9Q/c+XZZt9IGd7zrVlk/6dNXyXrmDONiydfPqZVfNZJhr83KemCVniTD/Tp9c/1JB2R970+WyXo5ZqQxG4fU9qi+J+ZbjJuWoeOBue1UigE3MK8WPKjqnJvfMBxdxvoC4OjhCSwAAAAAAAB4Gm9gAQAAAAAAwNP4CCEAAAAAwNN8tZrzeSj5z0t9ARYKnsACAAAAAACAp/EGFgAAAAAAADzNV6vx7CN+szKZjEsmk279Fde7QHhuuo2VANe4V7e1+G37ZL0zqpPhDnxglaxPrNMJUFZKkJVyaKUlzSzX/5DYr5NkIhNiHIxUldluIzFut44+sVK8su36/epgTp+TmvH29nlXPCzrP/vc6bLesm1G1g+dr6PSYsO6P7EJPcbFRt3RTJ+uxwd1+4kRnVpU8xvJed363Ian5zeeVsJcManr+VbdvkqSCxR0G1YSW9pIMut6SE8qq++luJEemNb7ne7Vg1MzPuRejs9vjINZ3R9r+8Z+3b6V8FlsNNaRuNGf0ydlfWPHoKzHAjot7Rdj3bJe+n67rIdm9XF1vGu/rB/8bn2ilrW+RCf1PxSS81t3sp3G9dBsnPOArvf9p47xGzxDJ65Z629k0kgtNJIws11GkqeRDBmd0HUrIXPmTJ2i1vCgnmzWNReeMc5Xk5FyalzrhWZZNpMtYyP1/anosE6XM+ZCYVlB1hu36IaCeT0G1hpr3efDxlhaCZDJHboemdZjHzD6mW/W95pASW8/eqI+rrZf6O0n1+pzXokYc3/Set2kty/rl1+ucb9uZ8s1t8j6KZ98r6yXGurbefmlOtHx3i/pRMeaka48vVyfq6ZdxnViXOfW3LGSeQvtehKuvl3HFu/7C92f8qG560I1n3f9H/1Ll06nXVOTTgv2quf+2+IV6//CBQPGovECKFcK7ifbPnNMjilwrOIJLAAAAAAAAHgab2ABAAAAAADA00ghBAAAAAB4W6327I9XeKkvwALBE1gAAAAAAADwNN7AAgAAAAAAgKfxEUIcNZWwc+6IoJBFD+hklUO/pyOLgl+pT8FyzrlDYb3PqTfpR3kbDuikl+v/5Muy/vG/fZesl2O6nb7v6gS7zDL9HnG+vb6d1qd0G9EpK+lNt516Rqf+zXTreBy/DnR0U2t1/d5bdNpgqKjHPviZMVlv+186DSzdp5elyVW6Hhsz0smMFK/xU3Wq0MxISNbzXfq8hI30sOQuveNcm643HDJi3Yyn0hsPGEmeB+rTycbX6zjNgA5oc4lDuo9W+p7VTsMhnRJmJcBVjUCh+GEjMfKw3n6617hWmnQ7PiMpbeQcfc5bH9ID0bxTNzS+Uc+p2D8nZX1XICXrwZyeI5VmIz2sQZadEWboxv5xqaw3FOv3WzTS6BKHdePVoF6sY+P6XpDtNK7zYb3flmf0uRpfp+davl2PZXTMSPEyEjWDOgzQJQZ1+/6ibn+2V8/N5E7dfnibThucXWzM8Yru/+wiHbvm18NppqiFZnT7nQ/rtLTJdfX9Lxtzyhrjtv/Qc2Rmkd6+GjCSZPuMtX1Sj03L03p7f1n3p8G4JgbPMF7AGH9S7nxEt3PgjfqcRAd0+6Ovyct68l59raR26wV+75v1+CS363GoGMGfmTNysm6lDW7+xK2yfuL/uqqu9vhfnyy3nXqVHstQk5Fs+YBeTKeO13Oh7WE9NtYYWJI7dDu7fl/3pzqt+9N0cO6kqhReBM8t8BFCYMF7EaxkAAAAAAAAeDHjDSwAAAAAAAB4Gh8hBAAAAAB4W9U5Z3xFxAvC+BYIAEcPT2ABAAAAAADA03gDCwAAAAAAAJ7mq9WIT8BvViaTcclk0m1816ddIDw3eiUn0veccy7frROp2h/S77EWk7qd5B6dMDPbpT8ta6UfFZpl2fmNFK9ZI83ozt+5Wdbf88H319UyS3TqTKHFSH+a1n0vJ/T2gZzePjZipPjp7rhqWLcTH9bncGaxbijXOb9+tmzXz2lP9+o5Es5YqVm6nu3U7WS79faL7jdS1Dr08U73ybKLDRmpbsP6eLPtup+F8zN1tfgPdfKklR44aSRPBrO6j6ldxjlZYvxtxLjbWEmS2S693+jo/LYP6vCtZ5NShZYd+txWQrr9YoORfthoJU/q9qtG+zVjOMPTevwn1ur1LrtY77dpl56zgUL9OLc8rQdzcrWO2cp2W9ez7ks+pQ82mDfWKb+xro3rNXlirU6GDE3r9q1zaKUNFt46Kev5h1tlvW2b7mehUZ8Tay7MGuMc1EFvZtpgYkifl5FT9Y6tJE9Lapfqi5GgaHw0J5+a37Fa7aRX6nYi+hS6fJvuZ9xYw9Nr9Fguuk+3P3a8HuPohJEOa9yjc136gJt2Gwm5xrpZWasTjUtT+lqPtOgTUBiLyboLGYm6z+hr1Hr9tfUjt9TV1n+uPpnQOef+v/buPD6u8r73+G+kkUb7aLMsC+/YYLDNZodgIIEUY8J6SUp8gcTQQtOQYsABcqGhfUHaG5yQG7JAgThNkzYkhS5ACC0QQ1wTVhsZAwbHCwjvsmxLGu2jWc79I0WpmO/PQQRbR/Ln/Xr5D/90/Jxnnucs40cz51tyik5F3rdFv+mLxPXNMtuvBz/S65y3UT0nZZv0a03rsFEb86o+cTvH62t+/3sCbzPJPtv0/75iiUTCKioq9E5C6t3/W8w/4nqL5jvRxcMgnUnaUxvvHJFjCoxUfAILAAAAAAAAocYCFgAAAAAAAEKNFEIAAAAAQLgFwW//hEWY+gIcIvgEFgAAAAAAAEKNBSwAAAAAAACEGl8hxAGTLopYEBucbtM7ScfIHLlMp9e8faOTSOUkuhQ26gSYLiehpWynTgnqHaPbKd6tPyrcPV3355Jv3SjrBeW57ZS06DZS87plveSxMlk3HShkQcRJ8XKuAuXbddpNwQ3Nup2/HSPr8XWtsr7lQr19sZMw56VveXVzkqdKdutjsGq17mfrR8fKeo9zjHj9Kd2u64EzXx2TdUNdU/S8FGZyt983Rx/fdS84CUrOJ+ELcwMOzcwsMdU5P3v09gU9Q/uofUGnrvfWOalcMd1+n3OqeOdKYUKP8d5jdPJR52R9sMXa9A72nKSvd7GY3u+EynZZb9qrk+3KnWtDyW4nsfNifU73/VvusZ84XCeQeaml3jUzVeyk2jnnbXe93j7tzG3xHl2Pter+ZJ1ESi9t0EtF7Fmh5ySih81NUUw7wW3tM/R+xzTqeiyh+5/fp68N7dP0QOT3OUmbTuptplIfy3nrcw+UbL6TTuykFvfW630W73auCzrozap+4xxsjmyhPgb7avX2sX36pCjs0Ml2Ux7SqX+JGTpNtvL1dllv+ky1rNes19edLZP0wemlDY7/pR7n7fOdg9a5J077J32MzPzOK7K+5m9P0NuLxME3rslNJjQzm3fDVbKu7/JmiWn6NdW+pvvefJJ+sfnJod1z02XeMa5TYPccry+E6SMG34yzPU4k70iSDfyBGw7ZEPUFOETwCSwAAAAAAACEGgtYAAAAAAAACDW+QggAAAAACDdSCIFDHp/AAgAAAAAAQKixgAUAAAAAAIBQiwQBn33Eh6ujo8Pi8bjN/fT/tWjB4BSbjkl6zXT6+ZtkfcPj02XdS84rchLsvGSr1pN0Ip0ldT9rV+kkmc4pupnKuToKK3ggN4Ev7aRUeX3vOFzXi/Y6SUzemDmpXF3jdTslu5zUqZjePlmjt/dSrZI1+gXXv+AkzFXpueqcJMuWKXLSfZp1O92zkrJeuk4n0nmpaDZTR+rFntEJU/nJoR3LHVNza9Vv6jbSxXrsuybotvsr9U5r1+gx85LP9h6rz58xr+hEJ093vW6nwzkPC7r06/WuI14yZM06ndyW53S/c7zuZ17KOYeceYl2O8eCc/fuqXeS7Ur0PyhM6O2L9uZuX/2mjphsPbpE1kt3O0mv1c4cOtc1L2GuYosefG9u26brH3jXKT9VVPenv0Jv3x/X7Zdt0+0UJvT2nVP09nn6MmVRJ3TM62dFk95vy8f0OEf69QAd9pRuv6cud/uIc/54yZCZQj0GBc554p2fe+c4CY29+jUVOOeJ136+M/Z5ztuOzlP1uVX+nD63uiY51/cxOuUw0qWP/UjKeV39ul5+tE7sjRXogUhn9LleXaxfb8u/T5T19uP0wNU2JHJq0Z/qJMYXvnWfrJ+1/jzdly59Q+/q1m/YMiknmddJmC1ardtPVuq5Ld8qy+51s2TH4DnMJPvsze9/xRKJhFVUOBeBkHr3/xbzp15r0Tz9/ms4pLNJe+rt743IMQVGKj6BBQAAAAAAgFBjAQsAAAAAAAChRgohAAAAACDcSCEEDnl8AgsAAAAAAAChxiewcMB0Tsiz/NjgNVLvQeK7uvWDDzPeg82dX3jkOw+y7atxHlJc7jyg+zn9YM3+Ct1Ofq/eb8vmGlmPi3Zi7fqBstl8vc+Ifjayle7S7SSm6PVq7yHFqbhuJ7JzaA/ETtbqjlav1Q929dbVs/m6P97D49NlevuKzbr90l26n321+knC3oN4Czp0vbNVH8xlzoOHvXPFnAeMx9pyf9Cvnw/vPnS4v1qPWeUbesziTfopxa0z9GvNFujX2jpDv9iS3c6J7pSLW/TgxNqdB3Q7Y9lb5wQMVDgni9OO91Bp7yH6BV1DOxZKduv56nEecu+Nj3ecqGtD71g9txXv6AdHd4/T50++8yD7lBOCULZF173zv2eM8zDlbt1OskrX1Xll5o9ZrF3XIxnvwfpDaydTqMct6gQVJCt1O0Ge88BzZ168cy7iPOi7r9K5T4hp6Z7o3Fedh6B79/90qW6ncrM+TwoS+hjJSzt9L9D77anT7Tc8M7TgkWhU34Py+3Q7BZ26n4cdt0/Wd748TtbTpc4x1aPbb99SKev5Nfr9VGaPvmbkT9fjFjhvDQoqdPv7tuSevGN1E+7D2p886jFZn7r8ClnPizr3lLSe28j2Uln3wh28OclPOkEfXlBJ3v7/DgAjEQtYAAAAAIBwywbmrqgPh2yI+gIcIliLBwAAAAAAQKixgAUAAAAAAIBQ4yuEAAAAAIBwC7K//RMWYeoLcIjgE1gAAAAAAAAINT6BhQMmyM9Nk8nqQCpr+c0YWY86SS/mpATFOvVvQpLVOtam8DkdJZXU4YFWuVmnBHVcpqPngj06UiuvP3ft2Esm6j7MSSDq1mPgJZZ5Y58uchLRErreq6fK6lfpFLKy7bpDmZhuJ+okOhZ26LHPOslQUWd8Spt1OwVdul7xtp6XXifmqGybnq/edj0OPWOd8XfS0rzX23V4brRg+Sa9Ty8100vl6m7Q25fs0QdV67F6LCvX6f6kdUCTJePOMe6MgZfoli0cWjsRL6XR6Y+XSNnjnLslO/T2vbW6/cJOvX33WD1fXoJVkOfEJTqSVbnbV23UL7btSH1CZwuc49t5TX5KoG4nVaGv7SXNzm/FnQi7TJGTHual7znNd0xzktWcoa94y9lvxtmxM4e99U7SXqf3e8qhnRNeAlwqqq8B++boeYn/Jrde/o6T1uecDxnnXlbS7Fx7nRTiVJUes7wePWaZMn1di7Xo61rLXN2fmted1L9G/X6ksEv3s+hNXd86vVrWx72it995ln5d5dMSsp56s1bWj2zYLestcf0+aPdW3c+8qbqf5c/rdjpPzL2hJaYVy237unQbXtrg22f+g6xP++erZL1hZous7ynV+81s1zetaK/zHtd5H9Raps+3994Ts06iJQCMJHwCCwAAAAAQbkEQvj8HSFtbmy1atMji8bjF43FbtGiRtbe3v+9//4UvfMEikYh95zvfOWB9BIYDC1gAAAAAAITEpZdeamvXrrUnnnjCnnjiCVu7dq0tWrToff3bRx55xF566SVraHA+Qg+MYHyFEAAAAACAEFi/fr098cQT9uKLL9pHP/pRMzP7wQ9+YPPmzbMNGzbYkUce6f7bHTt22OLFi+3JJ5+0c88992B1GThoWMACAAAAAIRbNjCzED3LK/vbvnR0DH4WbiwWs1jMedjr+/DCCy9YPB4fWLwyMzvppJMsHo/b888/7y5gZbNZW7RokX35y1+2mTNnfuD9A2HGVwgBAAAAAPgAJkyYMPCsqng8bkuXLv2D2mtubra6urqcel1dnTU3N7v/7hvf+IZFo1G79tpr/6D9A2HGJ7BwwOT3muW/J0wmXwcZWfGcNlnPLtdxgBkdMGM9Y5xEJydVrGOG/kH5Zn1qdEzQSS9F/16ptz9dJ3aV7MlN2emu132vfVX/pqljik6pSVbqen6fLLvJbckxemwq39Rjs+cYHQ3VPclJ99uoX2/PWP1685I6HitwrmJFe3S905nD/riuFxynj83Y8ipZT0zT+/VSyzzjnmmX9Z2nV8p62Vu5A+Ed917KppeUVtKif+C9phInedJLaItvdFLCynQ96hzLec7rjTfpH2Sjuv3dH9HHZvEQx6G8Sde9BM6yHfrY76/Q+w3ynYQ/HYpqyWrd0dLt+vWqRLr2abrz3rW9TweNuUmYhU76afl23ff2w3XfE1N13Tt2+it0PVXupPt1OYmU/UNLeozoy6MlnVTa8iZ9jHRO9vqj2886x2B+v26/fIWOCk2X6P0W7fXuW6LopAQWOsexd6x594JYu+5L0VgdeRlxoiejz8Rl3buHeklye4/V26fr9AtLl+jJSpc5F542fS9uO9J5f+Qk9qb+Q0cOZ2fqg3bDqsl6+wI9njOP3yLrO/5FHSRm7cd48bC59+7a1/S2u44qkvU8J/HaSxvcfMl9sn781/5C1mNO0m5Wv+2wwPl4Qc8Y5z3oXj2Hxe85DzPO9QB/uG3btllFxe9uJN6nr2677Tb76le/ut+2Vq9ebWZmkUjuvAZBIOtmZo2Njfbd737X1qxZ424DjAYsYAEAAAAAwu0AJ/8N2X/3paKiYtAClmfx4sV28cUX73ebyZMn22uvvWa7d+/O+dmePXts7Nix8t/9+te/tpaWFps4ceJALZPJ2A033GDf+c537J133vm9/QNGAhawAAAAAAA4gGpra622tvb3bjdv3jxLJBK2atUqO/HEE83M7KWXXrJEImEnn3yy/DeLFi2y+fPnD6qdddZZtmjRIvvTP/3TP7zzQEiwgAUAAAAAQAgcddRR9slPftI+//nP2/e//30zM/vzP/9zO++88wY9wH3GjBm2dOlS+9SnPmU1NTVWUzP4GREFBQVWX1+/39RCYKThIe4AAAAAgHAL7HdfIwzFnwP3Un/605/a7NmzbcGCBbZgwQI75phj7Cc/+cmgbTZs2GCJROLAdQIIIT6BBQAAAABASFRXV9v999+/322C3/M8MJ57hdGIBSwcMGPW9lg0OjglZ8s5Oj4wb62Oqop5R6iX+rVNp+PEWnW6TySro2H6nK+nxzfrG0Vw8V5Zz9ug4956q3PTQQo7dNvtR+gPSha2y7KV7dBjUNSqExFj63fI+pbLD5d1L6mu/sUeWW9r03Oecp51OXb10OL6Ym06bWjvsToBxkvHGv+vW2W96U8myXphn26nZJceoPbjdfzP4Q/qcdt6TqWsT/zPdlnfcGV5Tq1mjT52xv+bTn966wv6tfacrNO6qv5Rp11VNDnpgb26PxVb9LGZmKKTJyvf0mPZU6e3bz9cX0iyuvs2drU+h8o36N9yth6vEymL2nQ7XpJUT/3QkuSKWvUxWPu6jtrbfIken/4KPS+Tf56bwJl9db3c9p2/nSfrRa2y7CZGego79FiObXSu+fv0GOw9pkzWqzbodgq6dEd3z9VpZkG+nhMvXTHepI/9wnY96TtO0/es2rX6utlT5yRY6suO9dbqY+HJm74p6/NWLpb15Fv6uj/17k25xdpKuW2qRr/W/F49Zv1Vek72zdT3gth/6ZvQuKd1hO2WC2XZ0iVOyuE+PfaH/4uOV9z1cZ1yWLJbz23lG/p69Jurcu8FZmaxNieFMKPrlZ/S7w36njtM1g8/Xceuvrl1nKy//bROG8zT3bfal/R1c9/c3HFuPkm/pkxK14O0rjfMbJF1L23wlVvukfXzNp4t6/uW6XtuxyQnCXefPhaSVXpsusYPHptMkmQ6ACMfC1gAAAAAgHALaQohgIOHZ2ABAAAAAAAg1FjAAgAAAAAAQKjxFUIAAAAAQLhls+Y+CHc4ZEPUF+AQwSewAAAAAAAAEGp8AgsHTMFbzRbNGxzzlZeaJrfNxPRDEPN02JBlnPSwTJGTfrZOp+Pkz5op6/2Vuj8R5xctnb065Sgo1O1ERUBWxTs6Nau7oUTWC3p028m4Xpcu2alTtqxEp0VFnOdSRpxmCne2y3r6eKf/Xc7Y9OhBbp+uE9TKtuiEvKK9+iDpq9HHSMuZE2W9d7JOAytu0f3pPsw5dgr068oW6vSgjD6kLNKvU9EimdzXVbLXmayYcwI55k/bIOuvVhwn65mYHuO0Dgmzks37ZH3L/9JxoPXPdsn63mN1mmnSOZ+9X+F4x362TI9bcauek/w+PefpEn3rLWzXO+4do8czVabrlRv1vEdKnES6fN2fSE9uemt+pU5K8xLXuibqMSjdKctWttO5F6R1vfjNXbKenD5W78CZ83Sx7n+2UJ/nRft0f3qc879kh5P+5ZTzu3RybqxNX0+9c65sl3MNcCTL9QBdtmmh7s96L2XWOYniuSmQ2TJ9YShs0glwgWjDzKy4RafyFU6YoNtxjoVMXL+mQt28RbLO9U43YxbR2/frU8vtaFGrHofSd/T57N1Tor26vrdLp0B6os4bpGiBPgbTxfoYKdMhkJZx7h9BNHe/+Ul9X7WYc//crl/rnlI9xjFnaLy0wceOeFzWz2i+Uta7DtOT1TVOv66okypa8J5060w/DxwHMPKxgAUAAAAACDdSCIFDHl8hBAAAAAAAQKixgAUAAAAAAIBQ4yuEAAAAAIBw4yuEwCGPT2CNIs8884ydf/751tDQYJFIxB555JGBn6VSKbvpppts9uzZVlpaag0NDXbZZZfZzp2Dn6SbTCbtmmuusdraWistLbULLrjAtm/ffpBfCQAAAAAAwO9EgoCl49Hi8ccft+eee85OOOEE++M//mN7+OGH7cILLzQzs0QiYRdddJF9/vOft2OPPdba2tpsyZIllk6n7eWXXx5o44tf/KL94he/sB//+MdWU1NjN9xwg7W2tlpjY6Pl5zupLu/R0dFh8XjcTv75YouWDk5SafnVYfLfeIlOnVP1PgrbvDQtvf2kM9+R9bd/PUnWa1/TaTodE/UOktW6/14yV0oESfWO1+k4xTv0ByWDYztlvfIhHY+T/myrrBdG9X57H3FSvBzd43V9zCt6LLsa9Fj2nKxTBePLdfrWvo/rlMCCYh1hGX1VpwplivQcljrrt4npuj52tW6n+SS9/ZgZe2U9+VidrOedrbdva6rKqRU1OGNZqmOnEs/pOR//tG6n5SP6WOs9RacE1j2gY7l2XaTncOI/6mOkfbE+9tt26hivWItzYQic60iensNUlT6Wg6jefuaMbbK+7ZEpsu6lhFW+pVO8+sucdLJLmmU9eX/9kPY744r1ObUXm3Tfq57SEWFlu/T1JVugx37nJfpY8KR79fUxr0PX8/ucxLhyJ2K2XF9HKl7WrzerQwutp0G3X3x4h6x3byuX9WidPnfznGM287a+3mWdhNzatU6Sb9/QrmvV63Q7mQv1fUg5vm6HrD+3VR+D/c36HjHxSScB9lp9Le3u15PYntDXu6I39HWtZ6I+9s2Zq/FP6vM51qqPwa0L9Imb5+w21qrnpGOWPudKN+nUVa99LzU65ST2eemH/RW67lEJfF6SrKc/rv9BukTXY/v0XFVs0cdaSbMenKfv/6GsT/vnq2Q9vkHPYedkWc4JsMz29dk7t95iiUTCKiqGONDD7N3/W8yvvSIn4Xw4pbP99tTefxiRYwqMVHyFcBQ5++yz7eyzdYRvPB635cuXD6rdddddduKJJ9rWrVtt4sSJlkgk7Ic//KH95Cc/sfnz55uZ2f33328TJkywp556ys4666wD/hoAAAAAIEc2MLMQffYiG6K+AIcIvkJ4CEskEhaJRKyystLMzBobGy2VStmCBQsGtmloaLBZs2bZ888/77aTTCato6Nj0B8AAAAAAIAPCwtYh6i+vj67+eab7dJLLx34yGtzc7MVFhZaVdXgryKNHTvWmpv1V1LMzJYuXWrxeHzgz4QJEw5o3wEAAAAAwKGFBaxDUCqVsosvvtiy2azdc889v3f7IAgsEtHfuzcz+8u//EtLJBIDf7Zt0899AQAAAIAPIgiyofsD4OBiAesQk0qlbOHChdbU1GTLly8f9MDB+vp66+/vt7a2tkH/pqWlxcaO9R/oHYvFrKKiYtAfAAAAAACADwsPcT+EvLt4tWnTJluxYoXV1NQM+vmcOXOsoKDAli9fbgsXLjQzs127dtm6devsjjvuGPL+Oh4dZ/mFg5Oa/uLaX8ht//6e83WfK3TcTV5SH7qTH9PpZM2tOm0wv1p/siwvpR/KWLJb/6ald6xup/swvb1KsKl7QSeltR6t+1Lwmk6pKmrTaTcdj9bIeq8T0JZ0xia/T28f36T7+d4UnHflpZ10nzU6sig/qceyYo1OYupu0Ck1ta/pY6owoceteZ5OmDrsGd1Oy/HOZTVP9z/zr2NkPeKkIqZW1OrmRcpZeqM+RmydTiZ74PY7Zf3qN66T9dJm/Zq6t+g5zDjJZ+XPOSledc751qiPZZug07RirU6Sp3NseulYVSv0nO84XR9rm3frtLSY88zXtA5Rs9Yj9UnqJW1lHtJpg8W9ejxbZ+uB2HzPjJza5B16jPcd7SSuOkmJ6SLn2vuWPha8RNeCLj0I1W+IaDIz2/EJfWwWN+sxDpz0XW+/fTW6n5GMrhc9qpMzS/t1+5+6+QVZv/+fzpT1kk7dTl7aub4n9fbt07yEPFm2bh04bFU/qcypdR2mx/ilmD7PC5zjPt+79KZ0iufeX43T7SR1O1Xdesd//5Vvy/p111wj6+liPZY9tboe5OlUxNrXdH/q/+ItWW/9+mRZ75o0tOtjYYfeb5fz9IjkGD3+tav1vHcerq9T8Q16+77q3Fq6zDnunblNl+rto71eUq1up2OS/kHXYfp9ipc2uPmS+2T9nDP/t6z3NDj3xPe8rIyTwgoAIwkLWKNIV1eXbd68eeDvTU1NtnbtWquurraGhga76KKLbM2aNfbYY49ZJpMZeK5VdXW1FRYWWjwetyuvvNJuuOEGq6mpserqarvxxhtt9uzZA6mEAAAAAHDQBUG4kv+CEPUFOESwgDWKvPzyy/aJT3xi4O/XX3+9mZldfvnldtttt9mjjz5qZmbHHXfcoH+3YsUKO/30083M7Nvf/rZFo1FbuHCh9fb22hlnnGE//vGPLd/5LTQAAAAAAMCBxgLWKHL66adbsJ/fBOzvZ+8qKiqyu+66y+66664Ps2sAAAAAAAAfGAtYAAAAAIBwCwLLebjXcOIrhMBBRwohAAAAAAAAQo1PYOGAKdmTtWjB4DSZ/zh5qty26BydOjPtQZ0M1ztGJ6nc+2/3yvrC274s61kd7mO91U7yVI/+TYuXSOfpFqmFKSeBrK5Rj02yUq8/t5ygX5SXHljSotsPInqMa97UDTV/tEjW+6u89Crdftk23Z/26bqdQh08afWrdDs7LtHHVLyiW9ajT+hUtPbD9eWzMKH7U7Jbv97eOl2va9RxSckqvd+6V3JfV6pUb9t6tK7/n09dKevtZ+jzob9Snw9jGnU9MVXPYSruJFju1NvXv6TnsCWl0wALvCQ2HY7lzsn2P9Ltj3tuaOd/ENXtlzzdofszUadJFrbpRMDdH9VJezvm63GY/Ijuf+eE3ONk10n6PC/dpdvumKSPnaoNep+1r+s57xzvpBY6Q7/zND0GqXInYXaXbieiLyO25xS94/oV+vXWrNcHW8cX9Jy3/0ZEq5nZij85Uda7/kz3p6y+S9Zry/T1rvv+BlmveUO33zFRX0tKm/XrbROJmiXOsWOm57x0l56Usu363tTdoBPg3IRcfVpZqkz35+aFfybrLecMLd2vwLmX9dXoY8pL2qv4ozZZ3/J9ncY847vtst49pULW1XXBzCy+2bnOrtcvuM9JOj7iH/WxuemzOj33sP/KPR6Kd+tjYd9sL+VY9yXWoY/jnjF6Tor36WOza5zePr5B79dLG/zP5Q/K+pyvflHWc1IInXRTABhJWMACAAAAAIRbNuv/ZmE4BCHqC3CI4CuEAAAAAAAACDUWsAAAAAAAABBqfIUQAAAAABBupBAChzw+gQUAAAAAAIBQiwQBS8f4cHV0dFg8Hrejvni75ccGJ1ZFnKMto8O9rOpMHQ0Vi+pEpMQ/jZf1wi4nke5snTBT1aiT/Ao79AtIxvVacNZ5XeXbcvfbMVmn1NSt0Wk6XQ268fKtOr1u56k6Ta90p35NnVN0Ok5wtI5KKn5GJ6V5vyjLS+sf9NXo/VY0OWmJzjJ892Fe8pHeb6xd77dAh3hZ+0x9DNY06nlMlev2C9t1f7qd1LWiPXr7ItFOzxg9BlEnTTNTpPdZu65X1ltn6EQ6L/Ey1uEkTE7TY+adbz31TiKdDid0U8U8PYfpftau0fstbtXHwt7Z+jqSPkGfQ5NqdHrYpm1jZb2hXm+f+FW9rMfa9Hj2flIn4RX9MjeFzEsOq39JX3d6xuoxiPZ5SZX6WOgdo7cv6NL9qdqo57BljnNdc64jtWv1flvO1Adb2Ws68S6jy+5+S3br/XYt0BekYINOaEtVOMlwzrlS3Kw75D0zOa1vKzZhuT7G247O7aeXKuyNmXdPKWnRP0g717XOqfpFFe/WY1D7mh607nonkbZL92ffLN2fhmf0hSob0/3Zfrreb7THGc9i3Z/Sbc69yUlv7ZrgJAhvdd4fVertPX0n62O8v1O/56l8JbfeN0a3nSnSfYw615GUk/RYtNd5Tc75HO3R9e4G3X5+v5NU6yR2Nt6qE7jn3DY4nTDT32ev/+gWSyQSVlGhUybD6t3/W5xRdqlFI86b62GQDvrt6a6fjcgxBUYqvkIIAAAAAAi1IJu1IEQphAEphMBBx1cIAQAAAAAAEGosYAEAAAAAACDU+AohAAAAACDcSCEEDnl8AgsAAAAAAAChxiewcMD0NgSW957EFy8dp2q9fghi21PjZN1LOcsrcRL1nIS/+Ku67v12p7tBr/l2HaHTicrX6wSuxOHefnMtXvYvsn7zPy+S9UxMJ8NFnTHrbnBS/97WY9C/V6cNemlaBU4Sk5cwlXWuSqW7dELT1gW6oZgOaLOadU4KUZ8+BiM6qNKiPXoOvXSvvhpdTxfr8ff22zFN97+tXPyDQt2Z6hd0gk9vnd5n++H6mMpGdd97Jut2Os1JG2zX2xe1OteFY/T2Jdt0+7GEHrOscxpWbNIHc+dEvX3LqbpesE/vt+KXOjGupUifW3HnGbGpTp1OGHESuLxfWkdWx2U9XZJbK9uhG9k1T5+H8bd15/sqh5Z2V7bdSf3y0vFievt8HZZoxbv19t2H6fqkB3T/9x2t2w+cY827bnqJoMFGfeyU7tTt5DcNLXXR+zRBskq3E0voZnZ9RSdzFvxnbs1LaEvpl2pRHYrqns9e4uWYl/X23nVwx8f1zclLsG0/Qrcz/r/02KTKdfupUt3+xCf1PXH3ifpcLN+i+5Os1PW9n9AnS3y1vh/smefctBx1z+sJ69ohLjxmVrFNH7T94vKVPkIfVKUv6La980FdA83Mivc6CY1OenCBk6jrn4dDq783bfBdjbcNTifs6Mxa1Y+ctgFghGABCwAAAAAQbtnALBKir+3xFULgoOMrhAAAAAAAAAg1FrAAAAAAAAAQanyFEAAAAAAQbkFg7sMPhwNfIQQOOhaw8KEL/vtinu3LfWp4pk8/4DKd0jejTNL5kKDzIN4g4zww3NlvZqjtJHU72V79sOxMUj/UNBjCs057OvXGGTG+ZmYZ/VxXt+8Z59nImX5nDPqdhwI77eR57Xj7dfqZTuvXm3Ue0Ou+3n7vidi6He9h6pl+fWwGzkPcvf7kufOl61nnYfPZqOhoxjmvnDFwzxNvDvOd7Z3AAI/3WtMpPfhZ5yHOmaR+KLDXf++hz0He0K4X3vmf7dO3WPccdfbrvVd358U99oe2vbrODnmf3rXdHWPn+qKfez30sXGOTe+6lnHeJaVTQ7vmZ4b6EHfnGHGvd8725tSH+vBob14i3rHco0+WvP7cCcg6Nw9vriLOeejNuXe/jbjHsh6cod5rvO3TKX0wp6N6v96xmU57x6B3jAz1fc3Q3mNke72TVMv065PCH2dnfEQ52+P03WnDOx+Ger4N9dqb9a5HQ7wXezo6B18gO7p++/eARRcAI1gk4CqGD9n27dttwoQJw90NAAAAAP/Dtm3bbPz48cPdjSHp6OiweDxuf1T4GYtGdML3cEgHKftV/79aIpGwioqK4e4OcEjgE1j40DU0NNi2bdusvLzcOjs7bcKECbZt2zYu7KNMR0cHcztKMbejF3M7ejG3oxdzO3odzLkNgsA6OzutoaHhgO7nQAqygQUhSiHkcyDAwccCFj50eXl5A7/ZiUR++zHoiooK3nSNUszt6MXcjl7M7ejF3I5ezO3odbDmNh6PH/B9AMCBRAohAAAAAAAAQo1PYAEAAAAAwi3IWrhSCEPUF+AQwSewcEDFYjG79dZbLRaLDXdX8CFjbkcv5nb0Ym5HL+Z29GJuRy/mFgCGhhRCAAAAAEAovZtC+In8T4cuhXBF5iFSCIGDiK8QAgAAAABCjRRCAHyFEAAAAAAAAKHGAhYAAAAAAABCja8QAgAAAADCjRRC4JDHJ7BwwNxzzz02ZcoUKyoqsjlz5tivf/3r4e4Shmjp0qX2kY98xMrLy62urs4uvPBC27Bhw6BtgiCw2267zRoaGqy4uNhOP/10e+ONN4apx/igli5dapFIxJYsWTJQY25Hrh07dtjnPvc5q6mpsZKSEjvuuOOssbFx4OfM7ciUTqftr/7qr2zKlClWXFxsU6dOtb/5m7+xbPZ3/4libkeGZ555xs4//3xraGiwSCRijzzyyKCfv595TCaTds0111htba2VlpbaBRdcYNu3bz+IrwLK/uY2lUrZTTfdZLNnz7bS0lJraGiwyy67zHbu3DmoDeYWADQWsHBAPPjgg7ZkyRK75ZZb7JVXXrGPfexjdvbZZ9vWrVuHu2sYgpUrV9rVV19tL774oi1fvtzS6bQtWLDAuru7B7a544477M4777S7777bVq9ebfX19XbmmWdaZ2fnMPYcQ7F69WpbtmyZHXPMMYPqzO3I1NbWZqeccooVFBTY448/bm+++aZ961vfssrKyoFtmNuR6Rvf+Ibdd999dvfdd9v69evtjjvusG9+85t21113DWzD3I4M3d3dduyxx9rdd98tf/5+5nHJkiX28MMP2wMPPGDPPvusdXV12XnnnWeZTOZgvQwI+5vbnp4eW7Nmjf31X/+1rVmzxh566CHbuHGjXXDBBYO2Y261tKUsHYToj6WGe0iAQ08AHAAnnnhicNVVVw2qzZgxI7j55puHqUf4MLS0tARmFqxcuTIIgiDIZrNBfX198PWvf31gm76+viAejwf33XffcHUTQ9DZ2RlMnz49WL58eXDaaacF1113XRAEzO1IdtNNNwWnnnqq+3PmduQ699xzgyuuuGJQ7dOf/nTwuc99LggC5nakMrPg4YcfHvj7+5nH9vb2oKCgIHjggQcGttmxY0eQl5cXPPHEEwet79i/986tsmrVqsDMgi1btgRBwNwqvb29QX19fWBmoftTX18f9Pb2DvcQAYcMPoGFD11/f781NjbaggULBtUXLFhgzz///DD1Ch+GRCJhZmbV1dVmZtbU1GTNzc2D5joWi9lpp53GXI8QV199tZ177rk2f/78QXXmduR69NFHbe7cufaZz3zG6urq7Pjjj7cf/OAHAz9nbkeuU0891Z5++mnbuHGjmZm9+uqr9uyzz9o555xjZsztaPF+5rGxsdFSqdSgbRoaGmzWrFnM9QiTSCQsEokMfEqWuc1VVFRkTU1NlkgkQvenqanJioqKhnuIgEMGD3HHh27v3r2WyWRs7Nixg+pjx4615ubmYeoV/lBBENj1119vp556qs2aNcvMbGA+1Vxv2bLloPcRQ/PAAw/YmjVrbPXq1Tk/Y25Hrrffftvuvfdeu/766+0rX/mKrVq1yq699lqLxWJ22WWXMbcj2E033WSJRMJmzJhh+fn5lslk7Gtf+5pdcsklZsZ5O1q8n3lsbm62wsJCq6qqytmG91ojR19fn91888126aWXWkVFhZkxt56ioiIWigCwgIUDJxKJDPp7EAQ5NYwcixcvttdee82effbZnJ8x1yPPtm3b7LrrrrNf/vKX+31DyNyOPNls1ubOnWu33367mZkdf/zx9sYbb9i9995rl1122cB2zO3I8+CDD9r9999vP/vZz2zmzJm2du1aW7JkiTU0NNjll18+sB1zOzp8kHlkrkeOVCplF198sWWzWbvnnnt+7/bMLQDwEHccALW1tZafn5/zW6KWlpac3yZiZLjmmmvs0UcftRUrVtj48eMH6vX19WZmzPUI1NjYaC0tLTZnzhyLRqMWjUZt5cqV9r3vfc+i0ejA/DG3I8+4cePs6KOPHlQ76qijBkI0OG9Hri9/+ct2880328UXX2yzZ8+2RYsW2Ze+9CVbunSpmTG3o8X7mcf6+nrr7++3trY2dxuEVyqVsoULF1pTU5MtX7584NNXZswtAOwPC1j40BUWFtqcOXNs+fLlg+rLly+3k08+eZh6hQ8iCAJbvHixPfTQQ/arX/3KpkyZMujnU6ZMsfr6+kFz3d/fbytXrmSuQ+6MM86w119/3dauXTvwZ+7cufbZz37W1q5da1OnTmVuR6hTTjnFNmzYMKi2ceNGmzRpkplx3o5kPT09lpc3+K1bfn6+ZbNZM2NuR4v3M49z5syxgoKCQdvs2rXL1q1bx1yH3LuLV5s2bbKnnnrKampqBv2cuQUAH18hxAFx/fXX26JFi2zu3Lk2b948W7ZsmW3dutWuuuqq4e4ahuDqq6+2n/3sZ/bzn//cysvLB34bHI/Hrbi42CKRiC1ZssRuv/12mz59uk2fPt1uv/12KykpsUsvvXSYe4/9KS8vH3iW2btKS0utpqZmoM7cjkxf+tKX7OSTT7bbb7/dFi5caKtWrbJly5bZsmXLzMw4b0ew888/3772ta/ZxIkTbebMmfbKK6/YnXfeaVdccYWZMbcjSVdXl23evHng701NTbZ27Vqrrq62iRMn/t55jMfjduWVV9oNN9xgNTU1Vl1dbTfeeKPNnj07J5QDB9f+5rahocEuuugiW7NmjT322GOWyWQG3ltVV1dbYWEhcwsA+zNc8YcY/f7u7/4umDRpUlBYWBiccMIJwcqVK4e7SxgicyKDf/SjHw1sk81mg1tvvTWor68PYrFY8PGPfzx4/fXXh6/T+MBOO+204Lrrrhv4O3M7cv3iF78IZs2aFcRisWDGjBnBsmXLBv2cuR2ZOjo6guuuuy6YOHFiUFRUFEydOjW45ZZbgmQyObANczsyrFixQt5fL7/88iAI3t889vb2BosXLw6qq6uD4uLi4Lzzzgu2bt06DK8G/9P+5rapqcl9b7VixYqBNphbANAiQRAEB3PBDAAAAAAAABgKnoEFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAg1FrAAAAAAAAAQaixgAQAAAAAAINRYwAIAAAAAAECosYAFAAAAAACAUGMBCwAAAAAAAKHGAhYAAAAAAABCjQUsAAAAAAAAhBoLWAAAAAAAAAi1/w/AjnW95g3GkAAAAABJRU5ErkJggg==' width=1200.0/>
</div>




```python
# now    2) Make a similar plot showing correlation > 90%
import numpy as np
import matplotlib.pyplot as plt


correlation_matrix = df.corr()

# Create a mask for correlations greater than 90%
high_corr_mask = correlation_matrix > 0.9

# Set the diagonal to False to exclude self-correlations
np.fill_diagonal(high_corr_mask.values, False)

# Visualizing the filtered correlation matrix
plt.figure(figsize=(12, 10))
# Use the mask to filter values in the matrix, setting non-high correlations to NaN for clarity in visualization
filtered_correlation = correlation_matrix.where(high_corr_mask)
plt.imshow(filtered_correlation, cmap='viridis', interpolation='none')
plt.colorbar()
plt.title('Correlations > 90% in Data')
plt.show()

# This focused view highlights the strongest relationships between variables, indicating areas of significant linear association. ​
```



<div style="display: inline-block;">
    <div class="jupyter-widgets widget-label" style="text-align: center;">
        Figure
    </div>
    <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABLAAAAPoCAYAAADOWwfbAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjguMCwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy81sbWrAAAACXBIWXMAAA9hAAAPYQGoP6dpAABt8ElEQVR4nOzde5yWZZ0/8M/DyGFUmFRyAEXBFpUWTUVDoVK3xCXR3HYLszR3zdV024gOyhobWsKKSe6mkGik2CruQVt310y2zdNSoZS1HhZqVwUV8ofRjIpymLl/fxCzOzGaB2AueN7v1+t6vXyu57qf+d7PPTPO8+X7va9aVVVVAAAAAKBQPbo7AAAAAAB4JRJYAAAAABRNAgsAAACAoklgAQAAAFA0CSwAAAAAiiaBBQAAAEDRJLAAAAAAKJoEFgAAAABFk8ACAAAAoGgSWAAAAAAUTQILAAAAgKJJYAEAAABQNAksAAAAAIomgQUAAABA0SSwAAAAACiaBBYAAAAARZPAAgAAAKBoElgAAAAAFE0CCwAAAICiSWABAAAAUDQJLAAAAACKJoEFAAAAQNEksAAAAAAomgQWAAAAAEWTwAIAAACgaBJYAAAAABRNAgsAAACAoklgAQAAAFA0CSwAAAAAiiaBBQAAAEDRJLAAAAAAKJoEFgAAAABFk8ACAAAAoGgSWAAAAAAUTQILAAAAgKJJYAEAAABQNAksAAAAAIomgQUAAABA0SSwAAAAACiaBBYAAAAARZPAAgAAAKBoElgAAAAAFE0CCwAAAICiSWABAAAAUDQJLAAAAACKJoEFAAAAQNEksAAAAAAomgQWAAAAAEWTwAIAAACgaBJYAAAAABRNAgsAAACAoklgAQAAAFA0CSwAAAAAiiaBBQAAAEDRJLAAAAAAKJoEFgAAAABFk8ACAAAAoGgSWAAAAAAUTQILAAAAgKJJYAEAAABQNAksAAAAAIomgQUAAABA0SSwAAAAACiaBBYAAAAARZPAAgAAAKBoElgAAAAAFE0CCwAAAICiSWABAAAAUDQJLAAAAACKJoEFAAAAQNEksAAAAAAomgQWAAAAAEWTwAIAAACgaBJYAAAAABRNAgsAAACAoklgAQAAAFA0CSwAAAAAiiaBBQAAAEDRJLAAAAAAKJoEFgAAAABFk8ACAAAAoGgSWAAAAAAUTQILAAAAgKJJYAEAAABQNAksAAAAAIomgQUAAABA0SSwAAAAACiaBBYAAAAARZPAAgAAAKBoElgAAAAAFE0CCwAAAICiSWABAAAAUDQJLAAAAACKJoEFAAAAQNEksAAAAAAomgQWAAAAAEWTwAIAAACgaBJYAAAAABRNAgsAAACAoklgAQAAAFA0CSwAAAAAiiaBBQAAAEDRJLAAAAAAKJoEFgAAAABFk8ACAAAAoGgSWAAAAAAUTQILAAAAgKJJYAEAAABQNAksAAAAAIomgQUAAABA0SSwAAAAACiaBBYAAAAARZPAAmCr++lPf5o//uM/ztChQ9OnT5/suuuuOeywwzJjxoz88pe/7O7wOrnrrrtSq9Vy1113veZjH3nkkUydOjWPP/74Zs+dccYZGTJkyBuOb3vw3HPP5c///M+z1157pXfv3tl///0zY8aMtLW1bbb2+eefz8SJEzNo0KD06dMnhxxySObPn7/ZultuuSUHHHBA+vXrl/Hjx+epp57abM348eNz+umnv+o4jznmmBxzzDGv6dxeyabvnU2jV69eefOb35wxY8bkwgsvzBNPPPG6X/vpp5/O1KlT8+CDD26xeAEAtic7dXcAAOzYrrnmmpx77rk54IAD8tnPfjZvfetbs379+jzwwAP52te+lu9///u59dZbuzvMLeKRRx7JRRddlGOOOWazZNWUKVPyyU9+snsC24Y2bNiQ4447LkuXLs0Xv/jF7L///rnjjjtywQUX5Mknn8zf/M3fdFr//ve/P/fff3/+6q/+Kvvvv39uvPHGfOhDH0p7e3tOPfXUJMl///d/55RTTsnnPve5vOtd78pf/uVf5qMf/Wj+7d/+reN1/u7v/i4/+MEP8uijj77qWGfNmrVlTvo3TJs2Lccee2za2try7LPP5oc//GHmzp2br3zlK7nmmmvy4Q9/+DW/5tNPP52LLrooQ4YMySGHHLLlgwYAKJwEFgBbzfe///18/OMfz3HHHZdvfetb6d27d8dzxx13XD796U/njjvu2CJfa82aNdl55503m29ra8uGDRs6fe3u8Ja3vKVbv/4refHFF7Nq1aoMHjz4Db/WP/zDP+SHP/xh/vEf/zHvf//7k2y81s8//3yuuuqqnHfeeTnggAOSJLfffnsWLFjQkbRKkmOPPTZPPPFEPvvZz2bChAlpaGjInXfemaFDh+ZLX/pSkmTXXXfNO97xjrz44otpbGzMr371q3zyk5/Ml7/85bz5zW9+1bG+9a1vfcPn25Vhw4blyCOP7Hh80kkn5dOf/nTe85735IwzzsjBBx+cgw46aKt8bQCAHZUWQgC2mmnTpqVWq2XOnDldJpB69eqVk046qeNxe3t7ZsyYkQMPPDC9e/fOnnvumdNPPz1PPvlkp+OOOeaYjBgxIvfcc09Gjx6dnXfeOX/yJ3+Sxx9/PLVaLTNmzMiXvvSlDB06NL179873vve9JMkDDzyQk046Kbvvvnv69OmTQw89NH/3d3/3W8/jgQceyCmnnJIhQ4aksbExQ4YMyYc+9KFOLWHXXXddPvCBDyTZmITZ1EZ23XXXJem6hfCll17K5MmTM3To0PTq1St77bVXzjvvvPzqV7/qtG7IkCEZP3587rjjjhx22GFpbGzMgQcemLlz53Zat2bNmnzmM5/paNXcfffdc/jhh+emm256xfP7xS9+kX333Tfvete7Mnv27Kxateq3vicv5z/+4z9Sq9Uybty4TvPjx49Pe3t7p2q7W2+9NbvuumvH+7bJH//xH+fpp5/OD3/4wyQb36dddtml4/ldd901VVVl7dq1SZLzzz8/w4cPzxlnnPGaYv3NFsJN3z9f/vKXM3PmzAwdOjS77rprjjrqqPzgBz94Ta/9m3bfffdcffXV2bBhQ77yla90zP/85z/PH//xH2fYsGHZeeeds9dee+XEE0/Mf/7nf3asueuuu3LEEUck2fjebPremjp1apJX9/0JALC9k8ACYKtoa2vLv//7v2fkyJGvurLn4x//eM4///wcd9xxue222/LFL34xd9xxR0aPHr1ZUmXFihX5yEc+klNPPTW33357zj333I7n/uZv/ib//u//ni9/+cv59re/nQMPPDDf+973MmbMmPzqV7/K1772tfzTP/1TDjnkkEyYMKEjyfRyHn/88RxwwAG54oor8p3vfCeXXnppVqxYkSOOOKIjrhNOOCHTpk1Lklx11VX5/ve/n+9///s54YQTunzNqqpy8skn58tf/nJOO+20/Ou//msmTZqU66+/Pr/3e7/XkZzZ5Cc/+Uk+/elP51Of+lT+6Z/+KQcffHDOPPPM3HPPPR1rJk2alNmzZ+fP//zPc8cdd+SGG27IBz7wgTz77LOveH6DBw/Orbfemr322iuf/exnM3DgwLz3ve/NDTfckOeee+4Vj/1N69atS48ePdKzZ89O85sSmD/96U875h566KEMHz48O+3UuSD84IMP7ng+SUaPHp2f/OQnue222/LLX/4yl112WYYPH543velN+Y//+I/ccMMNufrqq19TnK/kqquuyoIFC3LFFVfkb//2b/PCCy/kve99b1paWt7Q6x5xxBEZOHBgp2v29NNPZ4899shf/dVf5Y477shVV12VnXbaKaNGjcqSJUuSJIcddli+8Y1vJEk+//nPd3xvfexjH0vy6r4/AQC2exUAbAUrV66sklSnnHLKq1r/6KOPVkmqc889t9P8D3/4wypJ9Rd/8Rcdc0cffXSVpPrud7/bae1jjz1WJane8pa3VOvWrev03IEHHlgdeuih1fr16zvNjx8/vho4cGDV1tZWVVVVfe9736uSVN/73vdeNtYNGzZUzz//fLXLLrtUf/3Xf90x//d///cve+xHP/rRat999+14fMcdd1RJqhkzZnRad/PNN1dJqjlz5nTM7bvvvlWfPn2qJ554omPuxRdfrHbffffq7LPP7pgbMWJEdfLJJ79s3K/GCy+8UN18883VH/zBH1R9+vSpGhsbqw984APVLbfcUr300ku/9fgrrriiSlLde++9neanTJlSJanGjh3bMTds2LDq+OOP3+w1nn766SpJNW3atI65Cy+8sKrValWSauDAgdX3v//9au3atdVb3/rW6otf/OLrOtejjz66Ovroozseb/r+Oeigg6oNGzZ0zC9atKhKUt10002v+Hqbvnf+/u///mXXjBo1qmpsbHzZ5zds2FCtW7euGjZsWPWpT32qY/7++++vklTf+MY3fut5vdz3JwDA9kwFFgBF2NTm95ttYG9/+9szfPjwfPe73+00v9tuu+X3fu/3unytk046qVMF0M9//vP813/9V8fNszds2NAx3vve92bFihUd1S5def7553P++efnd37nd7LTTjtlp512yq677poXXnjhNd00/P/693//9ySbn+8HPvCB7LLLLpud7yGHHJJ99tmn43GfPn2y//77d2oTe/vb355vf/vbueCCC3LXXXflxRdffM1x7bzzzvngBz+YW265Jb/4xS9y9dVX54UXXsgHP/jBNDc35z/+4z9e8fgPf/jD2X333fOnf/qn+eEPf5hf/epXuemmmzpu3t6jR+c/PWq12su+1v997ktf+lJ++ctf5r/+67+ybNmyHHnkkbn00kuTbGwhfOKJJzJ+/Pjsvvvueetb3/qGNgY44YQT0tDQ0PF4U0XYlmjJq6qq0+MNGzZk2rRpeetb35pevXplp512Sq9evfKzn/3sVX9vbY3vT4CSvPTSS2ltbS1uvPTSS9391kBdcRN3ALaK/v37Z+edd85jjz32qtZvanMbOHDgZs8NGjRos+RBV+te7rlf/OIXSZLPfOYz+cxnPtPlMa/UanXqqafmu9/9bqZMmZIjjjgi/fr1S61Wy3vf+97XlSRKNp7vTjvttNlNx2u1WgYMGLBZ298ee+yx2Wv07t2709f/m7/5m+y99965+eabc+mll6ZPnz45/vjjc9lll2XYsGGvOcYXXnghv/rVr9LS0pK2trb07ds3vXr1esVj+vfvnzvuuCMf/ehHO25kvscee2TmzJk588wzs9dee3U6p67aG3/5y18m2XjfqP/rTW96U970pjclSX72s59l+vTpWbBgQXr27JmPfOQj2X///fPkk0/mrrvuyvvf//789Kc/zf777/+az/s33+tN7Y+v91r/X8uWLcugQYM6Hk+aNClXXXVVzj///Bx99NHZbbfd0qNHj3zsYx971V9va3x/ApTipZdeytB9d83KZ9q6O5TNDBgwII899lj69OnT3aFAXZDAAmCraGhoyLvf/e58+9vfzpNPPpm99977FddvShqsWLFis7VPP/10+vfv32nu1VbuJOk4dvLkyR074/2mTTvj/aaWlpb8y7/8S77whS/kggsu6Jhfu3ZtR6Ll9dhjjz2yYcOG/L//9/86JbGqqsrKlSs7btr9Wuyyyy656KKLctFFF+UXv/hFRzXWiSeemP/6r/96Va+xatWq/OM//mPmz5+fe+65J7vttlv+8A//MJdcckne9a53veL7vskRRxyRRx55JI8//nheeOGFDBs2LIsXL06SvOtd7+pYd9BBB+Wmm27Khg0bOt0Ha9MNzEeMGPGyX+Pss8/O6aefnjFjxuT555/Pfffdl1mzZmXnnXfOe9/73rz1rW/NggULXlcCa2tZtGhRVq5cmTPPPLNj7pvf/GZOP/30jvunbbJq1aqOZN0r2VrfnwClWLduXVY+05YnFg9Jv77lNBC1PteefUc+nnXr1klgwTZSzm8AAHY4kydPTlVVOeuss7Ju3brNnl+/fn3++Z//OUk62gG/+c1vdlpz//3359FHH8273/3u1x3HAQcckGHDhuUnP/lJDj/88C5H3759uzy2VqulqqrNdlG89tpr09bW+V+DX0ulzqbz+c3z/cd//Me88MILb+h8k6S5uTlnnHFGPvShD2XJkiVZs2bNy65dt25d5s6dm+OPPz4DBw7Mpz/96QwcODD/9E//lBUrVuTqq6/O0Ucf/aqSV//XkCFD8ru/+7vp2bNnLr/88gwaNKjTjoN/8Ad/kOeffz7/+I//2Om466+/PoMGDcqoUaO6fN1vfOMbefTRRztaCDe15b3wwgsda55//vnN2vW60y9/+cucc8456dmzZz71qU91zNdqtc2+t/71X/81Tz31VKe5l/veei3fnwDbs359e6Rf34aCho/SsK2pwAJgqznqqKMye/bsnHvuuRk5cmQ+/vGP53d/93ezfv36/PjHP86cOXMyYsSInHjiiTnggAPyp3/6p/nqV7+aHj16ZNy4cXn88cczZcqUDB48uNOH/tfj6quvzrhx43L88cfnjDPOyF577ZVf/vKXefTRR/OjH/0of//3f9/lcf369cu73vWuXHbZZenfv3+GDBmSu+++O1//+tc3q5DZVDE0Z86c9O3bN3369MnQoUO7bP877rjjcvzxx+f8889Pa2trxowZk5/+9Kf5whe+kEMPPTSnnXbaaz7HUaNGZfz48Tn44IOz22675dFHH80NN9yQo446KjvvvPPLHvf000/nnHPOyfHHH5958+blfe973yuu/20uvPDCHHTQQRk4cGCWLVuWuXPn5oc//GH+9V//NY2NjR3rxo0bl+OOOy4f//jH09ramt/5nd/JTTfdlDvuuCPf/OY3O92HapP/9//+Xz772c9m9uzZaWpqSpL07ds3Rx11VD772c9mypQpueeee/LYY4+94STg6/Wzn/0sP/jBD9Le3p5nn302P/zhD/P1r389ra2tmTdvXn73d3+3Y+348eNz3XXX5cADD8zBBx+cxYsX57LLLtusCvEtb3lLGhsb87d/+7cZPnx4dt111wwaNCiDBg161d+fANuz9lRpT3t3h9GhPeX8IwnUCwksALaqs846K29/+9vzla98JZdeemlWrlyZnj17Zv/998+pp56aP/uzP+tYO3v27LzlLW/J17/+9Vx11VVpamrK7//+72f69OldJoFei2OPPTaLFi3KJZdckokTJ2b16tXZY4898ta3vjUf/OAHX/HYG2+8MZ/85Cfzuc99Lhs2bMiYMWOyYMGCnHDCCZ3WDR06NFdccUX++q//Osccc0za2tryjW98Y7MbtScbK2e+9a1vZerUqfnGN76RSy65JP37989pp52WadOmbVZR82r83u/9Xm677bZ85StfyZo1a7LXXnvl9NNPz4UXXviKxw0cODArV67c7J5Tr9fq1atz/vnnZ+XKlenXr1+OPvro/PCHP8xBBx202dpbbrklF154Yf7yL/8yv/zlL3PggQfmpptuyimnnNLla0+aNClHHnlkp0quZGMl2znnnJM//MM/zIABA3LDDTdk+PDhW+R8Xqu/+Iu/SJLstNNOaWpqyv77758/+ZM/yZ/+6Z9m33337bT2r//6r9OzZ89Mnz49zz//fA477LDccsst+fznP99p3c4775y5c+fmoosuytixY7N+/fp84QtfyNSpU1/19ycAwPasVpVUXw8AAAC/1tramqampjy7dGhRbXutz7Vnj/0fS0tLS/r169fd4UBdUIEFAABA0dqq9rQVVHrRVpXTzgj1opwUNgAAAAB0QQILAAAAgKJpIQQAAKBoG3chLKeHsKRYoF6owAIAAACgaBJYdGnWrFkZOnRo+vTpk5EjR+bee+/t7pAAAACAOqWFkM3cfPPNmThxYmbNmpUxY8bk6quvzrhx4/LII49kn332+a3Ht7e35+mnn07fvn1Tq9W2QcQAAMDLqaoqzz33XAYNGpQePbbPGob2tKekff/KigbqQ62qKs27dDJq1KgcdthhmT17dsfc8OHDc/LJJ2f69Om/9fgnn3wygwcP3pohAgAAr9Hy5cuz9957d3cYr0lra2uampry9JK9069vOcm31ufaM+iAJ9PS0pJ+/fp1dzhQF1Rg0cm6deuyePHiXHDBBZ3mx44dm4ULF76q1+jbt2+Sjf+D9MscAAC6V2trawYPHtzxdzrA9kgCi05WrVqVtra2NDc3d5pvbm7OypUruzxm7dq1Wbt2bcfj5557LknSr18/CSwAACjE9nx7j7aqSltBzUMlxQL1opwaTIrym/9zq6rqZf+HN3369DQ1NXUM7YMAAADAliSBRSf9+/dPQ0PDZtVWzzzzzGZVWZtMnjw5LS0tHWP58uXbIlQAAACgTkhg0UmvXr0ycuTILFiwoNP8ggULMnr06C6P6d27d0e7oLZBAABgS2tPVdwAti33wGIzkyZNymmnnZbDDz88Rx11VObMmZNly5blnHPO6e7QAAAAgDokgcVmJkyYkGeffTYXX3xxVqxYkREjRuT222/Pvvvu292hAQAAAHVIAosunXvuuTn33HO7OwwAAIC0p0pbQW17Wghh23MPLAAAAACKJoEFAAAAQNG0EAIAAFC00nb+KykWqBcqsAAAAAAomgQWAAAAAEXTQggAAEDR2qoqbVU5bXslxQL1QgUWAAAAAEWTwAIAAACgaFoIAQAAKFr7r0cpSooF6oUKLAAAAACKJoEFAAAAQNG0EAIAAFC0tlRpSzk7/5UUC9QLFVgAAAAAFE0CCwAAAICiaSEEAACgaG3VxlGKkmKBeqECCwAAAICiSWABAAAAUDQthAAAABSt/dejFCXFAvVCBRYAAAAARZPAAgAAAKBoWggBAAAoWntqaUutu8Po0F5QLFAvJLAAAAAKdszvX9rl/F13nL+NIwHoPloIAQAAACiaCiwAAACK1l5tHKUoKRaoFyqwAAAAACiaBBYAAAAARdNCCAAAQNHaCtuFsKRYoF5IYAEAABTMboMAWggBAAAAKJwKLAAAAIqmhRBQgQUAAABA0SSwAAAAACiaFkIAAACK1l7V0l6V07ZXUixQL1RgAQAAAFA0CSwAAAAAiqaFEAAAgKLZhRBQgQUAAABA0SSwAAAAACiaFkIAAACK1pYeaSuo/qKtuwOAOlTObwAAAAAA6IIEFgAAAABF00IIAABA0aqqlvaqnJ3/qoJigXqhAgsAAACAoklgAQAAAFA0LYQAAAAUrS21tKWctr2SYoF6oQILAAAAgKJJYAEAAABQNC2EAAAAFK2t6pG2qpz6i7aquyOA+lPObwAAAAAA6IIEFgAAAABF00IIAABA0dpTS3tB9Rft0UMI25oEFgAA0OH333Rml/N3/Orr2zgSAPhf5aSwAQAAAKALKrAAAAAoWltqaUutu8PoUFIsUC9UYAEAAABQNAksAAAAAIqmhRAAAOiwvdys/bidTtlsbsGG+d0QCdtCW9UjbVU59RdtlV0IYVsr5zcAAAAAAHRBAgsAAACAomkhBAAAoGjtqaW9oJ3/SooF6oUKLAAAANgGZs2alaFDh6ZPnz4ZOXJk7r333ldcf9VVV2X48OFpbGzMAQcckHnz5m225oorrsgBBxyQxsbGDB48OJ/61Kfy0ksvba1TgG6jAgsAAAC2sptvvjkTJ07MrFmzMmbMmFx99dUZN25cHnnkkeyzzz6brZ89e3YmT56ca665JkcccUQWLVqUs846K7vttltOPPHEJMnf/u3f5oILLsjcuXMzevToLF26NGeccUaS5Ctf+cq2PD3Y6mpVZfsEtqzW1tY0NTWlpaUl/fr16+5wAACgrm3Pf59viv3vf3Jgdu7b0N3hdFjzXFs+8Lb/ek3v6ahRo3LYYYdl9uzZHXPDhw/PySefnOnTp2+2fvTo0RkzZkwuu+yyjrmJEyfmgQceyH333Zck+bM/+7M8+uij+e53v9ux5tOf/nQWLVr0W6u7YHujhRAAAABeh9bW1k5j7dq1Xa5bt25dFi9enLFjx3aaHzt2bBYuXNjlMWvXrk2fPn06zTU2NmbRokVZv359kuQd73hHFi9enEWLFiVJ/ud//ie33357TjjhhDd6alAcCSwAAAB4HQYPHpympqaO0VUlVZKsWrUqbW1taW5u7jTf3NyclStXdnnM8ccfn2uvvTaLFy9OVVV54IEHMnfu3Kxfvz6rVq1Kkpxyyin54he/mHe84x3p2bNn3vKWt+TYY4/NBRdcsGVPFArgHlgAAAAUra3qkbaqnPqLtl/fiWf58uWdWgh79+79isfVap13L6yqarO5TaZMmZKVK1fmyCOPTFVVaW5uzhlnnJEZM2akoWFjO+Vdd92VSy65JLNmzcqoUaPy85//PJ/85CczcODATJky5Y2cIhSnnN8AAAAAsB3p169fp/FyCaz+/funoaFhs2qrZ555ZrOqrE0aGxszd+7crFmzJo8//niWLVuWIUOGpG/fvunfv3+SjUmu0047LR/72Mdy0EEH5Q/+4A8ybdq0TJ8+Pe3t7Vv2ZKGbSWABAADAVtSrV6+MHDkyCxYs6DS/YMGCjB49+hWP7dmzZ/bee+80NDRk/vz5GT9+fHr02PhRfs2aNR3/vUlDQ0Oqqor92tjRaCEEtohnn9qry/k99npqG0cCAMCOpj090l5Q/UV7XntyaNKkSTnttNNy+OGH56ijjsqcOXOybNmynHPOOUmSyZMn56mnnsq8efOSJEuXLs2iRYsyatSorF69OjNnzsxDDz2U66+/vuM1TzzxxMycOTOHHnpoRwvhlClTctJJJ3W0GcKOQgILAAAAtrIJEybk2WefzcUXX5wVK1ZkxIgRuf3227PvvvsmSVasWJFly5Z1rG9ra8vll1+eJUuWpGfPnjn22GOzcOHCDBkypGPN5z//+dRqtXz+85/PU089lTe/+c058cQTc8kll2zr04OtrlapK2QLa21tTVNTU1paWjrd0JAdmwosAIAybc9/n2+K/cYHR2TnvuVUFK15ri2nHvLQdvmewvZKBRYAAABFa6tqaau63q2vO5QUC9SLcpqIAQAAAKALElgAAAAAFE0LIbBFuNcVAABbS1t6pK2g+ou217ELIfDGlPMbAAAAAAC6IIEFAAAAQNG0EAIAAFC09qpH2qty6i/aKy2EsK2V8xsAAAAAALoggQUAAABA0bQQAgAAUDS7EALl/AYAAAAAgC5IYAEAAABQNC2EAAAAFK09SVtV6+4wOrR3dwBQh1RgAQAAAFA0CSwAAAAAiqaFEAAAgKK1p0faC6q/KCkWqBd+6gAAAAAomgQWAAAAAEXTQggAAEDR2qoeaavKqb8oKRaoF37qAAAAACiaBBYAAAAARdNCCAA7kD9aeE6X8/8w+mvbOBIA2HLaU0t7at0dRoeSYoF6oQILAAAAgKJJYAEAAABQNC2EAAAAFM0uhICfOgAAAACKJoEFAAAAQNG0EALADsRugwDsiNrSI20F1V+UFAvUCz91AAAAABRNAgsAAACAomkhBAAAoGjtVS3tVa27w+hQUixQL1RgAQAAAFA0CSwAAAAAiqaFEAAAgKK1F7YLYXtBsUC98FMHAAAAQNEksAAAAAAomhZCAAAAitZe9Uh7VU79RUmxQL3wUwcAAABA0SSw6sz06dNzxBFHpG/fvtlzzz1z8sknZ8mSJZ3WVFWVqVOnZtCgQWlsbMwxxxyThx9+uJsiBgAAAOqdBFadufvuu3PeeeflBz/4QRYsWJANGzZk7NixeeGFFzrWzJgxIzNnzsyVV16Z+++/PwMGDMhxxx2X5557rhsjBwAA6lVbasUNYNtyD6w6c8cdd3R6/I1vfCN77rlnFi9enHe9612pqipXXHFFLrzwwrz//e9Pklx//fVpbm7OjTfemLPPPrs7wgYAAADqmAqsOtfS0pIk2X333ZMkjz32WFauXJmxY8d2rOndu3eOPvroLFy4sMvXWLt2bVpbWzsNAAAAgC1FAquOVVWVSZMm5R3veEdGjBiRJFm5cmWSpLm5udPa5ubmjud+0/Tp09PU1NQxBg8evHUDBwAA6sqmXQhLGsC25aeujv3Zn/1ZfvrTn+amm27a7LlarXNPd1VVm81tMnny5LS0tHSM5cuXb5V4AQAAgPrkHlh16hOf+ERuu+223HPPPdl777075gcMGJBkYyXWwIEDO+afeeaZzaqyNundu3d69+69dQMGAAAA6pYEVp2pqiqf+MQncuutt+auu+7K0KFDOz0/dOjQDBgwIAsWLMihhx6aJFm3bl3uvvvuXHrppd0Rct149qm9upzfY6+ntnEkAABQlrakqJ3/2ro7AKhDElh15rzzzsuNN96Yf/qnf0rfvn077mvV1NSUxsbG1Gq1TJw4MdOmTcuwYcMybNiwTJs2LTvvvHNOPfXUbo4eAAAAqEcSWHVm9uzZSZJjjjmm0/w3vvGNnHHGGUmSz33uc3nxxRdz7rnnZvXq1Rk1alTuvPPO9O3bdxtHCwAAACCBVXeqqvqta2q1WqZOnZqpU6du/YAAAAB+i9J2/ispFqgXfuoAAAAAKJoEFgAAAABF00IIhbDbIAAAdK2t6pG2gtr2SooF6oWfOgAAAACKJoEFAAAAQNG0EAIAAFC0KrW0p9bdYXSoCooF6oUKLAAAAACKJoEFAAAAQNG0EAIAAFA0uxACfuoAAAAAKJoEFgAAAABF00IIAABA0dqrWtqrcnb+KykWqBcqsAAAAAAomgQWAAAAAEXTQggAAEDR2tIjbQXVX5QUC9QLP3UAAAAAFE0CCwAAAICiaSEEAACgaHYhBFRgAQAAAFA0CSwAAAAAiqaFEAAAgKK1p0faC6q/KCkWqBd+6gAAAAAomgQWAAAAAEXTQggAAEDR2qpa2gra+a+kWKBeqMACAAAAoGgSWAAAAAAUTQshAAAARWuvamkvqG2vpFigXqjAAgAAgG1g1qxZGTp0aPr06ZORI0fm3nvvfcX1V111VYYPH57GxsYccMABmTdvXqfnjznmmNRqtc3GCSecsDVPA7qFCiwAAADYym6++eZMnDgxs2bNypgxY3L11Vdn3LhxeeSRR7LPPvtstn727NmZPHlyrrnmmhxxxBFZtGhRzjrrrOy222458cQTkyS33HJL1q1b13HMs88+m7e97W35wAc+sM3OC7YVCSwAAACKVlU90l6V00BUvY5YZs6cmTPPPDMf+9jHkiRXXHFFvvOd72T27NmZPn36ZutvuOGGnH322ZkwYUKSZL/99ssPfvCDXHrppR0JrN13373TMfPnz8/OO+8sgcUOqZzfAAAAALADWrduXRYvXpyxY8d2mh87dmwWLlzY5TFr165Nnz59Os01NjZm0aJFWb9+fZfHfP3rX88pp5ySXXbZZcsEDgWRwAIAAIDXobW1tdNYu3Ztl+tWrVqVtra2NDc3d5pvbm7OypUruzzm+OOPz7XXXpvFixenqqo88MADmTt3btavX59Vq1Zttn7RokV56KGHOiq8YEejhRAAKMJX/+v3upz/xIH/vo0jAaA0bamlLeXs/LcplsGDB3ea/8IXvpCpU6e+7HG1WudzqKpqs7lNpkyZkpUrV+bII49MVVVpbm7OGWeckRkzZqShoWGz9V//+tczYsSIvP3tb3+NZwPbBxVYAAAA8DosX748LS0tHWPy5Mldruvfv38aGho2q7Z65plnNqvK2qSxsTFz587NmjVr8vjjj2fZsmUZMmRI+vbtm/79+3dau2bNmsyfP1/1FTs0CSwAAAB4Hfr169dp9O7du8t1vXr1ysiRI7NgwYJO8wsWLMjo0aNf8Wv07Nkze++9dxoaGjJ//vyMHz8+PXp0/ij/d3/3d1m7dm0+8pGPvLETgoJpIQQAAKBo7VXSXpXTQthevfZjJk2alNNOOy2HH354jjrqqMyZMyfLli3LOeeckySZPHlynnrqqcybNy9JsnTp0ixatCijRo3K6tWrM3PmzDz00EO5/vrrN3vtr3/96zn55JOzxx57vKHzgpJJYAEAAMBWNmHChDz77LO5+OKLs2LFiowYMSK333579t133yTJihUrsmzZso71bW1tufzyy7NkyZL07Nkzxx57bBYuXJghQ4Z0et2lS5fmvvvuy5133rktTwe2OQksAAAA2AbOPffcnHvuuV0+d91113V6PHz48Pz4xz/+ra+5//77p6peR0kYbGcksACAIthtEICX0171SHtVzi2cS4oF6oWfOgAAAACKJoEFAAAAQNG0EAIAAFC09tTSnoJ2ISwoFqgXKrAAAAAAKJoEFgAAAABF00IIAABA0dqqWtqqctr2SooF6oUKLAAAAACKJoEFAAAAQNG0EAIAAFC09qpH2qty6i9KigXqhZ86AAAAAIomgQUAAABA0SSwAAAAACiae2ABAABQtPbU0l7VujuMDu0pJxaoFyqwAAAAACiaBBYAAAAARdNCCAAAQNGq1Ipq26sKigXqhQosAAAAAIomgQUAAABA0bQQAgAAULT2qrBdCAuKBeqFCiwAAAAAiiaBBQAAAEDRtBACAABQtPaqR9qrcuovSooF6oWfOgAAAACKJoEFAAAAQNG0EAIAAFA0uxACKrAAAAAAKJoEFgAAAABF00IIAABA0dpTS3vKadsrKRaoFyqwAAAAACiaBBYAAAAARdNCCAAAQNHsQgiowAIAAACgaBJYAAAAABRNCyEAAABF00IIqMACAAAAoGgSWAAAAAAUTQshAAAARdNCCKjAAgAAAKBoElgAAAAAFE0LIQAAAEXTQgiowAIAAACgaBJYAAAAABRNCyEAAABFq5K0p5y2vaq7A4A6pAILAAAAgKJJYAEAAABQNC2EAAAAFM0uhIAKLAAAAACKJoEFAAAAQNG0EAIAAFA0LYSACiwAAAAAiiaBBQAAAEDRtBACAABQNC2EgAosAAAAAIomgQUAAABA0bQQAgAAUDQthIAKLAAAAACKJoEFAAAAQNG0EAIAAFC0qqqlKqhtr6RYoF5IYAHAG3DUKZd3Of/9+Z/expEAAMCOSwshAAAAAEVTgQUAAEDR2lNLe8pp2yspFqgXKrAAAAAAKJoEFgAAAABF00IIAABA0dqrWtoL2vmvpFigXkhgAcAbYLdBeHVmPnrcZnOThi/ohkgAgO2RFkIAAAAAiqYCCwAAgKJVVS1VQW17JcUC9UIFFgAAAABFk8ACAAAAoGgSWHVs+vTpqdVqmThxYsdcVVWZOnVqBg0alMbGxhxzzDF5+OGHuy9IAACg7m3ahbCkAWxb7oFVp+6///7MmTMnBx98cKf5GTNmZObMmbnuuuuy//7750tf+lKOO+64LFmyJH379u2maAGA7Z0dBwGAN0IFVh16/vnn8+EPfzjXXHNNdtttt475qqpyxRVX5MILL8z73//+jBgxItdff33WrFmTG2+8sRsjBgAAAOqZBFYdOu+883LCCSfkPe95T6f5xx57LCtXrszYsWM75nr37p2jjz46CxcufNnXW7t2bVpbWzsNAACALWXTLoQlDWDb0kJYZ+bPn58f/ehHuf/++zd7buXKlUmS5ubmTvPNzc154oknXvY1p0+fnosuumjLBgoAAADwayqw6sjy5cvzyU9+Mt/85jfTp0+fl11Xq3X+14Sqqjab+78mT56clpaWjrF8+fItFjMAAACACqw6snjx4jzzzDMZOXJkx1xbW1vuueeeXHnllVmyZEmSjZVYAwcO7FjzzDPPbFaV9X/17t07vXv33nqBAwAAda0qbOc/LYSw7anAqiPvfve785//+Z958MEHO8bhhx+eD3/4w3nwwQez3377ZcCAAVmw4H93CVq3bl3uvvvujB49uhsjBwAA2P7NmjUrQ4cOTZ8+fTJy5Mjce++9r7j+qquuyvDhw9PY2JgDDjgg8+bN22zNr371q5x33nkZOHBg+vTpk+HDh+f222/fWqcA3UYFVh3p27dvRowY0Wlul112yR577NExP3HixEybNi3Dhg3LsGHDMm3atOy888459dRTuyNkAACAHcLNN9+ciRMnZtasWRkzZkyuvvrqjBs3Lo888kj22WefzdbPnj07kydPzjXXXJMjjjgiixYtyllnnZXddtstJ554YpKNBQfHHXdc9txzz/zDP/xD9t577yxfvjx9+/bd1qcHW50EFp187nOfy4svvphzzz03q1evzqhRo3LnnXf6BQgAAHSbKklVdXcU/+v1hDJz5syceeaZ+djHPpYkueKKK/Kd73wns2fPzvTp0zdbf8MNN+Tss8/OhAkTkiT77bdffvCDH+TSSy/tSGDNnTs3v/zlL7Nw4cL07NkzSbLvvvu+vpOCwmkhrHN33XVXrrjiio7HtVotU6dOzYoVK/LSSy/l7rvv3qxqCwAAgKS1tbXTWLt2bZfr1q1bl8WLF2fs2LGd5seOHZuFCxd2eczatWs323yrsbExixYtyvr165Mkt912W4466qicd955aW5uzogRIzJt2rS0tbVtgbODskhgAQAAwOswePDgNDU1dYyuKqmSZNWqVWlra9tsc6zm5uasXLmyy2OOP/74XHvttVm8eHGqqsoDDzyQuXPnZv369Vm1alWS5H/+53/yD//wD2lra8vtt9+ez3/+87n88stzySWXbNkThQJoIQQAAKBo7amllnJ2/mv/dSzLly9Pv379OuZ/2+7stVrnc6iqarO5TaZMmZKVK1fmyCOPTFVVaW5uzhlnnJEZM2akoaFhYxzt7dlzzz0zZ86cNDQ0ZOTIkXn66adz2WWX5S//8i/fyClCcVRgAQAAwOvQr1+/TuPlElj9+/dPQ0PDZtVWzzzzzGZVWZs0NjZm7ty5WbNmTR5//PEsW7YsQ4YMSd++fdO/f/8kycCBA7P//vt3JLSSZPjw4Vm5cmXWrVu3hc4SyiCBBQAAAFtRr169MnLkyCxYsKDT/IIFCzJ69OhXPLZnz57Ze++909DQkPnz52f8+PHp0WPjR/kxY8bk5z//edrb2zvWL126NAMHDkyvXr22/IlAN5LAAgAAoGhVVStuvFaTJk3Ktddem7lz5+bRRx/Npz71qSxbtiznnHNOkmTy5Mk5/fTTO9YvXbo03/zmN/Ozn/0sixYtyimnnJKHHnoo06ZN61jz8Y9/PM8++2w++clPZunSpfnXf/3XTJs2Leedd94bf9OhMO6BBQAAAFvZhAkT8uyzz+biiy/OihUrMmLEiNx+++3Zd999kyQrVqzIsmXLOta3tbXl8ssvz5IlS9KzZ88ce+yxWbhwYYYMGdKxZvDgwbnzzjvzqU99KgcffHD22muvfPKTn8z555+/rU8PtrpaVVVVdwfBjqW1tTVNTU1paWnpdENDAABg29ue/z7fFPvBf/+ZNOz8yjdI35ba1qzNTz/w5e3yPYXtlQosAAAAitZe1VJ7HW17W0t7QbFAvXAPLAAAAACKJoEFAAAAQNG0EAIAAFC0qto4SlFSLFAvVGABAAAAUDQJLAAAAACKpoUQAACAolVVLVVBO/+VFAvUCxVYAAAAABRNAgsAAACAomkhBAAAoGhaCAEVWAAAAAAUTQILAAAAgKJpIQQAAKBo7VUttYLa9toLigXqhQosAAAAAIomgQUAAABA0bQQAgAAULSq2jhKUVIsUC9UYAEAAABQNAksAAAAAIqmhRAAAICibWwhLGfnPy2EsO1JYAEAW8VxPT7Q5fyC9r/fxpEAALC900IIAAAAQNFUYAEAAFC0qqoV1kJYTixQL1RgAQAAAFA0CSwAAAAAiqaFEAAAgKJVvx6lKCkWqBcSWADAVmG3QQAAthQthAAAAAAUTQUWAAAARbMLIaACCwAAAICiSWABAAAAUDQthAAAAJTNNoRQ91RgAQAAAFA0CSwAAAAAiqaFEAAAgLIVtgthSooF6oQKLAAAAACKJoEFAAAAQNG0EAIAAFC0qto4SlFSLFAvJLAAqEvtK4d1Od9jwM+2cSQAAMBvo4UQAAAAgKKpwAIAAKBoVWG7EJYUC9QLFVgAAAAAFE0CCwAAAICiaSEEAACgbFVt4yhFSbFAnZDAAmCHZrdBAADY/mkhBAAAAKBoKrAAAAAoWlVtHKUoKRaoFyqwAAAAACiaBBYAAAAARdNCCAAAQNmqX49SlBQL1AkJLAB2aHYbBACA7Z8WQgAAAACKpgILAACAolVVLVVV6+4wOpQUC9QLFVgAAAAAFE0CCwAAAICiaSEEAACgfHb+g7qmAgsAAACAoklgAQAAAFA0LYQAAAAUzS6EgAosAAAAAIomgQUAAABA0bQQAuygjjrl8i7nvz//09s4EgCAN6hKWbsQlhQL1AkVWAAAAAAUTQILAAAAgKJpIQQAAKBwtV+PUpQUC9QHFVgAAAAAFE0CCwAAAICiaSEE2EHZbRAA2GHYhRDqngosAAAAAIomgQUAAABA0bQQAgAAUDYthFD3VGABAAAAUDQJLAAAAACKpoUQAACAslW1jaMUJcUCdUIFFgAAAABFk8ACAAAAoGhaCAEAAChaVW0cpSgpFqgXKrAAAABgG5g1a1aGDh2aPn36ZOTIkbn33ntfcf1VV12V4cOHp7GxMQcccEDmzZvX6fnrrrsutVpts/HSSy9tzdOAbqECCwAAALaym2++ORMnTsysWbMyZsyYXH311Rk3blweeeSR7LPPPputnz17diZPnpxrrrkmRxxxRBYtWpSzzjoru+22W0488cSOdf369cuSJUs6HdunT5+tfj6wrUlgAQAAULbq16MUryOWmTNn5swzz8zHPvaxJMkVV1yR73znO5k9e3amT5++2fobbrghZ599diZMmJAk2W+//fKDH/wgl156aacEVq1Wy4ABA17fecB2RAshAAAAbEXr1q3L4sWLM3bs2E7zY8eOzcKFC7s8Zu3atZtVUjU2NmbRokVZv359x9zzzz+ffffdN3vvvXfGjx+fH//4x1v+BKAAElgAAADwOrS2tnYaa9eu7XLdqlWr0tbWlubm5k7zzc3NWblyZZfHHH/88bn22muzePHiVFWVBx54IHPnzs369euzatWqJMmBBx6Y6667Lrfddltuuumm9OnTJ2PGjMnPfvazLXuiUAAJLAAAAMpW1cobSQYPHpympqaO0VUr4P9Vq9U6n1ZVbTa3yZQpUzJu3LgceeSR6dmzZ973vvfljDPOSJI0NDQkSY488sh85CMfydve9ra8853vzN/93d9l//33z1e/+tU3+IZDeSSwAAAA4HVYvnx5WlpaOsbkyZO7XNe/f/80NDRsVm31zDPPbFaVtUljY2Pmzp2bNWvW5PHHH8+yZcsyZMiQ9O3bN/379+/ymB49euSII45QgcUOSQILAAAAXod+/fp1Gr179+5yXa9evTJy5MgsWLCg0/yCBQsyevToV/waPXv2zN57752GhobMnz8/48ePT48eXX+Ur6oqDz74YAYOHPj6TggKZhdCAAAAilarNo5SvJ5YJk2alNNOOy2HH354jjrqqMyZMyfLli3LOeeckySZPHlynnrqqcybNy9JsnTp0ixatCijRo3K6tWrM3PmzDz00EO5/vrrO17zoosuypFHHplhw4altbU1f/M3f5MHH3wwV1111RY5TyiJBBYAAABsZRMmTMizzz6biy++OCtWrMiIESNy++23Z999902SrFixIsuWLetY39bWlssvvzxLlixJz549c+yxx2bhwoUZMmRIx5pf/epX+dM//dOsXLkyTU1NOfTQQ3PPPffk7W9/+7Y+PdjqalVVFZTHZkfQ2tqapqamtLS0pF+/ft0dDgAA1LXt+e/zTbEP/uuL06OxT3eH06H9xZey/JN/uV2+p7C9UoEFAABA2apfj1KUFAvUCTdxBwAAAKBoElgAAAAAFE0LIQAAAGWrahtHKUqKBeqECiwAAAAAiiaBBQAAAEDRtBACAABQNrsQQt1TgQUAAABA0SSwAAAAACiaFkKoE3+08Jwu5/9h9Ne2cSQAAPAaaSGEuqcCCwAAAICiSWABAAAAUDQthAAAAJRNCyHUPRVYAAAAABRNAqsOPfXUU/nIRz6SPfbYIzvvvHMOOeSQLF68uOP5qqoyderUDBo0KI2NjTnmmGPy8MMPd2PEAAAAQD3TQlhnVq9enTFjxuTYY4/Nt7/97ey555757//+77zpTW/qWDNjxozMnDkz1113Xfbff/986UtfynHHHZclS5akb9++3Rc8b4jdBgEA2G5VtY2jFCXFAnVCAqvOXHrppRk8eHC+8Y1vdMwNGTKk47+rqsoVV1yRCy+8MO9///uTJNdff32am5tz44035uyzz97WIQMAAAB1Tgthnbntttty+OGH5wMf+ED23HPPHHroobnmmms6nn/ssceycuXKjB07tmOud+/eOfroo7Nw4cIuX3Pt2rVpbW3tNAAAAAC2FAmsOvM///M/mT17doYNG5bvfOc7Oeecc/Lnf/7nmTdvXpJk5cqVSZLm5uZOxzU3N3c895umT5+epqamjjF48OCtexIAAEBdqVXlDWDbksCqM+3t7TnssMMybdq0HHrooTn77LNz1llnZfbs2Z3W1Wqde7qrqtpsbpPJkyenpaWlYyxfvnyrxQ8AAADUHwmsOjNw4MC89a1v7TQ3fPjwLFu2LEkyYMCAJNms2uqZZ57ZrCprk969e6dfv36dBgAAAMCWIoFVZ8aMGZMlS5Z0mlu6dGn23XffJMnQoUMzYMCALFiwoOP5devW5e67787o0aO3aawAAABJkqrAAWxTdiGsM5/61KcyevToTJs2LR/84AezaNGizJkzJ3PmzEmysXVw4sSJmTZtWoYNG5Zhw4Zl2rRp2XnnnXPqqad2c/QAAABAPZLAqjNHHHFEbr311kyePDkXX3xxhg4dmiuuuCIf/vCHO9Z87nOfy4svvphzzz03q1evzqhRo3LnnXemb9++3Rg5AAAAUK9qVVUpfmSLam1tTVNTU1paWtwPCwAAutn2/Pf5ptj3ufRL6dHYp7vD6dD+4ktZdv7nt8v3FLZX7oEFAAAAQNEksAAAAAAomntgAQAAULRaklpBN7+pdXcAUIdUYAEAAABQNAksAAAAAIqmhRAAAICyVbWNoxQlxQJ1QgUWAAAAAEWTwAIAAACgaFoIAQAAKFv161GKkmKBOqECCwAAAICiSWABAAAAUDQthAAAAJRNCyHUPRVYAAAAABRNAgsAAACAomkhBAAAoGi1auMoRUmxQL1QgQUAAABA0SSwAAAAACiaFkIAAADKZhdCqHsqsAAAAAAomgQWAAAAAEXTQghAkY7r8YEu5xe0//02jgQA6HZaCKHuqcACAAAAoGgSWAAAAAAUTQshAAAARatVG0cpSooF6oUKLAAAAACKJoEFAAAAQNG0EAJQJLsNAgAdqtrGUYqSYoE6oQILAAAAgKJJYAEAAABQNC2EAAAAlK369ShFSbFAnVCBBQAAAEDRJLAAAAAAKJoWQmCH9NX/+r0u5z9x4L9v40gAAHijatXGUYqSYoF6oQILAAAAgKJJYAEAAABQNC2EAAAAlM0uhFD3VGABAAAAUDQJLAAAAACKpoUQ2CHZbRAAYAdS2C6EWghh21OBBQAAAEDRJLAAAAAAKJoWQgAAAMpmF0KoeyqwAAAAACiaBBYAAAAARdNCCAAAQNm0EELdU4EFAAAAQNEksAAAAAAomhZCAAAAilarNo5SlBQL1AsVWAAAAAAUTQILAAAAgKJJYAEAAABQNAksAAAAAIomgQUAAADbwKxZszJ06ND06dMnI0eOzL333vuK66+66qoMHz48jY2NOeCAAzJv3ryXXTt//vzUarWcfPLJWzhqKINdCAEAAChb9etRitcRy80335yJEydm1qxZGTNmTK6++uqMGzcujzzySPbZZ5/N1s+ePTuTJ0/ONddckyOOOCKLFi3KWWedld122y0nnnhip7VPPPFEPvOZz+Sd73zn6z0jKJ4KLAAAANjKZs6cmTPPPDMf+9jHMnz48FxxxRUZPHhwZs+e3eX6G264IWeffXYmTJiQ/fbbL6ecckrOPPPMXHrppZ3WtbW15cMf/nAuuuii7LffftviVKBbSGABAADA69Da2tpprF27tst169aty+LFizN27NhO82PHjs3ChQu7PGbt2rXp06dPp7nGxsYsWrQo69ev75i7+OKL8+Y3vzlnnnnmGzwbKJsEFgAAAEWrVeWNJBk8eHCampo6xvTp07uMf9WqVWlra0tzc3On+ebm5qxcubLLY44//vhce+21Wbx4caqqygMPPJC5c+dm/fr1WbVqVZLkP/7jP/L1r38911xzzZZ7s6FQ7oEFAAAAr8Py5cvTr1+/jse9e/d+xfW1Wq3T46qqNpvbZMqUKVm5cmWOPPLIVFWV5ubmnHHGGZkxY0YaGhry3HPP5SMf+Uiuueaa9O/f/42fDBROAgsAAABeh379+nVKYL2c/v37p6GhYbNqq2eeeWazqqxNGhsbM3fu3Fx99dX5xS9+kYEDB2bOnDnp27dv+vfvn5/+9Kd5/PHHO93Qvb29PUmy0047ZcmSJXnLW97yBs4OyqKFEAAAgPJVBY3XqFevXhk5cmQWLFjQaX7BggUZPXr0Kx7bs2fP7L333mloaMj8+fMzfvz49OjRIwceeGD+8z//Mw8++GDHOOmkk3LsscfmwQcfzODBg197oFAwFVgAAACwlU2aNCmnnXZaDj/88Bx11FGZM2dOli1blnPOOSdJMnny5Dz11FOZN29ekmTp0qVZtGhRRo0aldWrV2fmzJl56KGHcv311ydJ+vTpkxEjRnT6Gm9605uSZLN52BFIYAEAAMBWNmHChDz77LO5+OKLs2LFiowYMSK333579t133yTJihUrsmzZso71bW1tufzyy7NkyZL07Nkzxx57bBYuXJghQ4Z00xlA96pVVfU6CiDh5bW2tqapqSktLS2vqh8cAEr01slf6XL+kemf2saRALwx2/Pf55ti/53zp6Whd5/uDqdD29qX8vNL/2K7fE9he+UeWAAAAAAUTQILAAAAgKK5BxYAAABFq1UbRylKigXqhQosAAAAAIqmAgsAqGtu1g4AUD4JLAAAAMpW/XqUoqRYoE5oIQQAAACgaBJYAAAAABRNCyEAAABFswshoAILAAAAgKKpwAIA6prdBgEAyieBBQAAQNnsQgh1TwshAAAAAEWTwAIAAACgaFoIAQAAKJsWQqh7KrAAAAAAKJoEFgAAAABF00IIAABA0WrVxlGKkmKBeqECCwAAAICiSWABAAAAUDQthAAAAJTNLoRQ91RgAQAAAFA0CSwAAAAAiqaFEAAAgLJpIYS6pwILAAAAgKJJYAEAAABQNC2EAAAAFK1WbRylKCkWqBcqsAAAAAAomgQWAAAAAEXTQggAAEDZ7EIIdU8FFgAAAABFk8ACAAAAoGhaCAEAACiaXQgBFVgAAAAAFE0CCwAAAICiaSEEAACgbHYhhLqnAgsAAACAoklgAQAAAFA0LYQAAACUTQsh1D0VWAAAAAAUTQILAAAAgKJpIQQAAKBotV+PUpQUC9QLFVgAAAAAFE0CCwAAAICiaSEEAACgbHYhhLqnAqvObNiwIZ///OczdOjQNDY2Zr/99svFF1+c9vb2jjVVVWXq1KkZNGhQGhsbc8wxx+Thhx/uxqgBAACAeiaBVWcuvfTSfO1rX8uVV16ZRx99NDNmzMhll12Wr371qx1rZsyYkZkzZ+bKK6/M/fffnwEDBuS4447Lc889142RAwAAAPVKC2Gd+f73v5/3ve99OeGEE5IkQ4YMyU033ZQHHnggycbqqyuuuCIXXnhh3v/+9ydJrr/++jQ3N+fGG2/M2Wef3W2xAwAA9alWbRylKCkWqBcqsOrMO97xjnz3u9/N0qVLkyQ/+clPct999+W9731vkuSxxx7LypUrM3bs2I5jevfunaOPPjoLFy7s8jXXrl2b1tbWTgMAAABgS1GBVWfOP//8tLS05MADD0xDQ0Pa2tpyySWX5EMf+lCSZOXKlUmS5ubmTsc1NzfniSee6PI1p0+fnosuumjrBg4AAADULRVYdebmm2/ON7/5zdx444350Y9+lOuvvz5f/vKXc/3113daV6vVOj2uqmqzuU0mT56clpaWjrF8+fKtFj8AAFCHqgIHsE2pwKozn/3sZ3PBBRfklFNOSZIcdNBBeeKJJzJ9+vR89KMfzYABA5JsrMQaOHBgx3HPPPPMZlVZm/Tu3Tu9e/fe+sEDAAAAdUkFVp1Zs2ZNevTofNkbGhrS3t6eJBk6dGgGDBiQBQsWdDy/bt263H333Rk9evQ2jRUAAAAgUYFVd0488cRccskl2WefffK7v/u7+fGPf5yZM2fmT/7kT5JsbB2cOHFipk2blmHDhmXYsGGZNm1adt5555x66qndHD0AAFC3tO1BXZPAqjNf/epXM2XKlJx77rl55plnMmjQoJx99tn5y7/8y441n/vc5/Liiy/m3HPPzerVqzNq1Kjceeed6du3bzdGDgAAANSrWlVV8thsUa2trWlqakpLS0v69evX3eEAAEBd257/Pt8U+++ePS0Nvfp0dzgd2ta9lIev/ovt8j2F7ZUKLAAAAIpWqzaOUpQUC9QLN3EHAAAAoGgSWAAAAAAUTQshAAAAZatS1i6EJcUCdUIFFgAAAABFk8ACAAAAoGhaCAEAACiaXQgBFVgAAAAAFE0CCwAAAICiaSEEAACgbHYhhLqnAgsAAACAoklgAQAAAFA0LYQAAAAUzS6EgAosAAAAAIqmAgsAAOAN2G/m5V3O/8+kT2/jSAB2XBJYAAAAlM0uhFD3tBACAAAAUDQJLAAAAACKpoUQAACAsmkhhLqnAgsAAACAoklgAQAAvAH/M+nTXQ74TbNmzcrQoUPTp0+fjBw5Mvfee+8rrr/qqqsyfPjwNDY25oADDsi8efM6PX/LLbfk8MMPz5ve9KbssssuOeSQQ3LDDTdszVOAbqOFEAAAgKLVqo2jFK8nlptvvjkTJ07MrFmzMmbMmFx99dUZN25cHnnkkeyzzz6brZ89e3YmT56ca665JkcccUQWLVqUs846K7vttltOPPHEJMnuu++eCy+8MAceeGB69eqVf/mXf8kf//EfZ88998zxxx//Rk8TilKrqqqgXwPsCFpbW9PU1JSWlpb069evu8MBAIC6tj3/fb4p9rd9dFoaevXp7nA6tK17KT+5/i9e03s6atSoHHbYYZk9e3bH3PDhw3PyySdn+vTpm60fPXp0xowZk8suu6xjbuLEiXnggQdy3333vezXOeyww3LCCSfki1/84ms4IyifFkIAAADYitatW5fFixdn7NixnebHjh2bhQsXdnnM2rVr06dP56RdY2NjFi1alPXr12+2vqqqfPe7382SJUvyrne9a8sFD4XQQggAAEDZCt2FsLW1tdN0796907t3782Wr1q1Km1tbWlubu4039zcnJUrV3b5JY4//vhce+21Ofnkk3PYYYdl8eLFmTt3btavX59Vq1Zl4MCBSZKWlpbstddeWbt2bRoaGjJr1qwcd9xxW+AkoSwqsAAAAOB1GDx4cJqamjpGV62A/1etVuv0uKqqzeY2mTJlSsaNG5cjjzwyPXv2zPve976cccYZSZKGhoaOdX379s2DDz6Y+++/P5dcckkmTZqUu+666w2dF5RIBRYAAAC8DsuXL+90D6yuqq+SpH///mloaNis2uqZZ57ZrCprk8bGxsydOzdXX311fvGLX2TgwIGZM2dO+vbtm/79+3es69GjR37nd34nSXLIIYfk0UcfzfTp03PMMce8wbODsqjAAgAAoGi1qipuJEm/fv06jZdLYPXq1SsjR47MggULOs0vWLAgo0ePfsVz79mzZ/bee+80NDRk/vz5GT9+fHr0ePmP8lVVZe3ata/xHYbyqcACAACArWzSpEk57bTTcvjhh+eoo47KnDlzsmzZspxzzjlJksmTJ+epp57KvHnzkiRLly7NokWLMmrUqKxevTozZ87MQw89lOuvv77jNadPn57DDz88b3nLW7Ju3brcfvvtmTdvXqedDmFHIYEFAAAAW9mECRPy7LPP5uKLL86KFSsyYsSI3H777dl3332TJCtWrMiyZcs61re1teXyyy/PkiVL0rNnzxx77LFZuHBhhgwZ0rHmhRdeyLnnnpsnn3wyjY2NOfDAA/PNb34zEyZM2NanB1tdraqqkvZyYAfQ2tqapqamtLS0dOoHBwAAtr3t+e/zTbEf8pFL0tCrT3eH06Ft3Ut58JsXbpfvKWyv3AMLAAAAgKJpIQSoMzMfPa7L+UnDF3Q5DwAA0N0ksAAAAChardo4SlFSLFAvtBACAAAAUDQJLAAAAACKpoUQAACAslW/HqUoKRaoEyqwAAAAACiaCiyAOmO3QQAAYHsjgQUAAEDR7EIIaCEEAAAAoGgSWAAAAAAUTQshAAAAZbMLIdQ9FVgAAAAAFE0CCwAAAICiaSEEAACgaHYhBFRgAQAAAFA0CSwAAAAAiqaFEAAAgLLZhRDqngosAAAAAIomgQUAAABA0bQQAgAAUDw7/0F9U4EFAAAAQNEksAAAAAAomhZCAAAAylZVG0cpSooF6oQKLAAAAACKJoEFAAAAQNG0EAIAAFC0WlXWLoQlxQL1QgUWAAAAAEWTwAIAAACgaFoIAQAAKFv161GKkmKBOqECCwAAAICiSWABAAAAUDQthAAAABSt1r5xlKKkWKBeqMACAAAAoGgSWAAAAAAUTQshAAAAZbMLIdQ9FVgAAAAAFE0CCwAAAICiaSEEAACgaLVq4yhFSbFAvVCBBQAAAEDRJLAAAAAAKJoWQgAAAMpWVRtHKUqKBeqECiwAAAAAiiaBBQAAAEDRtBACAABQNLsQAiqwAAAAACiaBBYAAAAARZPAAgAAAKBo7oEFAABA2apfj1KUFAvUCRVYAAAAABRNAgsAAACAomkhBAAAoGi1auMoRUmxQL1QgQUAAABA0SSwAAAAACiaFkIAAADKVlUbRylKigXqhAosAAAAAIomgQUAAABA0bQQAgAAUDS7EAIqsAAAAAAomgQWAAAAAEXTQggAAEDZql+PUpQUC9QJFVgAAAAAFE0CCwAAAICiaSEEAACgaHYhBFRgAQAAAFA0CSwAAAAAiqaFEAAAgLK1VxtHKUqKBeqECiwAAAAAiiaBBQAAAEDRtBACAABQturXoxQlxQJ1QgUWAAAAAEWTwAIAAACgaFoIAQAAKFotSa2gtr1adwcAdUgFFgAAAABFk8ACAAAAoGhaCAEAAChbVW0cpSgpFqgTKrAAAAAAKJoE1g7knnvuyYknnphBgwalVqvlW9/6Vqfnq6rK1KlTM2jQoDQ2NuaYY47Jww8/3GnN2rVr84lPfCL9+/fPLrvskpNOOilPPvnkNjwLAACAHdOsWbMydOjQ9OnTJyNHjsy99977iuuvuuqqDB8+PI2NjTnggAMyb968Ts9fc801eec735nddtstu+22W97znvdk0aJFW/MUoNtIYO1AXnjhhbztbW/LlVde2eXzM2bMyMyZM3PllVfm/vvvz4ABA3Lcccflueee61gzceLE3HrrrZk/f37uu+++PP/88xk/fnza2tq21WkAAAB0UqvKG6/VzTffnIkTJ+bCCy/Mj3/847zzne/MuHHjsmzZsi7Xz549O5MnT87UqVPz8MMP56KLLsp5552Xf/7nf+5Yc9ddd+VDH/pQvve97+X73/9+9tlnn4wdOzZPPfXU632roVi1qtK8uyOq1Wq59dZbc/LJJyfZWH01aNCgTJw4Meeff36SjdVWzc3NufTSS3P22WenpaUlb37zm3PDDTdkwoQJSZKnn346gwcPzu23357jjz/+VX3t1tbWNDU1paWlJf369dsq5wcAALw62/Pf55tif8fvTc1OO/Xp7nA6bNjwUu7796mv6T0dNWpUDjvssMyePbtjbvjw4Tn55JMzffr0zdaPHj06Y8aMyWWXXdYxN3HixDzwwAO57777uvwabW1t2W233XLllVfm9NNPf41nBWVTgVUnHnvssaxcuTJjx47tmOvdu3eOPvroLFy4MEmyePHirF+/vtOaQYMGZcSIER1rurJ27dq0trZ2GgAAADu63/wctHbt2i7XrVu3LosXL+70WStJxo4d+7KftdauXZs+fTon7RobG7No0aKsX7++y2PWrFmT9evXZ/fdd38dZwNlk8CqEytXrkySNDc3d5pvbm7ueG7lypXp1atXdtttt5dd05Xp06enqampYwwePHgLRw8AANS1qsCRZPDgwZ0+C3VVSZUkq1atSltb2yt+HvtNxx9/fK699tosXrw4VVXlgQceyNy5c7N+/fqsWrWqy2MuuOCC7LXXXnnPe97T9fsI27GdujsAtq1ardbpcVVVm839pt+2ZvLkyZk0aVLH49bWVkksAABgh7d8+fJOLYS9e/d+xfWv5fPYlClTsnLlyhx55JGpqirNzc0544wzMmPGjDQ0NGy2fsaMGbnpppty1113bVa5BTsCFVh1YsCAAUmyWXb/mWee6fhXgAEDBmTdunVZvXr1y67pSu/evdOvX79OAwAAYEf3m5+DXi6B1b9//zQ0NLzi57Hf1NjYmLlz52bNmjV5/PHHs2zZsgwZMiR9+/ZN//79O6398pe/nGnTpuXOO+/MwQcfvGVODgojgVUnhg4dmgEDBmTBggUdc+vWrcvdd9+d0aNHJ0lGjhyZnj17dlqzYsWKPPTQQx1rAAAAtrVaVRU3XotevXpl5MiRnT5rJcmCBQt+62etnj17Zu+9905DQ0Pmz5+f8ePHp0eP//0of9lll+WLX/xi7rjjjhx++OGvKS7Ynmgh3IE8//zz+fnPf97x+LHHHsuDDz6Y3XffPfvss08mTpyYadOmZdiwYRk2bFimTZuWnXfeOaeeemqSpKmpKWeeeWY+/elPZ4899sjuu++ez3zmMznooIP0UAMAALwBkyZNymmnnZbDDz88Rx11VObMmZNly5blnHPOSbLx1ixPPfVU5s2blyRZunRpFi1alFGjRmX16tWZOXNmHnrooVx//fUdrzljxoxMmTIlN954Y4YMGdJR4bXrrrtm11133fYnCVuRBNYO5IEHHsixxx7b8XjTfak++tGP5rrrrsvnPve5vPjiizn33HOzevXqjBo1KnfeeWf69u3bccxXvvKV7LTTTvngBz+YF198Me9+97tz3XXXddljDQAAwKszYcKEPPvss7n44ouzYsWKjBgxIrfffnv23XffJBu7X5YtW9axvq2tLZdffnmWLFmSnj175thjj83ChQszZMiQjjWzZs3KunXr8kd/9EedvtYXvvCFTJ06dVucFmwztap6jbWP8Fu0tramqakpLS0t7ocFAADdbHv++3xT7O981xey007l3Jh8w4aXcu89F22X7ylsr9wDCwAAAICiSWABAAAAUDT3wAIAAKBor2fnv62ppFigXqjAAgAAAKBoElgAAAAAFE0LIQAAAGWrfj1KUVIsUCdUYAEAAABQNAksAAAAAIqmhRAAAICyVdXGUYqSYoE6oQILAAAAgKJJYAEAAABQNC2EAAAAFK1WbRylKCkWqBcqsAAAAAAomgQWAAAAAEXTQggAAEDZ7EIIdU8FFgAAAABFk8ACAAAAoGhaCAEAACharX3jKEVJsUC9UIEFAAAAQNEksAAAAAAomhZC2AJ+/01ndjl/x6++vo0jAQCAHZBdCKHuqcACAAAAoGgSWAAAAAAUTQshAAAAZat+PUpRUixQJ1RgAQAAAFA0CSwAAAAAiqaFELYAuw0CAMDWU6uq1Ara+a+kWKBeqMACAAAAoGgSWAAAAAAUTQshAAAAZauqjaMUJcUCdUIFFgAAAABFk8ACAAAAoGhaCAEAAChblaS9u4P4P3QQwjanAgsAAACAoklgAQAAAFA0LYQAAAAUrVZVqRW0819JsUC9UIEFAAAAQNEksAAAAAAomhZCAAAAylYlKaltr6BQoF6owAIAAACgaBJYAAAAABRNCyEAAABlq6rCWggLigXqhAosAAAAAIomgQUAAABA0bQQAgAAULb2JLXuDuL/aO/uAKD+qMACAAAAoGgSWAAAAAAUTQshAAAARatVVWoF7fxXUixQL1RgAQAAAFA0CSwAAAAAiqaFEAAAgLJV1cZRipJigTqhAgsAAACAoklgAQAAAFA0LYQAAACUTQsh1D0VWAAAAAAUTQILAAAAgKJpIQQAAKBsWgih7qnAAgAAAKBoElgAAAAAFE0LIQAAAGVrT1Lr7iD+j/buDgDqjwosAAAAAIomgQUAAABA0bQQwlZ03E6ndDm/YMP8bRwJAABsv2pVlVpBO/+VFAvUCxVYAAAAABRNAgsAAACAomkhBAAAoGxVtXGUoqRYoE6owAIAAACgaBJYAAAAABRNCyFsRXYbBACALaC9SmoFte21FxQL1AkVWAAAAAAUTQILAAAAgKJpIQQAAKBsdiGEuqcCCwAAAICiSWABAAAAUDQthAAAABSusBbClBQL1AcVWAAAAAAUTQILAAAAtoFZs2Zl6NCh6dOnT0aOHJl77733FddfddVVGT58eBobG3PAAQdk3rx5nZ5/+OGH84d/+IcZMmRIarVarrjiiq0YPXQvCSwAAADKtmkXwpLGa3TzzTdn4sSJufDCC/PjH/8473znOzNu3LgsW7asy/WzZ8/O5MmTM3Xq1Dz88MO56KKLct555+Wf//mfO9asWbMm++23X/7qr/4qAwYMeN1vL2wPJLAAAABgK5s5c2bOPPPMfOxjH8vw4cNzxRVXZPDgwZk9e3aX62+44YacffbZmTBhQvbbb7+ccsopOfPMM3PppZd2rDniiCNy2WWX5ZRTTknv3r231alAt5DAAgAAgK1o3bp1Wbx4ccaOHdtpfuzYsVm4cGGXx6xduzZ9+vTpNNfY2JhFixZl/fr1Wy1WKJUEFgAAAGVrr8obSVpbWzuNtWvXdhn+qlWr0tbWlubm5k7zzc3NWblyZZfHHH/88bn22muzePHiVFWVBx54IHPnzs369euzatWqLfv+wnZAAgsAAABeh8GDB6epqaljTJ8+/RXX12q1To+rqtpsbpMpU6Zk3LhxOfLII9OzZ8+8733vyxlnnJEkaWho2CLxw/ZEAgsAAABeh+XLl6elpaVjTJ48uct1/fv3T0NDw2bVVs8888xmVVmbNDY2Zu7cuVmzZk0ef/zxLFu2LEOGDEnfvn3Tv3//LX4uUDoJLAAAAMpWtZc3kvTr16/TeLkbqffq1SsjR47MggULOs0vWLAgo0ePfsVT79mzZ/bee+80NDRk/vz5GT9+fHr08FGe+rNTdwcAAAAAO7pJkybltNNOy+GHH56jjjoqc+bMybJly3LOOeckSSZPnpynnnoq8+bNS5IsXbo0ixYtyqhRo7J69erMnDkzDz30UK6//vqO11y3bl0eeeSRjv9+6qmn8uCDD2bXXXfN7/zO72z7k4StSAILAAAAtrIJEybk2WefzcUXX5wVK1ZkxIgRuf3227PvvvsmSVasWJFly5Z1rG9ra8vll1+eJUuWpGfPnjn22GOzcOHCDBkypGPN008/nUMPPbTj8Ze//OV8+ctfztFHH5277rprW50abBO1qqqq7g6CHUtra2uamprS0tKSfv36dXc4AABQ17bnv883xf6ewR/PTj26bs/rDhva1+bfls/eLt9T2F5pnAUAAACgaBJYAAAAABTNPbAAAAAoW3uVpKC737QXFAvUCRVYAAAAABRNAgsAAACAomkhBAAAoGxVtXGUoqRYoE6owAIAAACgaBJYAAAAABRNCyEAAABlq1JW215BoUC9UIEFAAAAQNFUYAEA8LL2m3l5l/P/M+nT2zgSAKCeSWABAABQNrsQQt3TQggAAABA0SSwAAAAACiaFkIAAADK1t6epL27o/hf7QXFAnVCBRYAAAAARVOBBQDAy7LbIABQAgksAAAAymYXQqh7WggBAAAAKJoEFgAAAABF00IIAABA2bQQQt1TgbUDueeee3LiiSdm0KBBqdVq+da3vtXx3Pr163P++efnoIMOyi677JJBgwbl9NNPz9NPP93pNdauXZtPfOIT6d+/f3bZZZecdNJJefLJJ7fxmQAAAAD8LwmsHcgLL7yQt73tbbnyyis3e27NmjX50Y9+lClTpuRHP/pRbrnllixdujQnnXRSp3UTJ07Mrbfemvnz5+e+++7L888/n/Hjx6etrW1bnQYAAABAJ1oIdyDjxo3LuHHjunyuqakpCxYs6DT31a9+NW9/+9uzbNmy7LPPPmlpacnXv/713HDDDXnPe96TJPnmN7+ZwYMH59/+7d9y/PHHb/VzAAAA2Ex7laSgtr32gmKBOqECq461tLSkVqvlTW96U5Jk8eLFWb9+fcaOHduxZtCgQRkxYkQWLlz4sq+zdu3atLa2dhoAAAAAW4oEVp166aWXcsEFF+TUU09Nv379kiQrV65Mr169sttuu3Va29zcnJUrV77sa02fPj1NTU0dY/DgwVs1dgAAAKC+SGDVofXr1+eUU05Je3t7Zs2a9VvXV1WVWq32ss9Pnjw5LS0tHWP58uVbMlwAAKDOVVV7cQPYtiSw6sz69evzwQ9+MI899lgWLFjQUX2VJAMGDMi6deuyevXqTsc888wzaW5uftnX7N27d/r169dpAAAAAGwpElh1ZFPy6mc/+1n+7d/+LXvssUen50eOHJmePXt2utn7ihUr8tBDD2X06NHbOlwAAACAJHYh3KE8//zz+fnPf97x+LHHHsuDDz6Y3XffPYMGDcof/dEf5Uc/+lH+5V/+JW1tbR33tdp9993Tq1evNDU15cwzz8ynP/3p7LHHHtl9993zmc98JgcddFDHroQAAADbXFWVtfNfVVAsUCcksHYgDzzwQI499tiOx5MmTUqSfPSjH83UqVNz2223JUkOOeSQTsd973vfyzHHHJMk+cpXvpKddtopH/zgB/Piiy/m3e9+d6677ro0NDRsk3MAAAAA+E0SWDuQY445JtUr/EvAKz23SZ8+ffLVr341X/3qV7dkaAAAAACvmwQWAAAAZauqJAW17WkhhG3OTdwBAAAAKJoKLHYox/z+pV3O33XH+ds4EgAAAGBLkcACAACgbO3tSa29u6P4X1VBsUCd0EIIAAAAQNEksAAAAAAomhZCAAAAymYXQqh7KrAAAAAAKJoKLHYodhsEAACAHY8EFgAAAEWr2ttTFbQLYWUXQtjmtBACAAAAUDQJLAAAAACKpoUQAACAstmFEOqeCiwAAAAAiiaBBQAAAEDRtBACAABQtvYqqRXUtqeFELY5FVgAAAAAFE0CCwAAAICiaSEEAACgbFWVpL27o/hfWghhm5PAYourfv3LvLW1tZsjAQAANv1dXkm6ANsxCSy2uOeeey5JMnjw4G6OBAAA2OS5555LU1NTd4cB8LpIYLHFDRo0KMuXL0/fvn3z3HPPZfDgwVm+fHn69evX3aGxBbW2trq2OyjXdsfl2u64XNsdl2u749qW17aqqjz33HMZNGjQVv06W1PVXqUqaBdC1Wyw7UlgscX16NEje++9d5KkVqslSfr16+ePrh2Ua7vjcm13XK7tjsu13XG5tjuubXVtVV4B2zu7EAIAAABQNBVYAAAAlK1qT1m7EBYUC9QJFVhsVb17984XvvCF9O7du7tDYQtzbXdcru2Oy7Xdcbm2Oy7Xdsfl2gK8NrXK3ecAAAAoUGtra5qamnJsw/uzU61nd4fTYUO1Pt9ruyUtLS3uTwfbiBZCAAAAimYXQkALIQAAAABFk8ACAAAAoGhaCAEAACibXQih7qnAYquZNWtWhg4dmj59+mTkyJG59957uzskXqPp06fniCOOSN++fbPnnnvm5JNPzpIlSzqtqaoqU6dOzaBBg9LY2JhjjjkmDz/8cDdFzOs1ffr01Gq1TJw4sWPOtd1+PfXUU/nIRz6SPfbYIzvvvHMOOeSQLF68uON513b7tGHDhnz+85/P0KFD09jYmP322y8XX3xx2tv/90OUa7t9uOeee3LiiSdm0KBBqdVq+da3vtXp+VdzHdeuXZtPfOIT6d+/f3bZZZecdNJJefLJJ7fhWdCVV7q269evz/nnn5+DDjoou+yySwYNGpTTTz89Tz/9dKfXcG0BuiaBxVZx8803Z+LEibnwwgvz4x//OO985zszbty4LFu2rLtD4zW4++67c9555+UHP/hBFixYkA0bNmTs2LF54YUXOtbMmDEjM2fOzJVXXpn7778/AwYMyHHHHZfnnnuuGyPntbj//vszZ86cHHzwwZ3mXdvt0+rVqzNmzJj07Nkz3/72t/PII4/k8ssvz5ve9KaONa7t9unSSy/N1772tVx55ZV59NFHM2PGjFx22WX56le/2rHGtd0+vPDCC3nb296WK6+8ssvnX811nDhxYm699dbMnz8/9913X55//vmMHz8+bW1t2+o06MIrXds1a9bkRz/6UaZMmZIf/ehHueWWW7J06dKcdNJJnda5tl3bkPXZUBU0sr673xKoPxVsBW9/+9urc845p9PcgQceWF1wwQXdFBFbwjPPPFMlqe6+++6qqqqqvb29GjBgQPVXf/VXHWteeumlqqmpqfra177WXWHyGjz33HPVsGHDqgULFlRHH3109clPfrKqKtd2e3b++edX73jHO172edd2+3XCCSdUf/Inf9Jp7v3vf3/1kY98pKoq13Z7laS69dZbOx6/muv4q1/9qurZs2c1f/78jjVPPfVU1aNHj+qOO+7YZrHzyn7z2nZl0aJFVZLqiSeeqKrKte3Kiy++WA0YMKBKUtwYMGBA9eKLL3b3WwR1QwUWW9y6deuyePHijB07ttP82LFjs3Dhwm6Kii2hpaUlSbL77rsnSR577LGsXLmy07Xu3bt3jj76aNd6O3HeeeflhBNOyHve855O867t9uu2227L4Ycfng984APZc889c+ihh+aaa67peN613X694x3vyHe/+90sXbo0SfKTn/wk9913X9773vcmcW13FK/mOi5evDjr16/vtGbQoEEZMWKEa72daWlpSa1W66iSdW0316dPnzz22GNpaWkpbjz22GPp06dPd79FUDfcxJ0tbtWqVWlra0vz/2/vbkJsbPg4jv/nnjEzCJlRhjSilNuwYGbjJRa27CQvodgowzCIWFjN2Fko1GxsJDbKy8rINGVFmLwsvGTCgmxE8pq5ntV9eqbBjedh/kefT1mc67qaLv06zel7OGfixEHHJ06cGM+fPx+mu+J/VRRFtLe3x6JFi2L27NkREaU9v7T148ePf/s98mNOnToVN27ciGvXrg05Z9vy9ejRozh27Fi0t7fHvn374urVq7Ft27aoqamJ9evX27aM7dmzJ169ehUzZ86MysrK+Pz5c3R0dMTq1asjwvP2T/E9Oz5//jyqq6tj/PjxQ67xWqt8vH//Pvbu3Rtr1qyJsWPHRoRtv6a2tlYoAgQsfp2KiopBj4uiGHKM8tHa2hq3bt2KK1euDDln6/Lz9OnTaGtri4sXL37zBaFty8/AwEC0tLREZ2dnRETMnTs37t69G8eOHYv169eXrrNt+Tl9+nScOHEiTp48GU1NTdHX1xfbt2+PyZMnx4YNG0rX2fbP8DM72rp8fPr0KVatWhUDAwNx9OjRf73etgA+xJ1fYMKECVFZWTnkXaIXL14MeTeR8rB169Y4d+5c9PT0xJQpU0rHGxoaIiJsXYauX78eL168iObm5qiqqoqqqqro7e2Nw4cPR1VVVWk/25afSZMmxaxZswYd+/vvv0tfouF5W752794de/fujVWrVsWcOXNi3bp1sWPHjjh48GBE2PZP8T07NjQ0xMePH+Ply5dfvYa8Pn36FCtXroz+/v7o7u4u/eurCNsCfIuAxf9ddXV1NDc3R3d396Dj3d3dsWDBgmG6K35GURTR2toaZ86cicuXL8e0adMGnZ82bVo0NDQM2vrjx4/R29tr6+SWLl0at2/fjr6+vtKflpaWWLt2bfT19cX06dNtW6YWLlwY9+7dG3Ts/v37MXXq1IjwvC1nb9++jb/+GvzSrbKyMgYGBiLCtn+K79mxubk5RowYMeiaZ8+exZ07d2yd3D/x6sGDB3Hp0qWor68fdN62AF/nvxDyS7S3t8e6deuipaUl5s+fH11dXfHkyZPYvHnzcN8aP2DLli1x8uTJOHv2bIwZM6b0bvC4ceNi5MiRUVFREdu3b4/Ozs6YMWNGzJgxIzo7O2PUqFGxZs2aYb57vmXMmDGlzzL7x+jRo6O+vr503LblaceOHbFgwYLo7OyMlStXxtWrV6Orqyu6uroiIjxvy9jy5cujo6MjGhsbo6mpKW7evBmHDh2KjRs3RoRty8mbN2/i4cOHpcf9/f3R19cXdXV10djY+K87jhs3LjZt2hQ7d+6M+vr6qKuri127dsWcOXOGfCkHv9e3tp08eXKsWLEibty4ERcuXIjPnz+XXlvV1dVFdXW1bQG+Zbi+/pA/35EjR4qpU6cW1dXVxbx584re3t7hviV+UHzlK4OPHz9eumZgYKA4cOBA0dDQUNTU1BSLFy8ubt++PXw3zU9bsmRJ0dbWVnps2/J1/vz5Yvbs2UVNTU0xc+bMoqura9B525an169fF21tbUVjY2NRW1tbTJ8+vdi/f3/x4cOH0jW2LQ89PT1f/P26YcOGoii+b8d3794Vra2tRV1dXTFy5Mhi2bJlxZMnT4bhb8N/+9a2/f39X31t1dPTU/oZtgX4soqiKIrfGcwAAAAA4Ef4DCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABSE7AAAAAASE3AAgAAACA1AQsAAACA1AQsAAAAAFITsAAAAABITcACAAAAIDUBCwAAAIDUBCwAAAAAUhOwAAAAAEhNwAIAAAAgNQELAAAAgNQELAAAAABS+w/s0dn8N5CmxAAAAABJRU5ErkJggg==' width=1200.0/>
</div>




```python
##################################################################################################################
#
# YouDo:
#  1) Remove any rows with na values
# 
#  2) Split the data into "test" and "train" bits with ~30% in the test set.
#       The "Label" column is the "y" data.  All other columns are the "X" data
#       Give them these names:
#       X_train, X_test, y_train, y_test

#######################################  BEGIN STUDENT CODE  #####################################################

# 1)import pandas as pd
from sklearn.model_selection import train_test_split


data = pd.read_csv("C:/Users/chl_b/BIOS6644_Spring_2024_OLD/Modules/students/Module_1/data/sugar_metabolomics.csv")

# Drop columns with more than 50% missing values
threshold = len(data) * 0.5
data_reduced = data.dropna(thresh=threshold, axis=1)

# Remove any rows with NA values from the reduced dataset
data_cleaned = data_reduced.dropna()

# Separate features (X) and labels (y), excluding 'Unnamed: 0' as it's likely an index column
X = data_cleaned.drop(columns=['Label', 'Unnamed: 0'])
y = data_cleaned['Label']

#2 Split the data into train and test sets (70% train, 30% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Verify the shapes of the resulting datasets (optional)
print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)


#######################################   END STUDENT CODE   #####################################################

```

    X_train shape: (54, 124)
    X_test shape: (24, 124)
    y_train shape: (54,)
    y_test shape: (24,)
    


```python
# Convert all columns to numeric, forcing any non-numeric strings to NaN
# This might introduce NaN values if non-numeric strings are present
for column in X_train.columns:
    X_train[column] = pd.to_numeric(X_train[column], errors='coerce')
    X_test[column] = pd.to_numeric(X_test[column], errors='coerce')

# Now, you might need to handle any newly introduced NaN values
# One approach is to fill them with the median of the column
X_train.fillna(X_train.median(), inplace=True)
X_test.fillna(X_test.median(), inplace=True)

# Try fitting the model again
clf = RandomForestClassifier(n_estimators=100, max_depth=2, random_state=8675309)
clf.fit(X_train, y_train)

# And then make predictions
predictions = clf.predict(X_test)
reality = y_test  # This is just your y_test set, already suitable for comparison

```


```python
#Build a model to classify the Label based on the other columns

from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier(n_estimators=100, max_depth=2, random_state=8675309)
clf.fit(X_train, y_train)

```




<style>#sk-container-id-2 {color: black;background-color: white;}#sk-container-id-2 pre{padding: 0;}#sk-container-id-2 div.sk-toggleable {background-color: white;}#sk-container-id-2 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-2 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-2 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-2 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-2 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-2 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-2 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-2 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-2 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-2 div.sk-item {position: relative;z-index: 1;}#sk-container-id-2 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-2 div.sk-item::before, #sk-container-id-2 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-2 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-2 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-2 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-2 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-2 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-2 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-2 div.sk-label-container {text-align: center;}#sk-container-id-2 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-2 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(max_depth=2, random_state=8675309)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier(max_depth=2, random_state=8675309)</pre></div></div></div></div></div>




```python
# Test the model
predictions = clf.predict(X_test)
reality = y_test
```


```python
# YouDo:
#  1) Evaluate the "goodness" of the predictions and write a paragraph describing the results as a markdown.
#
#######################################  BEGIN STUDENT CODE  #####################################################
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt

# Compute metrics
accuracy = accuracy_score(y_test, predictions)
precision = precision_score(y_test, predictions)
recall = recall_score(y_test, predictions)
f1 = f1_score(y_test, predictions)

# Confusion Matrix
conf_matrix = confusion_matrix(y_test, predictions)

# ROC AUC
# Note: roc_auc_score and roc_curve require the probability scores of the positive class, which can be obtained using clf.predict_proba()
y_scores = clf.predict_proba(X_test)[:, 1]  # Assuming the positive class is at index 1
roc_auc = roc_auc_score(y_test, y_scores)
fpr, tpr, thresholds = roc_curve(y_test, y_scores)

# Printing the metrics
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1 Score: {f1:.4f}")
print("Confusion Matrix:\n", conf_matrix)

# Plotting ROC Curve
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, label=f'ROC curve (area = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], 'k--')  # Random guess line
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend(loc="lower right")
plt.show()


#######################################   END STUDENT CODE   #####################################################

```

    Accuracy: 0.9583
    Precision: 1.0000
    Recall: 0.9375
    F1 Score: 0.9677
    Confusion Matrix:
     [[ 8  0]
     [ 1 15]]
    



<div style="display: inline-block;">
    <div class="jupyter-widgets widget-label" style="text-align: center;">
        Figure
    </div>
    <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAJYCAYAAACadoJwAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjguMCwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy81sbWrAAAACXBIWXMAAA9hAAAPYQGoP6dpAABz70lEQVR4nO3dd3RU5eL18T3pIZAE6U2KiICKhIQuVToCokiVDtKUJiDIlWbBq1KlKSAIUqVdUKRJL9IjYFBUeolISwIh/Xn/8Me8xoQSSOYkk+9nrVnLeeacmT05xMye5xSbMcYIAAAAABzAxeoAAAAAADIPCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAAAAAh6GAAAAAAHAYCggAZDBz586VzWaz39zc3JQvXz61bt1av/32W7LrxMbGavr06apcubL8/Pzk7e2tUqVKaejQobp69Wqy6yQkJGj+/PmqU6eOcubMKXd3d+XOnVsvvvii1qxZo4SEhPtmjY6O1pQpU/T8888re/bs8vDwUIECBdSyZUtt27btkX4OAICMiQICABnUnDlztGfPHm3atElvvPGGVq9ereeff17Xr19PtFxkZKTq1q2rN998UwEBAVq0aJHWrl2r9u3b64svvlBAQIB+/fXXROtERUWpUaNG6tixo3Lnzq3p06dr8+bNmjFjhvLnz69XX31Va9asuWe+K1euqGrVqho4cKCeeeYZzZ07Vz/88IPGjRsnV1dXvfDCC/rpp59S/ecCAEjfbMYYY3UIAMCDmzt3rjp37qz9+/crKCjIPj5mzBiNHDlSX375pTp37mwf79Gjh7744gstXrxYrVq1SvRcJ06cUIUKFVSwYEH99NNPcnV1lST17t1b06dP11dffaUOHTokyfDbb7/p9u3bKlOmzF1zNmrUSBs3btT69etVu3btJI/v379fefLk0eOPP57in8G/3b59W97e3o/8PACAtMcMCAA4iTtl5M8//7SPhYaG6ssvv1T9+vWTlA9JKlGihN5++239/PPPWrVqlX2dWbNmqX79+smWD0l68skn71k+Dh48qO+//15du3ZNtnxIUvny5e3lY9SoUbLZbEmWubO72enTp+1jRYoU0YsvvqgVK1YoICBAXl5eGj16tAICAlStWrUkzxEfH68CBQro5Zdfto/FxMTo/fffV8mSJeXp6alcuXKpc+fO+uuvv+76ngAAqYMCAgBO4tSpU5L+LhV3bNmyRXFxcXrppZfuut6dxzZu3GhfJzY29p7r3M+GDRsSPXdqO3TokAYPHqy+fftq3bp1euWVV9S5c2ft3LkzyXEwGzZs0MWLF+2zQgkJCWrWrJk++ugjtW3bVt99950++ugjbdy4UTVr1tTt27fTJDMA4G9uVgcAADyc+Ph4xcXFKSoqSrt27dL777+v6tWrq2nTpvZlzp49K0kqWrToXZ/nzmN3ln2Qde4nNZ7jXi5fvqyQkJBEZatYsWIaPHiw5s6dqw8++MA+PnfuXOXJk0cNGzaUJC1dulTr1q3T8uXLE82KPPfccypfvrzmzp2rXr16pUluAAAzIACQYVWqVEnu7u7Kli2bGjRooOzZs+t///uf3Nwe7rul5HaBSq/KlCmTqHxIUo4cOdSkSRN99dVX9jN0Xb9+Xf/73//UoUMH+8/l22+/lb+/v5o0aaK4uDj7rWzZssqbN6+2bt3q6LcDAJkKBQQAMqh58+Zp//792rx5s3r06KHjx4+rTZs2iZa5c4zFnd2zknPnsUKFCj3wOveTGs9xL/ny5Ut2vEuXLrpw4YJ9d7JFixYpOjpanTp1si/z559/6saNG/Lw8JC7u3uiW2hoqK5cuZImmQEAf6OAAEAGVapUKQUFBalWrVqaMWOGunXrpnXr1mnZsmX2ZWrVqiU3Nzf7AebJufNY3bp17eu4u7vfc537qV+/fqLnvh8vLy9Jf1835J/uVgbuNltTv3595c+fX3PmzJH096mKK1asqNKlS9uXyZkzp3LkyKH9+/cne5s2bdoDZQYAPBwKCAA4iY8//ljZs2fXiBEj7Lsg5c2bV126dNH69eu1ZMmSJOucOHFC//3vf/X000/bDxjPmzevunXrpvXr12vevHnJvtYff/yhI0eO3DVLuXLl1LBhQ82ePVubN29OdpkDBw7YjxUpUqSIJCV5zvtda+TfXF1d1b59e61atUo7duzQgQMH1KVLl0TLvPjii7p69ari4+MVFBSU5PbUU0+l6DUBACnDdUAAIIO523VAJOmTTz7RkCFDNH/+fL322muSpFu3bqlx48batWuXXn/9dTVp0kSenp768ccf9emnnypLlizatGlTog/eUVFReumll7Rhwwa1adNGzZs3V548eXTlyhVt3LhRc+bM0eLFi9WsWbO75rxy5YoaNGigo0ePqkuXLmrYsKGyZ8+uS5cuac2aNVq0aJEOHjyo5557TuHh4SpatKgKFCigMWPGyM3NTXPnztWhQ4d06tQpnTp1yl5SihQpomeeeUbffvttsq974sQJPfXUUypYsKCuXr2qS5cuyc/Pz/54fHy8mjRpor1796pfv36qUKGC3N3ddf78eW3ZskXNmjVT8+bNH3bzAADugwICABnMvQpIVFSUnnrqKXl6eur48eP2CwvGxsZq5syZmjdvnn7++WfFxsaqSJEiatasmYYMGaIcOXIkeZ34+HgtWLBAX331lYKDgxUeHq7s2bMrKChI7du3V6tWreTicu+J9KioKM2cOVOLFi3Szz//rMjISOXOnVuVKlVS165d1ahRI/uy+/fvV//+/fXTTz/J399f3bp1U6FChdStW7cUFRBJqlq1qnbv3q127drp66+/TvJ4XFycJk2apPnz5+vXX3+Vm5ubChYsqBo1amjQoEEqXrz4Pd8XAODhUUAAAAAAOAzHgAAAAABwGAoIAAAAAIehgAAAAABwGAoIAAAAAIehgAAAAABwGAoIAAAAAIdxszoA/r+EhARdvHhR2bJlk81mszoOAAAA/sUYo4iICOXPn/++10JC8igg6cjFixdVqFAhq2MAAADgPs6dO6eCBQtaHSNDooCkI9myZZP09z9oX19fi9MAAADg38LDw1WoUCH75zakHAUkHbmz25Wvry8FBAAAIB1jd/mHx45rAAAAAByGAgIAAADAYSggAAAAAByGAgIAAADAYSggAAAAAByGAgIAAADAYSggAAAAAByGAgIAAADAYSggAAAAAByGAgIAAADAYSggAAAAAByGAgIAAADAYSggAAAAAByGAnIX27dvV5MmTZQ/f37ZbDatWrXqvuts27ZNgYGB8vLyUrFixTRjxoy0DwoAAABkIBSQu7h165aee+45TZky5YGWP3XqlBo1aqRq1arp8OHDeuedd9S3b18tX748jZMCAAAAGYeb1QHSq4YNG6phw4YPvPyMGTP0+OOPa+LEiZKkUqVK6cCBA/r000/1yiuvpFFKAAAAIGOhgKSSPXv2qF69eonG6tevr9mzZys2Nlbu7u4WJQNSjzFGt2PjrY4BAEAS3u6ustlsVsfAA6CApJLQ0FDlyZMn0ViePHkUFxenK1euKF++fEnWiY6OVnR0tP1+eHh4mucEHpYxRi1m7NHBM9etjgIAgCTp1q+7lBAZpmwBjRQypr6yePDRNiNgK6Wif7duY0yy43eMHTtWo0ePTvNcQGq4HRtP+QAApAsmLkbXt8xWxKHvJBdXeeYvaXUkpAAFJJXkzZtXoaGhicYuX74sNzc35ciRI9l1hg0bpoEDB9rvh4eHq1ChQmmaE0gNB/5TR1k8XK2OAQDIhP74/Xe1b9dGZ4ODJUkDBgzQyNHd5O3O36WMggKSSipXrqw1a9YkGtuwYYOCgoLuevyHp6enPD09HREPSFVZPFyZ5gYAONzixYv1+uuvKyIiQjly5NC8efPUqFEjq2MhhTgN713cvHlTwcHBCv6/dn3q1CkFBwfr7Nmzkv6evejQoYN9+Z49e+rMmTMaOHCgjh8/ri+//FKzZ8/WoEGDrIgPAADgVGbPnq02bdooIiJCzz//vIKDgykfGRQF5C4OHDiggIAABQQESJIGDhyogIAAjRgxQpJ06dIlexmRpKJFi2rt2rXaunWrypYtq/fee0+TJ0/mFLwAAACpoEWLFipevLiGDx+uLVu2qGDBglZHwkOymTtHSsNy4eHh8vPzU1hYmHx9fa2OAyQSGROn0iPWSxJnGgEAOMTWrVtVo0YN+wl9IiMjlSVLFksz8Xnt0TEDAgAAgHQlMjJSXbt2Va1atTRt2jT7uNXlA6mDrzABAACQboSEhOjVV19VSEiIbDYb10lzQhQQAAAAWM4Yo7lz56pPnz66ffu28ubNq4ULF6pWrVpWR0Mqo4AAAADAUjdv3lTv3r01f/58SVLdunX19ddfK3fu3BYnQ1rgGBAAAABY6tixY1q4cKFcXFz0wQcfaN26dZQPJ8YMCAAAACxVqVIlTZ48Wc8++6yqVatmdRykMWZAAAAA4FDh4eHq3LmzQkJC7GO9e/emfGQSzIAAAADAYQ4fPqyWLVvq999/V3BwsA4ePCgXF74Tz0zY2gAAAEhzxhhNnTpVlSpV0u+//67HH39c06ZNo3xkQsyAAAAAIE3duHFD3bt317JlyyRJTZs21Zw5c/TYY49ZnAxWoIAAAAAgzZw5c0a1atXSqVOn5O7uro8//lj9+vWTzWazOhosQgEBAABAmilQoIAKFiwoSVqyZInKly9vcSJYjQICAACAVHX9+nVlyZJFnp6ecnNz09KlS+Xl5SV/f3+royEd4KgfAAAApJoff/xRZcuW1dtvv20fy5s3L+UDdhQQAAAAPLKEhAR98sknqlatms6ePau1a9cqIiLC6lhIhyggAAAAeCRXrlxRkyZNNGTIEMXFxal169Y6cOCAsmXLZnU0pEMcAwIAAICHtmPHDrVp00YXLlyQl5eXJk+erG7dunGWK9wVBQQAAAAP5ebNm3rppZd07do1PfXUU1q6dKnKlCljdSykcxSQTMwYo9ux8VbHQAYRGcO/FQBAYlmzZtXnn3+u1atXa9q0acqaNavVkZABUEAyKWOMWszYo4NnrlsdBQAAZCBbt25VQkKCateuLUlq0aKFWrRoYXEqZCQchJ5J3Y6Np3zgoQQVzi5vd1erYwAAHCw+Pl6jR4/WCy+8oNatW+vSpUtWR0IGxQwIdOA/dZTFgw+UeDDe7q4cWAgAmUxoaKjatWunzZs3S5KaNGkiPz8/i1Mho6KAQFk8XJXFg38KAAAgqU2bNqldu3a6fPmyfHx8NH36dLVv397qWMjA2AULAAAASSQkJOjdd99VvXr1dPnyZT377LM6cOAA5QOPjAICAACAJFxcXHTu3DkZY9SjRw/t3btXJUuWtDoWnAD73QAAAMAuPj5erq5/Hxs6depUNW/eXM2aNbM4FZwJMyAAAABQbGyshg4dqpdeekkJCQmSJB8fH8oHUh0zIAAAAJnc2bNn1aZNG+3evVuStHnzZtWpU8fiVHBWzIAAAABkYmvWrFHZsmW1e/du+fn5admyZZQPpCkKCAAAQCYUExOjt956S02bNtX169dVvnx5HT58WK+88orV0eDkKCAAAACZUIcOHTR+/HhJ0oABA7Rz504VLVrU4lTIDCggAAAAmdCgQYOUN29e/e9//9P48ePl4eFhdSRkEhyEDgAAkAlER0dr3759qlatmiQpKChIJ0+elLe3t8XJkNkwAwIAAODkfv/9d1WpUkV169ZVcHCwfZzyAStQQAAAAJzY0qVLVa5cOR06dEhZs2bV1atXrY6ETI4CAgAA4IRu376tXr16qVWrVoqIiNDzzz+v4OBgvfDCC1ZHQyZHAQEAAHAyv/76qypVqqQZM2bIZrNp+PDh2rJliwoWLGh1NICD0AEAAJzNypUrdeTIEeXOnVtff/216tata3UkwI4CAgAA4GSGDBmi8PBwvfnmm8qXL5/VcYBE2AULAAAggwsJCVHr1q11+/ZtSZKLi4s+/PBDygfSJWZAAAAAMrC5c+eqT58+ioyMVMGCBfXpp59aHQm4JwoIAABABnTz5k316dNH8+bNkyTVrVtXgwcPtjgVcH/sggUAAJDBHD16VOXLl9e8efPk4uKiDz74QOvWrVOePHmsjgbcFzMgAAAAGciaNWvUsmVLRUVFqUCBAlq0aJGqVatmdSzggVFAAAAAMpCyZcvKx8dHtWrV0rx585QzZ06rIwEpQgEBAABI5y5dumQ/o1WhQoX0448/qlixYnJxYW96ZDz8qwUAAEinjDGaNm2aihYtqtWrV9vHixcvTvlAhsW/XAAAgHQoLCxMLVu2VJ8+fRQdHa0VK1ZYHQlIFRQQAACAdObAgQMKCAjQsmXL5O7urgkTJmjOnDlWxwJSBceAAAAApBPGGE2ePFmDBw9WbGysihQpoqVLl6p8+fJWRwNSDTMgAAAA6cSOHTvUv39/xcbG6uWXX9bhw4cpH3A6zIAAAACkE9WrV1f//v1VvHhx9e7dWzabzepIQKqjgAAAAFgkISFBU6dOVYsWLeyn2Z0wYYLFqYC0xS5YAAAAFrh69aqaNm2qvn37ql27doqPj7c6EuAQzIAAAAA42M6dO9WmTRudP39enp6eatWqFdf1QKbBv3QAAAAHSUhI0NixY1WzZk2dP39eJUqU0N69e9WjRw+O90CmwQwIAACAA1y9elXt2rXT+vXrJUmvvfaapk+frqxZs1qcDHAsZkAAAAAcwNPTU2fOnJG3t7dmz56tefPmUT6QKTEDAgAAkEbi4+Nls9nk4uKirFmzatmyZZKkp59+2uJkgHWYAQEAAEgDoaGhql+/fqLT6j799NOUD2R6FBAAAIBUtmnTJpUtW1Y//PCD3n//fd24ccPqSEC6QQEBAABIJXFxcXr33XdVr149/fnnn3r22We1Z88e+fv7Wx0NSDc4BgQAACAVXLhwQW3bttX27dslSa+//romTpwob29vi5MB6QsFBAAA4BFFRkaqQoUKunjxorJmzaqZM2eqdevWVscC0iV2wQIAAHhEWbJk0aBBgxQQEKBDhw5RPoB7oIAAAAA8hLNnzyokJMR+v3///tqzZ4+efPJJC1MB6R8FBAAAIIXWrFmjgIAAvfTSS4qIiJAk2Ww2eXp6WpwMSP8oIAAAAA8oJiZGb731lpo2bapr167Jz89PYWFhVscCMhQKCAAAwAM4ffq0qlWrpvHjx0v6e5erXbt2qWDBghYnAzIWzoIFAABwH6tWrVLnzp1148YN+fv7a+7cuWrWrJnVsYAMiQICAABwD8YYTZ06VTdu3FClSpW0ePFiFS5c2OpYQIbFLlgAAAD3YLPZ9PXXX2vUqFHavn075QN4RBQQAACAf1m6dKkGDRpkv58nTx6NHDlS7u7uFqYCnAMF5B6mTZumokWLysvLS4GBgdqxY8c9l1+wYIGee+45ZcmSRfny5VPnzp119epVB6UFAACP6vbt2+rZs6datWqlcePGad26dVZHApwOBeQulixZov79+2v48OE6fPiwqlWrpoYNG+rs2bPJLr9z50516NBBXbt21c8//6xvvvlG+/fvV7du3RycHAAAPIxff/1VlSpV0ueffy6bzaZ33nlHderUsToW4HQoIHcxfvx4de3aVd26dVOpUqU0ceJEFSpUSNOnT092+R9//FFFihRR3759VbRoUT3//PPq0aOHDhw44ODkAAAgpRYsWKDAwEAdOXJEuXLl0rp16/TBBx/IzY3z9QCpjQKSjJiYGB08eFD16tVLNF6vXj3t3r072XWqVKmi8+fPa+3atTLG6M8//9SyZcvUuHFjR0QGAAAPafDgwXrttdd069Yt1axZU8HBwUk+AwBIPRSQZFy5ckXx8fHKkydPovE8efIoNDQ02XWqVKmiBQsWqFWrVvLw8FDevHnl7++vzz777K6vEx0drfDw8EQ3AADgWDVq1JCLi4tGjhypTZs2KX/+/FZHApwaBeQebDZbovvGmCRjd4SEhKhv374aMWKEDh48qHXr1unUqVPq2bPnXZ9/7Nix8vPzs98KFSqUqvkBAEDyzp8/b//vF198USdOnNCoUaPk6upqYSogc6CAJCNnzpxydXVNMttx+fLlJLMid4wdO1ZVq1bV4MGDVaZMGdWvX1/Tpk3Tl19+qUuXLiW7zrBhwxQWFma/nTt3LtXfCwAA+P9u3rypjh07qkyZMolOLPPEE09YmArIXCggyfDw8FBgYKA2btyYaHzjxo2qUqVKsutERkbKxSXxj/POtyjGmGTX8fT0lK+vb6IbAABIG0ePHlX58uU1b948hYWFaevWrVZHAjIlCshdDBw4ULNmzdKXX36p48ePa8CAATp79qx9l6phw4apQ4cO9uWbNGmiFStWaPr06Tp58qR27dqlvn37qkKFCuxLCgCAhYwxmjVrlipUqKBffvlF+fPn1+bNmxP9HQfgOJxb7i5atWqlq1evasyYMbp06ZKeeeYZrV27VoULF5YkXbp0KdHUbadOnRQREaEpU6borbfekr+/v2rXrq3//ve/Vr0FAAAyvYiICPXs2VMLFy6UJDVo0EDz5s1Trly5LE4GZF42c7f9g+Bw4eHh8vPzU1hYWJrvjhUZE6fSI9ZLkkLG1FcWD7ooAMD5jBw5UmPGjJGrq6s+/PBDDRo0KMku00BKOPLzmrPiUycAAHBaQ4cO1aFDhzRs2LC7HscJwLH4CgAAADiNsLAwffDBB4qPj5ckeXt7a82aNZQPIB1hBgQAADiFAwcOqGXLljp16pQSEhL07rvvWh0JQDKYAQEAABmaMUaTJk1SlSpVdOrUKRUuXFj16tWzOhaAu2AGBAAAZFjXr19Xly5dtGrVKklS8+bNNXv2bGXPnt3aYADuihkQAACQIR08eFABAQFatWqVPDw8NHnyZC1fvpzyAaRzzIAAAIAMyc3NTaGhoSpWrJiWLl2qwMBAqyMBeAAUEAAAkGHExsbK3d1dkvTcc8/p22+/Vfny5eXn52dxMgAPil2wAABAhrBr1y6VLFlS+/bts4/VqVOH8gFkMBQQAACQriUkJGjs2LGqUaOGTp48qREjRlgdCcAjYBcsAACQbl2+fFnt27fXhg0bJEnt2rXT9OnTLU4F4FFQQAAAQLq0detWtW3bVpcuXZK3t7emTJmizp07y2azWR0NwCOggAAAgHTnxx9/1AsvvKCEhASVKlVKS5cu1TPPPGN1LACpgAICAADSnYoVK6pRo0bKmTOnpkyZIh8fH6sjAUglFBAAAJAubNu2TYGBgcqaNatsNpuWLVsmT09Pq2MBSGWcBQsAAFgqLi5O7777rmrVqqVevXrJGCNJlA/ASTEDAgAALHPhwgW1bdtW27dvlyR5e3srPj5ebm58RAGcFb/dAADAEuvWrVP79u115coVZc2aVV988YXatGljdSwAaYxdsAAAgEPFxsZq2LBhatiwoa5cuaKyZcvq4MGDlA8gk6CAAAAAh7p+/brmzJkjSerdu7f27NmjEiVKWJwKgKOwCxYAAHCo3Llza+HChbp27ZpatGhhdRwADkYBAQAAaSomJkbvvPOOypcvr1atWkmSateubXEqAFahgAAAgDRz+vRptW7dWnv37pWvr6/q1KmjHDlyWB0LgIU4BgQAAKSJVatWKSAgQHv37pW/v7+++uorygcACggAAEhd0dHR6tevn5o3b64bN26oYsWKCg4O1ksvvWR1NADpALtgAQCAVBMVFaVq1arpwIEDkqRBgwbpww8/lLu7u8XJAKQXFBAAAJBqvLy8VK1aNZ08eVLz5s1T48aNrY4EIJ1hFywAAPBIoqKidPnyZfv9jz76SEeOHKF8AEgWBQQAADy0EydOqFKlSmrevLliY2MlSR4eHipQoIDFyQCkVxQQAADwUBYuXKjAwED99NNPOnHihH7//XerIwHIACggAAAgRSIjI9W9e3e1a9dON2/eVI0aNfTTTz+pVKlSVkcDkAFQQAAAwAM7fvy4KlasqFmzZslms2nEiBHatGmT8ufPb3U0ABkEZ8ECAAAPxBijrl276tixY8qTJ48WLFigF154wepYADIYZkAAAMADsdls+vLLL9WsWTMFBwdTPgA8FAoIAAC4q6NHj2rmzJn2+yVLltSqVauUN29eC1MByMjYBQsAACRhjNHs2bP15ptvKiYmRk899ZSqV69udSwAToACAgAAEomIiFDPnj21cOFCSVL9+vU5wxWAVMMuWAAAwC44OFiBgYFauHChXF1dNXbsWK1du1a5cuWyOhoAJ8EMCAAAkCTNmjVLb7zxhqKjo1WwYEEtXrxYVatWtToWACfDDAgAAJAkxcXFKTo6Wi+++KKCg4MpHwDSBDMgAABkYrGxsXJ3d5ck9ejRQ/nz51eTJk1ks9ksTgbAWTEDAgBAJmSM0WeffaZnn31WN27ckPT3dT6aNm1K+QCQpiggAABkMtevX9crr7yivn376tdff9Xs2bOtjgQgE2EXLAAAMpG9e/eqVatWOnPmjDw8PPTpp5/qjTfesDoWgEyEGRAAADIBY4zGjRun559/XmfOnFGxYsW0e/duvfnmm+xyBcChKCAAAGQCY8eO1aBBgxQXF6dXX31Vhw4dUmBgoNWxAGRCFBAAADKBHj16qHjx4po+fbqWLFkiPz8/qyMByKQ4BgQAACeUkJCg7777Tk2aNJEk5ciRQz///LM8PDwsTgYgs2MGBAAAJ/PXX3+pcePGatq0qebOnWsfp3wASA+YAQEAwIls27ZNbdu21cWLF+Xl5WV1HABIghkQAACcQHx8vN577z3Vrl1bFy9eVMmSJbVv3z516tTJ6mgAkAgzIAAAZHChoaF67bXX9MMPP0iSOnbsqKlTp8rHx8fiZACQFAUEAIAM7ueff9bmzZuVJUsWTZs2TR07drQ6EgDcFQUEAIAM7oUXXtDUqVNVo0YNlS5d2uo4AHBPHAMCAEAGc/HiRTVr1kx//PGHfaxXr16UDwAZAjMgAABkIOvXr1f79u31119/KTw8XFu2bLE6EgCkCDMgAABkAHFxcRo2bJgaNGigv/76S88995w+//xzq2MBQIoxAwIAQDp37tw5tWnTRrt27ZL09+5W48eP5zofADIkCggAAOnY0aNHVbNmTV27dk2+vr6aOXOmWrZsaXUsAHhoTrcLVlxcnDZt2qTPP/9cERERkv4+WO/mzZsWJwMAIOWeeuopFStWTIGBgTp06BDlA0CG51QzIGfOnFGDBg109uxZRUdHq27dusqWLZs+/vhjRUVFacaMGVZHBADgvs6fP6+8efPKzc1NHh4eWrNmjbJnzy5PT0+rowHAI3OqGZB+/fopKChI169fl7e3t328efPm9qvDAgCQnq1atUrPPvusRowYYR/Lmzcv5QOA03CqGZCdO3dq165d8vDwSDReuHBhXbhwwaJUAADcX3R0tN5++21NmjRJkrRlyxbFxMQk+ZsGABmdU82AJCQkKD4+Psn4+fPnlS1bNgsSAQBwfydPnlTVqlXt5eOtt97Stm3bKB8AnJJTFZC6detq4sSJ9vs2m003b97UyJEj1ahRI+uCAQBwF8uWLVNAQIAOHjyoxx57TKtXr9ann35K+QDgtJxqF6wJEyaoVq1aKl26tKKiotS2bVv99ttvypkzpxYtWmR1PAAAErl8+bI6deqkW7duqWrVqlq0aJEKFSpkdSwASFNOVUDy58+v4OBgLV68WAcPHlRCQoK6du2qdu3aJTooHQCA9CB37tyaNm2ajh8/rjFjxsjd3d3qSACQ5pyqgGzfvl1VqlRR586d1blzZ/t4XFyctm/frurVq1uYDgAAadGiRSpYsKCqVasmSerQoYPFiQDAsZzqGJBatWrp2rVrScbDwsJUq1YtCxIBAPC327dvq3v37mrbtq3atGmjq1evWh0JACzhVDMgxhjZbLYk41evXpWPj48FiQAAkI4fP66WLVvq2LFjstls6ty5s/z8/KyOBQCWcIoC8vLLL0v6+6xXnTp1SnSxpvj4eB05ckRVqlSxKh4AIBObN2+eevXqpcjISOXJk0dff/216tSpY3UsALCMUxSQO98iGWOULVu2RAece3h4qFKlSurevbtV8QAAmVBMTIx69OihuXPnSpJq166tBQsWKG/evNYGAwCLOUUBmTNnjiSpSJEiGjRoELtbAQAs5+7urps3b8rFxUWjRo3SO++8I1dXV6tjAYDlnOog9JEjR6Zq+Zg2bZqKFi0qLy8vBQYGaseOHfdcPjo6WsOHD1fhwoXl6empJ554Ql9++WWq5QEApG/GGMXExEj6e7fgWbNmaevWrXr33XcpHwDwf5xiBuSfli1bpqVLl+rs2bP2PwJ3HDp06IGfZ8mSJerfv7+mTZumqlWr6vPPP1fDhg0VEhKixx9/PNl1WrZsqT///FOzZ89W8eLFdfnyZcXFxT3S+wEAZAwRERHq1auXoqKi9M0338hms8nPz89+ul0AwN+cagZk8uTJ6ty5s3Lnzq3Dhw+rQoUKypEjh06ePKmGDRum6LnGjx+vrl27qlu3bipVqpQmTpyoQoUKafr06ckuv27dOm3btk1r165VnTp1VKRIEVWoUIGD3wEgE/jpp58UFBSkBQsWaNWqVTp8+LDVkQAg3XKqAjJt2jR98cUXmjJlijw8PDRkyBBt3LhRffv2VVhY2AM/T0xMjA4ePKh69eolGq9Xr552796d7DqrV69WUFCQPv74YxUoUEAlSpTQoEGDdPv27Ud6TwCA9MsYo88//1wVK1bUiRMnVKBAAW3dulXlypWzOhoApFtOtQvW2bNn7TMO3t7eioiIkCS1b99elSpV0pQpUx7oea5cuaL4+HjlyZMn0XiePHkUGhqa7DonT57Uzp075eXlpZUrV+rKlSvq3bu3rl27dtfjQKKjoxUdHW2/Hx4e/kD5AADWCw8PV/fu3bV06VJJUuPGjTV37lzlzJnT4mQAkL451QxI3rx57VeWLVy4sH788UdJ0qlTp2SMSfHz/fuihne70KEkJSQkyGazacGCBapQoYIaNWqk8ePHa+7cuXedBRk7dqz8/Pzst0KFCqU4IwDAGs2aNdPSpUvl5uamTz75RKtXr6Z8AMADcKoCUrt2ba1Zs0aS1LVrVw0YMEB169ZVq1at1Lx58wd+npw5c8rV1TXJbMfly5eTzIrckS9fPhUoUCDRlW1LlSolY4zOnz+f7DrDhg1TWFiY/Xbu3LkHzggAsNZ7772nJ554Qjt27NCgQYPk4uJUf1IBIM041S5YX3zxhRISEiRJPXv21GOPPaadO3eqSZMm6tmz5wM/j4eHhwIDA7Vx48ZExWXjxo1q1qxZsutUrVpV33zzjW7evKmsWbNKkk6cOCEXFxcVLFgw2XU8PT0TXbUdAJB+3bhxQ4cOHVLt2rUlSc8//7yOHz8ud3d3i5MBQMbiVF/XuLi4yM3t/3eqli1bavLkyerbt6/++uuvFD3XwIEDNWvWLH355Zc6fvy4BgwYoLNnz9qLzLBhw9ShQwf78m3btlWOHDnUuXNnhYSEaPv27Ro8eLC6dOmS6MrsAICMZ9++fQoICFCTJk10/Phx+zjlAwBSzqkKSHJCQ0P15ptvqnjx4ilar1WrVpo4caLGjBmjsmXLavv27Vq7dq0KFy4sSbp06ZLOnj1rXz5r1qzauHGjbty4oaCgILVr105NmjTR5MmTU/X9AAAcxxij8ePHq2rVqjp9+rTy5MmjqKgoq2MBQIZmMw9zdHY6c+PGDfXp00cbNmyQu7u7hg4dqjfeeEOjRo3Sp59+qqeffloDBw5UmzZtrI56T+Hh4fLz81NYWJh8fX3T9LUiY+JUesR6SVLImPrK4uFUe+MBwCO7du2aOnXqZD+2sEWLFpo1a1aiY/0AZD6O/LzmrJziU+c777yj7du3q2PHjlq3bp0GDBigdevWKSoqSt9//71q1KhhdUQAQAaye/dutW7dWufOnZOHh4cmTJigXr163fVMiACAB+cUBeS7777TnDlzVKdOHfXu3VvFixdXiRIlNHHiRKujAQAyoLVr1+rcuXMqXry4li5dqoCAAKsjAYDTcIoCcvHiRZUuXVqSVKxYMXl5ealbt24WpwIAZFSjRo2Sl5eX+vXrp2zZslkdBwCcilMchJ6QkJDoTCSurq7y8fGxMBEAICPZvn27XnrpJUVHR0uS3Nzc9J///IfyAQBpwClmQIwx6tSpk/2aGlFRUerZs2eSErJixQor4gEA0qn4+HiNHTtWI0eOVEJCgj799FMNHz7c6lgA4NScooB07Ngx0f3XXnvNoiQAgIzizz//1GuvvaZNmzZJkjp06KB+/fpZnAoAnJ9TFJA5c+ZYHQEAkIFs3rxZbdu21Z9//qksWbJo6tSp6tSpk9WxACBTcIoCAgDAg5o9e7a6d+8uY4yefvppLV261H4iEwBA2nOKg9ABAHhQtWrVUrZs2dS1a1ft27eP8gEADsYMCADA6Z08eVLFihWT9Pfp2o8dO6ZChQpZnAoAMidmQAAATisuLk7vvPOOSpQooY0bN9rHKR8AYB0KCADAKZ0/f161atXS2LFjFR8fry1btlgdCQAgJywg8+fPV9WqVZU/f36dOXNGkjRx4kT973//szgZAMBR1q5dq7Jly2rnzp3Kli2bFi9erA8//NDqWAAAOVkBmT59ugYOHKhGjRrpxo0bio+PlyT5+/tr4sSJ1oYDAKS52NhYDRkyRI0bN9bVq1dVrlw5HTp0SK1atbI6GgDg/zhVAfnss880c+ZMDR8+XK6urvbxoKAgHT161MJkAABHWLt2rT755BNJ0ptvvqndu3erePHiFqcCAPyTU50F69SpUwoICEgy7unpqVu3blmQCADgSM2aNdObb76pmjVr6uWXX7Y6DgAgGU41A1K0aFEFBwcnGf/+++85zzsAOKGYmBiNHDlSV65csY9NnjyZ8gEA6ZhTzYAMHjxYffr0UVRUlIwx2rdvnxYtWqSxY8dq1qxZVscDAKSikydPqlWrVjpw4IAOHTqk1atXy2azWR0LAHAfTlVAOnfurLi4OA0ZMkSRkZFq27atChQooEmTJql169ZWxwMApJJly5apa9euCg8PV/bs2fX6669TPgAgg3CqAiJJ3bt3V/fu3XXlyhUlJCQod+7cVkcCAKSSqKgovfXWW5o2bZokqUqVKlq0aJEef/xxi5MBAB6UUx0DMnr0aP3xxx+SpJw5c1I+AMCJnD17VlWqVLGXj7fffltbt26lfABABuNUBWT58uUqUaKEKlWqpClTpuivv/6yOhIAIJX4+vrqxo0bypkzp9auXauPPvpI7u7uVscCAKSQUxWQI0eO6MiRI6pdu7bGjx+vAgUKqFGjRlq4cKEiIyOtjgcASKHo6GgZYyT9fVHZVatWKTg4WA0bNrQ4GQDgYTlVAZGkp59+Wh9++KFOnjypLVu2qGjRourfv7/y5s1rdTQAQAr88ssvKl++vGbMmGEfK1OmjAoUKGBhKgDAo3K6AvJPPj4+8vb2loeHh2JjY62OAwB4QPPnz1dQUJCOHj2qjz76SFFRUVZHAgCkEqcrIKdOndIHH3yg0qVLKygoSIcOHdKoUaMUGhpqdTQAwH3cunVLXbp0UYcOHXTr1i3VqlVLP/74o7y8vKyOBgBIJU51Gt7KlStr3759evbZZ9W5c2f7dUAAAOnfzz//rJYtWyokJEQuLi4aOXKkhg8fLldXV6ujAQBSkVMVkFq1amnWrFl6+umnrY4CAEiBq1evqnLlyoqIiFDevHm1aNEi1axZ0+pYAIA04FQF5MMPP7Q6AgDgIeTIkUNvv/22tm/frvnz53MdJwBwYhm+gAwcOFDvvfeefHx8NHDgwHsuO378eAelAgDcz08//SQvLy899dRTkqRhw4Zp2LBhcnFxusMTAQD/kOELyOHDh+1nuDp8+LDFaQAA92OM0RdffKF+/fqpRIkS2rt3r7y9vSkeAJBJZPgCsmXLlmT/GwCQ/oSHh+v111/XkiVLJEmFChVSVFSUvL29LU4GAHAUp/q6qUuXLoqIiEgyfue0jgAA6xw6dEjlypXTkiVL5Obmpo8//lhr1qxR9uzZrY4GAHAgpyogX331lW7fvp1k/Pbt25o3b54FiQAAxhhNmTJFlStX1h9//KHHH39c27dv1+DBg9ntCgAyoQy/C5b095S+MUbGGEVERCS6YFV8fLzWrl3LGVUAwCLx8fFavHixYmJi1LRpU82ZM0ePPfaY1bEAABZxigLi7+8vm80mm82mEiVKJHncZrNp9OjRFiQDALi5uWnRokX63//+pz59+shms1kdCQBgIacoIFu2bJExRrVr19by5csTfbPm4eGhwoULK3/+/BYmBIDMwxijSZMm6dKlS/rvf/8r6e+Dzd944w2LkwEA0gOnKCA1atSQJJ06dUqPP/44364BgEWuXbumzp07a/Xq1ZKkl19+WRUrVrQ4FQAgPcnwBeTIkSN65pln5OLiorCwMB09evSuy5YpU8aByQAgc9m9e7dat26tc+fOycPDQxMmTFCFChWsjgUASGcyfAEpW7asQkNDlTt3bpUtW1Y2m03GmCTL2Ww2xcfHW5AQAJxbQkKCPv30U73zzjuKj49X8eLFtXTpUgUEBFgdDQCQDmX4AnLq1CnlypXL/t8AAMdq166dFi9eLElq3bq1Pv/8c/n6+lqcCgCQXmX4AlK4cOFk/xsA4BjNmzfXqlWrNHnyZHXr1o3j8AAA9+RUV4D66quv9N1339nvDxkyRP7+/qpSpYrOnDljYTIAcB4JCQn6448/7Pdbtmyp33//Xd27d6d8AADuy6kKyIcffihvb29J0p49ezRlyhR9/PHHypkzpwYMGGBxOgDI+P788081aNBAVapUUWhoqH28QIECFqYCAGQkTlVAzp07p+LFi0uSVq1apRYtWuj111/X2LFjtWPHDovTAUDGtnnzZpUtW1YbN25URESEDh8+bHUkAEAG5FQFJGvWrLp69aokacOGDapTp44kycvLS7dv37YyGgBkWPHx8Ro1apTq1Kmj0NBQlS5dWvv371fDhg2tjgYAyIAy/EHo/1S3bl1169ZNAQEBOnHihBo3bixJ+vnnn1WkSBFrwwFABnTp0iW1a9dOW7ZskSR16dJFn332mbJkyWJxMgBARuVUMyBTp05V5cqV9ddff2n58uXKkSOHJOngwYNq06aNxekAIOP58MMPtWXLFvn4+Gj+/PmaPXs25QMA8EicagbE399fU6ZMSTI+evRoC9IAQMY3duxYhYaG6v3339dTTz1ldRwAgBNwqgIiSTdu3NDs2bN1/Phx2Ww2lSpVSl27dpWfn5/V0QAg3Tt//rw+//xzjRkzRjabTVmzZtU333xjdSwAgBNxql2wDhw4oCeeeEITJkzQtWvXdOXKFU2YMEFPPPGEDh06ZHU8AEjX1q5dq7Jly+r999/XpEmTrI4DAHBSTjUDMmDAADVt2lQzZ86Um9vfby0uLk7dunVT//79tX37dosTAkD6Exsbq+HDh+uTTz6RJJUrV04vvviixakAAM7KqQrIgQMHEpUPSXJzc9OQIUMUFBRkYTIASJ/Onj2r1q1ba8+ePZKkN954Q59++qk8PT0tTgYAcFZOtQuWr6+vzp49m2T83LlzypYtmwWJACD9Wr9+vcqWLas9e/bIz89Py5Yt02effUb5AACkKacqIK1atVLXrl21ZMkSnTt3TufPn9fixYvVrVs3TsMLAP+SPXt23bx5U+XLl9fhw4f1yiuvWB0JAJAJONUuWJ9++qlsNps6dOiguLg4SZK7u7t69eqljz76yOJ0AGC9qKgoeXl5SZIqVKigDRs2qEqVKvLw8LA4GQAgs3CqGRAPDw9NmjRJ169fV3BwsA4fPqxr165pwoQJ7FIAINNbsWKFihYtqp9++sk+VrNmTcoHAMChnKKAREZGqk+fPipQoIBy586tbt26KV++fCpTpgxX7AWQ6UVFRenNN9/UK6+8otDQUI0bN87qSACATMwpCsjIkSM1d+5cNW7cWK1bt9bGjRvVq1cvq2MBgOV+//13ValSRVOmTJEkDRkyRLNnz7Y4FQAgM3OKY0BWrFih2bNnq3Xr1pKk1157TVWrVlV8fLxcXV0tTgcA1liyZIm6d++uiIgI5ciRQ/PmzVOjRo2sjgUAyOScYgbk3Llzqlatmv1+hQoV5ObmposXL1qYCgCss3btWrVu3VoRERGqVq2agoODKR8AgHTBKWZA4uPjkxxE6ebmZj8TFgBkNvXr11fdunVVoUIFjRo1KtEFWgEAsJJT/EUyxqhTp06JznQVFRWlnj17ysfHxz62YsUKK+IBgEOsWrVK9evXl7e3t1xdXbV27VqKBwAg3XGKv0wdO3ZMMvbaa69ZkAQAHC8yMlJvvPGG5syZox49emjGjBmSRPkAAKRLTvHXac6cOVZHAABL/Pzzz2rZsqVCQkLk4uKi/Pnzyxgjm81mdTQAAJLlFAUEADIbY4zmzp2rPn366Pbt28qbN68WLVqkmjVrWh0NAIB7coqzYAFAZnLz5k117NhRXbp00e3bt1W3bl399NNPlA8AQIZAAQGADOb69ev67rvv5OLiog8++EDr1q1T7ty5rY4FAMADYRcsAMhgChUqpIULF8rb21vVq1e3Og4AACnCDAgApHPh4eFq27at1qxZYx+rX78+5QMAkCE5XQGZP3++qlatqvz58+vMmTOSpIkTJ+p///ufxckAIOUOHz6swMBALVq0SN26dVNkZKTVkQAAeCROVUCmT5+ugQMHqlGjRrpx44bi4+MlSf7+/po4caK14QAgBYwxmjp1qipVqqTff/9djz/+uFatWqUsWbJYHQ0AgEfiVAXks88+08yZMzV8+HC5urrax4OCgnT06FELkwHAg7tx44ZeffVVvfHGG4qJiVHTpk11+PBhVa5c2epoAAA8MqcqIKdOnVJAQECScU9PT926dSvFzzdt2jQVLVpUXl5eCgwM1I4dOx5ovV27dsnNzU1ly5ZN8WsCyNxu3LihcuXKafny5XJ3d9eECRO0atUqPfbYY1ZHAwAgVThVASlatKiCg4OTjH///fcqXbp0ip5ryZIl6t+/v4YPH67Dhw+rWrVqatiwoc6ePXvP9cLCwtShQwe98MILKXo9AJD+3mW0bt26KlKkiHbt2qX+/ftzVXMAgFNxqtPwDh48WH369FFUVJSMMdq3b58WLVqksWPHatasWSl6rvHjx6tr167q1q2bpL8PZF+/fr2mT5+usWPH3nW9Hj16qG3btnJ1ddWqVase5e0AyCSuXbumuLg4+7U8Jk6cqOjoaPn7+1sbDACANOBUBaRz586Ki4vTkCFDFBkZqbZt26pAgQKaNGmSWrdu/cDPExMTo4MHD2ro0KGJxuvVq6fdu3ffdb05c+bojz/+0Ndff63333//od8HgMxjz549at26tZ588kmtX79erq6u8vb2lre3t9XRAABIE05VQCSpe/fu6t69u65cuaKEhISHujrwlStXFB8frzx58iQaz5Mnj0JDQ5Nd57ffftPQoUO1Y8cOubk92I81Ojpa0dHR9vvh4eEpzgogY0pISNC4ceP0zjvvKC4uTh4eHgoNDVWBAgWsjgYAQJpyqmNA/ilnzpwPVT7+6d/7XRtjkt0XOz4+Xm3bttXo0aNVokSJB37+sWPHys/Pz34rVKjQI+UFkDFcuXJFTZo00ZAhQxQXF6fWrVvr4MGDlA8AQKbgVDMgRYsWvefBmidPnnyg58mZM6dcXV2TzHZcvnw5yayIJEVEROjAgQM6fPiw3njjDUl/f7tpjJGbm5s2bNig2rVrJ1lv2LBhGjhwoP1+eHg4JQRwcjt27FCbNm104cIFeXp6avLkyerevTsHmgMAMg2nKiD9+/dPdD82NlaHDx/WunXrNHjw4Ad+Hg8PDwUGBmrjxo1q3ry5fXzjxo1q1qxZkuV9fX2TXGdk2rRp2rx5s5YtW6aiRYsm+zqenp7y9PR84FwAMrb4+Hj17NlTFy5cUIkSJfTNN9+oTJkyVscCAMChnKqA9OvXL9nxqVOn6sCBAyl6roEDB6p9+/YKCgpS5cqV9cUXX+js2bPq2bOnpL9nLy5cuKB58+bJxcVFzzzzTKL1c+fOLS8vryTjADIvV1dXLVq0SJMmTdKkSZOUNWtWqyMBAOBwTnsMyD81bNhQy5cvT9E6rVq10sSJEzVmzBiVLVtW27dv19q1a1W4cGFJ0qVLl+57TRAA2Lp1a6LTgJcpU0azZ8+mfAAAMi2bMcZYHSKtffzxx5o2bZpOnz5tdZR7Cg8Pl5+fn8LCwuTr65umrxUZE6fSI9ZLkkLG1FcWD6eaDAMsFx8fr/fff19jxoyRq6ur9uzZo8DAQKtjAQAekSM/rzkrp/rUGRAQkOhATmOMQkND9ddff2natGkWJgOQmYSGhqpdu3bavHmzJKlTp04qVaqUxakAAEgfnKqAvPTSS4nuu7i4KFeuXKpZs6ZKlixpTSgAmcqmTZvUrl07Xb58WT4+PpoxY4Zee+01q2MBAJBuOE0BiYuLU5EiRVS/fn3lzZvX6jgAMqHRo0dr9OjRMsaoTJkyWrJkCV9+AADwL05zELqbm5t69eqV6MriAOBIWbNmlTFGPXr00I8//kj5AAAgGU4zAyJJFStW1OHDh+1nqgKAtBYZGaksWbJI+vv03eXKlVOtWrUsTgUAQPrlVAWkd+/eeuutt3T+/HkFBgbKx8cn0eNc8AtAaomNjdV//vMfrV69Wvv371fWrFlls9koHwAA3IdTFJAuXbpo4sSJatWqlSSpb9++9sdsNpuMMbLZbIqPj7cqIgAncvbsWbVp00a7d++WJK1atYoDzQEAeEBOUUC++uorffTRRzp16pTVUQA4uTVr1qhjx466fv26/Pz8NHv2bL3yyitWxwIAIMNwigJy51qKHPsBIK3ExMRo2LBhGj9+vCSpfPnyWrx4sYoVK2ZxMgAAMhanOQvWPy9ACACp7e2337aXjwEDBmjnzp2UDwAAHoJTzIBIUokSJe5bQq5du+agNACczdtvv63169fro48+UtOmTa2OAwBAhuU0BWT06NHy8/OzOgYAJxEdHa3//e9/atmypSQpb968Onr0qFxdXS1OBgBAxuY0BaR169bKnTu31TEAOIHff/9drVq10qFDhyTJXkIoHwAAPDqnOAaE4z8ApJalS5eqXLlyOnTokHLkyCFfX1+rIwEA4FScooDcOQsWADys27dvq2fPnmrVqpUiIiL0/PPPKzg4WA0aNLA6GgAATsUpdsFKSEiwOgKADOzXX39Vy5YtdeTIEdlsNr3zzjsaNWqU3Nyc4n+RAACkK/x1BZDp/frrrzpy5Ihy5cqlBQsWqG7dulZHAgDAaVFAAGR6TZs21eeff64mTZooX758VscBAMCpOcUxIACQEiEhIapZs6bOnTtnH3v99dcpHwAAOAAFBECmMnfuXJUvX17btm1Tv379rI4DAECmwy5YADKFmzdvqk+fPpo3b54kqW7dupo+fbrFqQAAyHyYAQHg9I4ePary5ctr3rx5cnFx0fvvv69169YpT548VkcDACDTYQYEgFPbsWOH6tWrp6ioKBUoUECLFi1StWrVrI4FAECmRQEB4NSCgoL05JNPqmDBgpo3b55y5sxpdSQAADI1CggAp/Prr7/qySeflIuLi7y9vfXDDz8oR44ccnFhr1MAAKzGX2MATsMYo2nTpqlMmTIaO3asfTxXrlyUDwAA0glmQAA4hbCwMHXr1k3Lli2TJB08eFAJCQkUDwAA0hn+MgPI8A4cOKCAgAAtW7ZM7u7uGj9+vJYvX075AAAgHWIGBECGZYzR5MmTNXjwYMXGxqpIkSJasmSJKlSoYHU0AABwF3w9CCDDOnnypN5++23Fxsbq5Zdf1uHDhykfAACkc8yAAMiwnnjiCU2ZMkVRUVHq06ePbDab1ZEAAMB9UEAAZBgJCQmaMGGCqlevrvLly0uSunXrZnEqAACQEhQQABnC1atX1bFjR3333XcqUqSIjh49qqxZs1odCwAApBAFBEC6t3PnTrVp00bnz5+Xp6enhg0bJh8fH6tjAQCAh8BB6ADSrYSEBI0dO1Y1a9bU+fPnVaJECe3bt0+vv/46x3sAAJBBMQMCIF26efOmWrRoofXr10uSXnvtNU2fPp3drgAAyOCYAQGQLmXJkkVubm7y9vbW7NmzNW/ePMoHAABOgBkQAOlGfHy8YmNj5eXlJRcXF3311VcKDQ3V008/bXU0AACQSpgBAZAuhIaGql69eurRo4d9LEeOHJQPAACcDAUEgOU2bdqksmXLavPmzVq+fLlOnjxpdSQAAJBGKCAALBMXF6d3331X9erV059//qlnn31WBw4cULFixayOBgAA0gjHgACwxIULF9S2bVtt375dkvT6669r4sSJ8vb2tjgZAABISxQQAA6XkJCgBg0a6NixY8qaNatmzpyp1q1bWx0LAAA4ALtgAXA4FxcXjR8/XoGBgTp06BDlAwCATIQCAsAhzp07px9++MF+v27dutq3b5+efPJJC1MBAABHo4AASHPffvutypYtq5dffll//PGHfdzFhf8FAQCQ2fDXH0CaiYmJ0VtvvaUmTZro2rVrKlGiBKUDAIBMjk8CANLE6dOnVb16dY0fP16S1L9/f+3atUtFixa1OBkAALASZ8ECkOpWrlypLl266MaNG/L399fcuXPVrFkzq2MBAIB0gAICINVt27ZNN27cUKVKlbR48WIVLlzY6kgAACCdoIAASHUff/yxihQpoj59+sjd3d3qOAAAIB3hGBAAj+ybb77Riy++qLi4OEmSh4eH+vfvT/kAAABJUEAAPLSoqCj17t1bLVu21HfffaeZM2daHQkAAKRz7IIF4KGcOHFCLVu21E8//SRJGjZsmLp3725xKgAAkN5RQACk2MKFC9WjRw/dvHlTuXLl0vz581W/fn2rYwEAgAyAXbAApMgHH3ygdu3a6ebNm6pZs6aCg4MpHwAA4IFRQACkyMsvv6xs2bJp5MiR2rRpk/Lnz291JAAAkIGwCxaA+zp69KieffZZSVKpUqV08uRJ5cyZ0+JUAAAgI2IGBMBd3bx5Ux07dlTZsmW1Y8cO+zjlAwAAPCwKCIBkHT16VOXLl9e8efMkSUeOHLE4EQAAcAYUEACJGGM0a9YsVahQQb/88ovy58+vLVu2qE+fPlZHAwAAToBjQADYRUREqEePHlq0aJEkqUGDBpo3b55y5cplcTIAAOAsmAEBYLdixQotWrRIrq6u+uijj/Tdd99RPgAAQKpiBgSAXYcOHXTo0CG1bNlSVatWtToOAABwQsyAAJlYWFiY+vbtq7CwMEmSzWbTpEmTKB8AACDNMAMCZFIHDhxQq1atdPLkSV25ckULFy60OhIAAMgEmAEBMhljjCZNmqQqVaro5MmTKlKkiPr37291LAAAkEkwAwJkItevX1eXLl20atUqSVLz5s315Zdfyt/f39JcAAAg86CAAJnE0aNH1aRJE505c0YeHh4aN26c+vTpI5vNZnU0AACQiVBAgEwiX758iouL0xNPPKElS5YoMDDQ6kgAACATooAATuzmzZvKmjWrJClnzpz6/vvv9fjjj8vPz8/iZAAAILPiIHTASe3cuVOlSpXSV199ZR979tlnKR8AAMBSFBDAySQkJOijjz5SzZo1df78eU2aNEkJCQlWxwIAAJBEAbmnadOmqWjRovLy8lJgYKB27Nhx12VXrFihunXrKleuXPL19VXlypW1fv16B6YFpMuXL6tRo0YaNmyY4uPj1a5dO23btk0uLvyqAwCA9IFPJXexZMkS9e/fX8OHD9fhw4dVrVo1NWzYUGfPnk12+e3bt6tu3bpau3atDh48qFq1aqlJkyY6fPiwg5Mjs9q2bZvKli2r9evXy9vbW7NmzdL8+fOVLVs2q6MBAADY2YwxxuoQ6VHFihVVrlw5TZ8+3T5WqlQpvfTSSxo7duwDPcfTTz+tVq1aacSIEQ+0fHh4uPz8/BQWFiZfX9+Hyv2gImPiVHrE3zM0IWPqK4sH5yPIyM6cOaPixYsrLi5OpUqV0tKlS/XMM89YHQsAAKfjyM9rzooZkGTExMTo4MGDqlevXqLxevXqaffu3Q/0HAkJCYqIiNBjjz2WFhGBRAoXLqwhQ4aoU6dO2r9/P+UDAACkW3ztnYwrV64oPj5eefLkSTSeJ08ehYaGPtBzjBs3Trdu3VLLli3vukx0dLSio6Pt98PDwx8uMDKlH374QUWLFlWxYsUkSe+99x7HegAAgHSPTyv38O8rRBtjHuiq0YsWLdKoUaO0ZMkS5c6d+67LjR07Vn5+fvZboUKFHjkznF9cXJxGjBihunXrqlWrVoqJiZEkygcAAMgQ+MSSjJw5c8rV1TXJbMfly5eTzIr825IlS9S1a1ctXbpUderUueeyw4YNU1hYmP127ty5R84O53bhwgW98MILeu+992SMUUBAgOLj462OBQAA8MAoIMnw8PBQYGCgNm7cmGh848aNqlKlyl3XW7RokTp16qSFCxeqcePG930dT09P+fr6JroBd7Nu3TqVLVtW27dvV9asWbVw4UJ98cUX8vb2tjoaAADAA+MYkLsYOHCg2rdvr6CgIFWuXFlffPGFzp49q549e0r6e/biwoULmjdvnqS/y0eHDh00adIkVapUyT574u3tzZWn8UhiY2M1YsQIffTRR5KksmXLasmSJSpRooTFyQAAAFKOGZC7aNWqlSZOnKgxY8bYv3Veu3atChcuLEm6dOlSomuCfP7554qLi1OfPn2UL18++61fv35WvQU4iYSEBPtsXO/evbVnzx7KBwAAyLC4Dkg6wnVA8E//POnByZMndejQIbVo0cLiVAAAZG5cB+TR8akTSGdiYmI0bNgwZcmSRe+9954kqVixYvbT7QIAAGRkFBAgHTl9+rRat26tvXv3ymaz6bXXXtNTTz1ldSwAAIBUwzEgQDqxatUqBQQEaO/evfL399eKFSsoHwAAwOlQQACLRUdHq1+/fmrevLlu3LihihUr6vDhw3rppZesjgYAAJDq2AULsJAxRvXr19e2bdskSYMGDdKHH34od3d3i5MBAACkDQoIYCGbzabOnTvr2LFj+uqrrx7oApYAAAAZGbtgAQ4WFRWlX3/91X6/Y8eO+vXXXykfAAAgU6CAAA504sQJVapUSXXq1NHVq1ft4zly5LAwFQAAgONQQAAHWbBggcqVK6effvpJ0dHR+uOPP6yOBAAA4HAUECCNRUZGqlu3bnrttdd069Yt1ahRQ8HBwapQoYLV0QAAAByOAgKkoePHj6tixYqaPXu2bDabRowYoU2bNil//vxWRwMAALAEZ8EC0tCHH36oY8eOKU+ePFqwYIFeeOEFqyMBAABYigICpKEpU6bIzc1NY8eOVd68ea2OAwAAYDl2wQJS0bFjx/T222/LGCNJ8vPz05w5cygfAAAA/4cZECAVGGM0e/Zsvfnmm4qKilKJEiXUtWtXq2MBAACkOxQQ4BFFRESoZ8+eWrhwoSSpQYMGatq0qcWpAAAA0id2wQIeQXBwsAIDA7Vw4UK5urrqo48+0nfffadcuXJZHQ0AACBdYgYEeEjz589X9+7dFR0drYIFC2rx4sWqWrWq1bEAAADSNWZAgIdUuHBhxcbG6sUXX1RwcDDlAwAA4AEwAwKkQHh4uHx9fSVJ1atX1+7du1WhQgXZbDaLkwEAAGQMzIAAD8AYo8mTJ6tIkSL65Zdf7OMVK1akfAAAAKQABQS4j+vXr+uVV15Rv379dP36dX355ZdWRwIAAMiw2AULuIe9e/eqVatWOnPmjNzd3fXpp5/qzTfftDoWAABAhsUMCJAMY4zGjRun559/XmfOnFGxYsW0e/du9e3bl12uAAAAHgEFBEjGvHnzNGjQIMXFxenVV1/VoUOHFBQUZHUsAACADI8CAiSjXbt2euGFFzRt2jQtWbJEfn5+VkcCAABwChwDAkhKSEjQ3Llz9dprr8nDw0Nubm7auHEju1sBAACkMmZAkOn99ddfaty4sbp27aqhQ4faxykfAAAAqY8ZEGRq27ZtU9u2bXXx4kV5eXmpdOnSVkcCAABwasyAIFOKj4/Xe++9p9q1a+vixYsqWbKk9u/fr27dulkdDQAAwKkxA4JM588//1S7du30ww8/SJI6duyoqVOnysfHx+JkAAAAzo8CgkwnIiJC+/btU5YsWTRt2jR17NjR6kgAAACZBgUEmYIxxn5QefHixbVkyRIVLlyYYz4AAAAcjGNA4PQuXryoOnXqaNOmTfaxhg0bUj4AAAAswAwInNr69evVvn17/fXXXzpz5ox++eUXubnxzx4AAMAqzIDAKcXFxWnYsGFq0KCB/vrrLz333HNau3Yt5QMAAMBifBqD0zl37pzatGmjXbt2SZJ69eql8ePHy8vLy+JkAAAAoIDAqVy4cEFly5bVtWvX5Ovrq5kzZ6ply5ZWxwIAAMD/oYDAqeTPn1+NGzdWSEiIlixZoieeeMLqSAAAAPgHCggyvNOnTytbtmzKkSOHbDabpk+fLjc3N3l6elodDQAAAP/CQejI0FatWqWAgAB17txZxhhJko+PD+UDAAAgnaKAIEOKjo5Wv3791Lx5c924cUN//vmnbty4YXUsAAAA3AcFBBnOH3/8oapVq2ry5MmSpLfeeks7duxQ9uzZLU4GAACA++EYEGQo33zzjbp166bw8HA99thjmjt3rpo0aWJ1LAAAADwgCggyjKioKA0ZMkTh4eGqUqWKFi9erEKFClkdCwAAAClAAUGG4eXlpSVLlmjlypUaM2aM3N3drY4EAACAFKKAIF1btGiRoqKi1LlzZ0lShQoVVKFCBYtTAQAA4GFRQJAu3b59W/369dPMmTPl6empypUrq2TJklbHAgAAwCOigCDd+eWXX/Tqq6/q2LFjstlsGjx4sIoXL251LAAAAKQCCgjSlXnz5qlXr16KjIxUnjx59PXXX6tOnTpWxwIAAEAqoYAgXTDG6PXXX9esWbMkSbVr19aCBQuUN29ei5MBAAAgNXEhQqQLNptNhQsXlouLi8aMGaMNGzZQPgAAAJwQMyCwjDFG4eHh8vPzkyQNGzZMDRs2VGBgoMXJAAAAkFaYAYElIiIi1L59e1WvXl23b9+WJLm6ulI+AAAAnBwFBA73008/KSgoSAsWLNDPP/+sbdu2WR0JAAAADkIBgcMYYzRjxgxVrFhRJ06cUMGCBbV161Y1aNDA6mgAAABwEI4BgUOEhYXp9ddf19KlSyVJjRs31ty5c5UzZ06LkwEAAMCRmAGBQ/Tu3VtLly6Vm5ubPvnkE61evZryAQAAkAkxAwKHGDt2rH755RdNnTpVlSpVsjoOAAAALMIMCNLEjRs3NH/+fPv9xx9/XAcOHKB8AAAAZHLMgCDV7du3T61atdLp06fl7++vJk2aSPr7YoMAAADI3JgBQaoxxmj8+PGqWrWqTp8+rWLFiilfvnxWxwIAAEA6wgwIUsXVq1fVqVMnffvtt5KkFi1aaNasWfarnAMAAAASMyBIBbt371ZAQIC+/fZbeXp6atq0aVq6dCnlAwAAAEkwA4JHdvbsWZ07d05PPvmkli5dqrJly1odCQAAAOkUBQQPxRhjP6i8devWun37tlq0aKFs2bJZnAwAAADpGQUEKbZ9+3YNHDhQ3377rfLmzStJ6ty5s8WpAMD5xcfHKzY21uoYgFNzd3eXq6ur1TGcGgUEDyw+Pl5jx47VyJEjlZCQoBEjRuiLL76wOhYAOD1jjEJDQ3Xjxg2rowCZgr+/v/LmzcslBNIIBQQP5M8//9Rrr72mTZs2SZI6dOig8ePHW5wKADKHO+Ujd+7cypIlCx+KgDRijFFkZKQuX74sSVxOII1QQHBfmzdvVrt27RQaGqosWbJo6tSp6tSpk9WxACBTiI+Pt5ePHDlyWB0HcHre3t6SpMuXLyt37tzsjpUGKCC4p5UrV+qVV16RMUZPP/20li5dqtKlS1sdCwAyjTvHfGTJksXiJEDmcef3LTY2lgKSBigguKc6deroySefVPXq1TVp0iT+AAKARdjtCnAcft/SFgUESRw4cECBgYGy2WzKli2b9u7dK39/f6tjAQAAwAlwJfR7mDZtmooWLSovLy8FBgZqx44d91x+27ZtCgwMlJeXl4oVK6YZM2Y4KGnqiIuL0/Dhw1WhQgVNnDjRPk75AADAsa5evarcuXPr9OnTVkdxOlOmTFHTpk2tjpGpUUDuYsmSJerfv7+GDx+uw4cPq1q1amrYsKHOnj2b7PKnTp1So0aNVK1aNR0+fFjvvPOO+vbtq+XLlzs4+cM5f/68atWqpQ8//FDGGJ06dcrqSACADK5Tp06y2Wyy2Wxyc3PT448/rl69eun69etJlt29e7caNWqk7Nmzy8vLS88++6zGjRun+Pj4JMtu2bJFjRo1Uo4cOZQlSxaVLl1ab731li5cuOCIt+UQY8eOVZMmTVSkSBGro6SZh/ni9ocfflCVKlWULVs25cuXT2+//bbi4uISLbN+/XpVqlRJ2bJlU65cufTKK68k+lzTvXt37d+/Xzt37kz194QHQwG5i/Hjx6tr167q1q2bSpUqpYkTJ6pQoUKaPn16ssvPmDFDjz/+uCZOnKhSpUqpW7du6tKliz799FMHJ0+5dd9/r7Jly2rnzp3Kli2blixZosmTJ1sdCwDgBBo0aKBLly7p9OnTmjVrltasWaPevXsnWmblypWqUaOGChYsqC1btuiXX35Rv3799MEHH6h169YyxtiX/fzzz1WnTh3lzZtXy5cvV0hIiGbMmKGwsDCNGzfOYe8rJiYmzZ779u3bmj17trp16/ZIz5OWGR/Vw3xxe+TIETVq1EgNGjTQ4cOHtXjxYq1evVpDhw61L3Py5Ek1a9ZMtWvXVnBwsNavX68rV67o5Zdfti/j6emptm3b6rPPPkvT94h7MEgiOjrauLq6mhUrViQa79u3r6levXqy61SrVs307ds30diKFSuMm5ubiYmJeaDXDQsLM5JMWFjYwwVPgVvRsebxQauMb4WXjSQjyZQrV8789ttvaf7aAIAHd/v2bRMSEmJu375tdZQU69ixo2nWrFmisYEDB5rHHnvMfv/mzZsmR44c5uWXX06y/urVq40ks3jxYmOMMefOnTMeHh6mf//+yb7e9evX75rl+vXrpnv37iZ37tzG09PTPP3002bNmjXGGGNGjhxpnnvuuUTLT5gwwRQuXDjJe/nwww9Nvnz5TOHChc3QoUNNxYoVk7zWs88+a0aMGGG//+WXX5qSJUsaT09P89RTT5mpU6feNacxxixfvtzkzJkz0VhcXJzp0qWLKVKkiPHy8jIlSpQwEydOTLRMchmNMeb8+fOmZcuWxt/f3zz22GOmadOm5tSpU/b19u3bZ+rUqWNy5MhhfH19TfXq1c3BgwfvmfFRDRkyxJQsWTLRWI8ePUylSpXuus6wYcNMUFBQorGVK1caLy8vEx4ebowx5ptvvjFubm4mPj7evszq1auNzWZL9Hls69atxsPDw0RGRib7Wvf6vXPk5zVnxQxIMq5cuaL4+HjlyZMn0XiePHkUGhqa7DqhoaHJLh8XF6crV64ku050dLTCw8MT3Rwp9spZhR/4nyTpzTff1O7du1W8eHGHZgAApJwxRpExcZbczD9mI1Lq5MmTWrdundzd3e1jGzZs0NWrVzVo0KAkyzdp0kQlSpTQokWLJEnffPONYmJiNGTIkGSf/27HLCYkJKhhw4bavXu3vv76a4WEhOijjz5K8elVf/jhBx0/flwbN27Ut99+q3bt2mnv3r36448/7Mv8/PPPOnr0qNq1aydJmjlzpoYPH64PPvhAx48f14cffqh3331XX3311V1fZ/v27QoKCkryHgoWLKilS5cqJCREI0aM0DvvvKOlS5feM2NkZKRq1aqlrFmzavv27dq5c6eyZs2qBg0a2GdIIiIi1LFjR+3YsUM//vijnnzySTVq1EgRERF3zbhgwQJlzZr1nrcFCxbcdf09e/aoXr16icbq16+vAwcO2E89/W/R0dHy8vJKNObt7a2oqCgdPHhQkhQUFCRXV1fNmTNH8fHxCgsL0/z581WvXr1E/+6CgoIUGxurffv23TUj0g5nwbqHf5+CzRhzz9OyJbd8cuN3jB07VqNHj37ElA/PI08xPVanh6Z0rak2LV+1LAcAIGVux8ar9Ij1lrx2yJj6yuLx4B8fvv32W2XNmlXx8fGKioqS9PduznecOHFCklSqVKlk1y9ZsqR9md9++02+vr4pvjr1pk2btG/fPh0/flwlSpSQJBUrVixFzyFJPj4+mjVrljw8POxjZcqU0cKFC/Xuu+9K+vuDefny5e2v895772ncuHH2XYCKFi2qkJAQff755+rYsWOyr3P69Gnlz58/0Zi7u3uizwxFixbV7t27tXTpUrVs2fKuGb/88ku5uLho1qxZ9s8jc+bMkb+/v7Zu3ap69eqpdu3aiV7r888/V/bs2bVt2za9+OKLyWZs2rSpKlaseM+f17+/mP2n+31xm9w2rl+/viZOnKhFixapZcuWCg0N1fvvvy9JunTpkiSpSJEi2rBhg1599VX16NFD8fHxqly5stauXZvouXx8fOTv76/Tp0+rRo0a93wfSH3MgCQjZ86ccnV1TTLbcfny5bv+MuXNmzfZ5d3c3O565dphw4YpLCzMfjt37lzqvIEH4O3uqpAx9XVuzSS1frWFw14XAJC51KpVS8HBwdq7d6/efPNN1a9fX2+++WaS5e42s/LPL//u90Xg3QQHB6tgwYL2UvCwnn322UTlQ5LatWtn/6bfGKNFixbZZz/++usvnTt3Tl27dk00M/D+++8nmjX5t9u3byf5pl/6+3jToKAg5cqVS1mzZtXMmTOTnBzn3xkPHjyo33//XdmyZbO//mOPPaaoqCh7hsuXL6tnz54qUaKE/Pz85Ofnp5s3b971xDuSlC1bNhUvXvyet2zZst3z55nSL27r1aunTz75RD179pSnp6dKlCihxo0bS5J9Nis0NFTdunVTx44dtX//fm3btk0eHh5q0aJFkn9j3t7eioyMvGdGpA1mQJLh4eGhwMBAbdy4Uc2bN7ePb9y4Uc2aNUt2ncqVK2vNmjWJxjZs2KCgoKBEU37/5OnpKU9Pz9QLngI2my1F32ABANKPO18iWfXaKeHj42PfvXfy5MmqVauWRo8erffee0+S7KXg+PHjqlKlSpL1f/nlF5UuXdq+bFhYmC5dupSiWRBvb+97Pu7i4pLkw2lyuwH5+PgkGWvbtq2GDh2qQ4cO6fbt2zp37pxat24t6e/dpqS/d8P692zBvXb/ypkzZ5IzhS1dulQDBgzQuHHjVLlyZWXLlk2ffPKJ9u7de8+MCQkJCgwMTHZ3qFy5ckn6+2xlf/31lyZOnKjChQvL09NTlStXvudB7AsWLFCPHj3u+rj090zKnTL2bw/zxa0kDRw4UAMGDNClS5eUPXt2nT59WsOGDVPRokUlSVOnTpWvr68+/vhj+zpff/21ChUqpL1796pSpUr28WvXrtl/BnAsPoHexcCBA9W+fXsFBQWpcuXK+uKLL3T27Fn17NlT0t+zFxcuXNC8efMkST179tSUKVM0cOBAde/eXXv27NHs2bPt+60CAJBaMvKXSCNHjlTDhg3Vq1cv5c+fX/Xq1dNjjz2mcePGJSkgq1ev1m+//WYvKy1atNDQoUP18ccfa8KECUme+8aNG8keB1KmTBmdP39eJ06cSHYWJFeuXAoNDU00wxIcHPxA76dgwYKqXr26FixYoNu3b6tOnTr2vSXy5MmjAgUK6OTJk3f9IJ6cgIAAff3114nGduzYoSpVqiQ6g9i9ZlHuKFeunJYsWaLcuXPL19c32WV27NihadOmqVGjRpKkc+fO3fX41TsedResh/ni9g6bzWbfRW3RokUqVKiQypUrJ0mKjIxMUu7u3L9TCKW/f3ZRUVEKCAi452shjVhz7HvGMHXqVFO4cGHj4eFhypUrZ7Zt22Z/rGPHjqZGjRqJlt+6dasJCAgwHh4epkiRImb69Okpej3OqgAA+DdnOwuWMcYEBgaaPn362O9/8803xtXV1XTv3t389NNP5tSpU2bWrFkme/bspkWLFiYhIcG+7NSpU43NZjNdunQxW7duNadPnzY7d+40r7/+uhk4cOBds9SsWdM888wzZsOGDebkyZNm7dq15vvvvzfGGBMSEmJsNpv56KOPzO+//26mTJlismfPnuxZsJLzxRdfmPz585ucOXOa+fPnJ3ps5syZxtvb20ycONH8+uuv5siRI+bLL78048aNu2vWI0eOGDc3N3Pt2jX72MSJE42vr69Zt26d+fXXX81//vMf4+vrm+jsXcllvHXrlnnyySdNzZo1zfbt283JkyfN1q1bTd++fc25c+eMMcaULVvW1K1b14SEhJgff/zRVKtWzXh7e5sJEybcNeOjOnnypMmSJYsZMGCACQkJMbNnzzbu7u5m2bJl9mVWrFhhnnrqqUTrffzxx+bIkSPm2LFjZsyYMcbd3d2sXLnS/vgPP/xgbDabGT16tDlx4oQ5ePCgqV+/vilcuHCiM17NmTPHFCtW7K75OAtW2qKApCP8gwYA/JszFpAFCxYYDw8Pc/bsWfvY9u3bTYMGDYyfn5/x8PAwpUuXNp9++qmJi4tLsv7GjRtN/fr1Tfbs2Y2Xl5cpWbKkGTRokLl48eJds1y9etV07tzZ5MiRw3h5eZlnnnnGfPvtt/bHp0+fbgoVKmR8fHxMhw4dzAcffPDABeT69evG09PTZMmSxURERCT7fsuWLWs8PDxM9uzZTfXq1ZOc6v/fKlWqZGbMmGG/HxUVZTp16mT8/PyMv7+/6dWrlxk6dOh9C4gxxly6dMl06NDB5MyZ03h6eppixYqZ7t272z9vHDp0yAQFBRlPT0/z5JNPmm+++cYULlw4TQuIMff/4nbOnDnm39+V16pVy/j5+RkvLy9TsWJFs3bt2iTPu2jRIhMQEGB8fHxMrly5TNOmTc3x48cTLVOvXj0zduzYu2ajgKQtmzGPcD49pKrw8HD5+fkpLCzsrtOkAIDMJSoqSqdOnVLRokWTPTAZzmnt2rUaNGiQjh07JhcXzhmUmo4dO6YXXnhBJ06ckJ+fX7LL3Ov3js9rjy5j7kAKAADgxBo1aqTffvtNFy5cUKFChayO41QuXryoefPm3bV8IO1RQAAAANKhfv36WR3BKf37AohwPOb0AAAAADgMBQQAAACAw1BAAADIADhnDOA4/L6lLQoIAADp2J2LskVGRlqcBMg87vy+3e+iiHg4HIQOAEA65urqKn9/f12+fFmSlCVLFvvVugGkLmOMIiMjdfnyZfn7+ye5qjpSBwUEAIB0Lm/evJJkLyEA0pa/v7/99w6pjwICAEA6Z7PZlC9fPuXOnVuxsbFWxwGcmru7OzMfaYwCAgBABuHq6soHIwAZHgehAwAAAHAYCggAAAAAh6GAAAAAAHAYjgFJR+5c9CY8PNziJAAAAEjOnc9pXKzw4VFA0pGIiAhJUqFChSxOAgAAgHuJiIiQn5+f1TEyJJuhvqUbCQkJunjxorJly+aQi0yFh4erUKFCOnfunHx9fdP89ZD62IYZH9swY2P7ZXxsw4zP0dvQGKOIiAjlz59fLi4czfAwmAFJR1xcXFSwYEGHv66vry//083g2IYZH9swY2P7ZXxsw4zPkduQmY9HQ20DAAAA4DAUEAAAAAAOQwHJxDw9PTVy5Eh5enpaHQUPiW2Y8bENMza2X8bHNsz42IYZDwehAwAAAHAYZkAAAAAAOAwFBAAAAIDDUEAAAAAAOAwFBAAAAIDDUECc3LRp01S0aFF5eXkpMDBQO3bsuOfy27ZtU2BgoLy8vFSsWDHNmDHDQUlxNynZhitWrFDdunWVK1cu+fr6qnLlylq/fr0D0+LfUvo7eMeuXbvk5uamsmXLpm1A3FdKt2F0dLSGDx+uwoULy9PTU0888YS+/PJLB6VFclK6DRcsWKDnnntOWbJkUb58+dS5c2ddvXrVQWnxT9u3b1eTJk2UP39+2Ww2rVq16r7r8FkmAzBwWosXLzbu7u5m5syZJiQkxPTr18/4+PiYM2fOJLv8yZMnTZYsWUy/fv1MSEiImTlzpnF3dzfLli1zcHLckdJt2K9fP/Pf//7X7Nu3z5w4ccIMGzbMuLu7m0OHDjk4OYxJ+fa748aNG6ZYsWKmXr165rnnnnNMWCTrYbZh06ZNTcWKFc3GjRvNqVOnzN69e82uXbscmBr/lNJtuGPHDuPi4mImTZpkTp48aXbs2GGefvpp89JLLzk4OYwxZu3atWb48OFm+fLlRpJZuXLlPZfns0zGQAFxYhUqVDA9e/ZMNFayZEkzdOjQZJcfMmSIKVmyZKKxHj16mEqVKqVZRtxbSrdhckqXLm1Gjx6d2tHwAB52+7Vq1cr85z//MSNHjqSAWCyl2/D77783fn5+5urVq46IhweQ0m34ySefmGLFiiUamzx5silYsGCaZcSDeZACwmeZjIFdsJxUTEyMDh48qHr16iUar1evnnbv3p3sOnv27EmyfP369XXgwAHFxsamWVYk72G24b8lJCQoIiJCjz32WFpExD087PabM2eO/vjjD40cOTKtI+I+HmYbrl69WkFBQfr4449VoEABlShRQoMGDdLt27cdERn/8jDbsEqVKjp//rzWrl0rY4z+/PNPLVu2TI0bN3ZEZDwiPstkDG5WB0DauHLliuLj45UnT55E43ny5FFoaGiy64SGhia7fFxcnK5cuaJ8+fKlWV4k9TDb8N/GjRunW7duqWXLlmkREffwMNvvt99+09ChQ7Vjxw65ufG/Z6s9zDY8efKkdu7cKS8vL61cuVJXrlxR7969de3aNY4DscDDbMMqVapowYIFatWqlaKiohQXF6emTZvqs88+c0RkPCI+y2QMzIA4OZvNlui+MSbJ2P2WT24cjpPSbXjHokWLNGrUKC1ZskS5c+dOq3i4jwfdfvHx8Wrbtq1Gjx6tEiVKOCoeHkBKfgcTEhJks9m0YMECVahQQY0aNdL48eM1d+5cZkEslJJtGBISor59+2rEiBE6ePCg1q1bp1OnTqlnz56OiIpUwGeZ9I+v2JxUzpw55erqmuQbnsuXLyf5ZuCOvHnzJru8m5ubcuTIkWZZkbyH2YZ3LFmyRF27dtU333yjOnXqpGVM3EVKt19ERIQOHDigw4cP64033pD094dZY4zc3Ny0YcMG1a5d2yHZ8beH+R3Mly+fChQoID8/P/tYqVKlZIzR+fPn9eSTT6ZpZiT2MNtw7Nixqlq1qgYPHixJKlOmjHx8fFStWjW9//77fIOezvFZJmNgBsRJeXh4KDAwUBs3bkw0vnHjRlWpUiXZdSpXrpxk+Q0bNigoKEju7u5plhXJe5htKP0989GpUyctXLiQfZYtlNLt5+vrq6NHjyo4ONh+69mzp5566ikFBwerYsWKjoqO//Mwv4NVq1bVxYsXdfPmTfvYiRMn5OLiooIFC6ZpXiT1MNswMjJSLi6JPx65urpK+v/fpCP94rNMBmHRwe9wgDunHpw9e7YJCQkx/fv3Nz4+Pub06dPGGGOGDh1q2rdvb1/+zqnrBgwYYEJCQszs2bM5dZ3FUroNFy5caNzc3MzUqVPNpUuX7LcbN25Y9RYytZRuv3/jLFjWS+k2jIiIMAULFjQtWrQwP//8s9m2bZt58sknTbdu3ax6C5leSrfhnDlzjJubm5k2bZr5448/zM6dO01QUJCpUKGCVW8hU4uIiDCHDx82hw8fNpLM+PHjzeHDh+2nUeazTMZEAXFyU6dONYULFzYeHh6mXLlyZtu2bfbHOnbsaGrUqJFo+a1bt5qAgADj4eFhihQpYqZPn+7gxPi3lGzDGjVqGElJbh07dnR8cBhjUv47+E8UkPQhpdvw+PHjpk6dOsbb29sULFjQDBw40ERGRjo4Nf4ppdtw8uTJpnTp0sbb29vky5fPtGvXzpw/f97BqWGMMVu2bLnn3zU+y2RMNmOYTwQAAADgGBwDAgAAAMBhKCAAAAAAHIYCAgAAAMBhKCAAAAAAHIYCAgAAAMBhKCAAAAAAHIYCAgAAAMBhKCAAkI7NnTtX/v7+Vsd4aEWKFNHEiRPvucyoUaNUtmxZh+QBAFiPAgIAaaxTp06y2WxJbr///rvV0TR37txEmfLly6eWLVvq1KlTqfL8+/fv1+uvv26/b7PZtGrVqkTLDBo0SD/88EOqvN7d/Pt95smTR02aNNHPP/+c4ufJyIUQANIDCggAOECDBg106dKlRLeiRYtaHUuS5Ovrq0uXLunixYtauHChgoOD1bRpU8XHxz/yc+fKlUtZsmS55zJZs2ZVjhw5Hvm17uef7/O7777TrVu31LhxY8XExKT5awMA/j8KCAA4gKenp/LmzZvo5urqqvHjx+vZZ5+Vj4+PChUqpN69e+vmzZt3fZ6ffvpJtWrVUrZs2eTr66vAwEAdOHDA/vju3btVvXp1eXt7q1ChQurbt69u3bp1z2w2m0158+ZVvnz5VKtWLY0cOVLHjh2zz9BMnz5dTzzxhDw8PPTUU09p/vz5idYfNWqUHn/8cXl6eip//vzq27ev/bF/7oJVpEgRSVLz5s1ls9ns9/+5C9b69evl5eWlGzduJHqNvn37qkaNGqn2PoOCgjRgwACdOXNGv/76q32Ze22PrVu3qnPnzgoLC7PPpIwaNUqSFBMToyFDhqhAgQLy8fFRxYoVtXXr1nvmAYDMigICABZycXHR5MmTdezYMX311VfavHmzhgwZctfl27Vrp4IFC2r//v06ePCghg4dKnd3d0nS0aNHVb9+fb388ss6cuSIlixZop07d+qNN95IUSZvb29JUmxsrFauXKl+/frprbfe0rFjx9SjRw917txZW7ZskSQtW7ZMEyZM0Oeff67ffvtNq1at0rPPPpvs8+7fv1+SNGfOHF26dMl+/5/q1Kkjf39/LV++3D4WHx+vpUuXql27dqn2Pm/cuKGFCxdKkv3nJ917e1SpUkUTJ060z6RcunRJgwYNkiR17txZu3bt0uLFi3XkyBG9+uqratCggX777bcHzgQAmYYBAKSpjh07GldXV+Pj42O/tWjRItllly5danLkyGG/P2fOHOPn52e/ny1bNjN37txk123fvr15/fXXE43t2LHDuLi4mNu3bye7zr+f/9y5c6ZSpUqmYMGCJjo62lSpUsV079490TqvvvqqadSokTHGmHHjxpkSJUqYmJiYZJ+/cOHCZsKECfb7kszKlSsTLTNy5Ejz3HPP2e/37dvX1K5d235//fr1xsPDw1y7du2R3qck4+PjY7JkyWIkGUmmadOmyS5/x/22hzHG/P7778Zms5kLFy4kGn/hhRfMsGHD7vn8AJAZuVlbfwAgc6hVq5amT59uv+/j4yNJ2rJliz788EOFhIQoPDxccXFxioqK0q1bt+zL/NPAgQPVrVs3zZ8/X3Xq1NGrr76qJ554QpJ08OBB/f7771qwYIF9eWOMEhISdOrUKZUqVSrZbGFhYcqaNauMMYqMjFS5cuW0YsUKeXh46Pjx44kOIpekqlWratKkSZKkV199VRMnTlSxYsXUoEEDNWrUSE2aNJGb28P/eWnXrp0qV66sixcvKn/+/FqwYIEaNWqk7NmzP9L7zJYtmw4dOqS4uDht27ZNn3zyiWbMmJFomZRuD0k6dOiQjDEqUaJEovHo6GiHHNsCABkNBQQAHMDHx0fFixdPNHbmzBk1atRIPXv21HvvvafHHntMO3fuVNeuXRUbG5vs84waNUpt27bVd999p++//14jR47U4sWL1bx5cyUkJKhHjx6JjsG44/HHH79rtjsfzF1cXJQnT54kH7RtNlui+8YY+1ihQoX066+/auPGjdq0aZN69+6tTz75RNu2bUu0a1NKVKhQQU888YQWL16sXr16aeXKlZozZ4798Yd9ny4uLvZtULJkSYWGhqpVq1bavn27pIfbHnfyuLq66uDBg3J1dU30WNasWVP03gEgM6CAAIBFDhw4oLi4OI0bN04uLn8fkrd06dL7rleiRAmVKFFCAwYMUJs2bTRnzhw1b95c5cqV088//5yk6NzPPz+Y/1upUqW0c+dOdejQwT62e/fuRLMM3t7eatq0qZo2bao+ffqoZMmSOnr0qMqVK5fk+dzd3R/o7Fpt27bVggULVLBgQbm4uKhx48b2xx72ff7bgAEDNH78eK1cuVLNmzd/oO3h4eGRJH9AQIDi4+N1+fJlVatW7ZEyAUBmwEHoAGCRJ554QnFxcfrss8908uRJzZ8/P8kuQf90+/ZtvfHGG9q6davOnDmjXbt2af/+/fYy8Pbbb2vPnj3q06ePgoOD9dtvv2n16tV68803Hzrj4MGDNXfuXM2YMUO//fabxo8frxUrVtgPvp47d65mz56tY8eO2d+Dt7e3ChcunOzzFSlSRD/88INCQ0N1/fr1u75uu3btdOjQIX3wwQdq0aKFvLy87I+l1vv09fVVt27dNHLkSBljHmh7FClSRDdv3tQPP/ygK1euKDIyUiVKlFC7du3UoUMHrVixQqdOndL+/fv13//+V2vXrk1RJgDIFKw8AAUAMoOOHTuaZs2aJfvY+PHjTb58+Yy3t7epX7++mTdvnpFkrl+/boxJfNBzdHS0ad26tSlUqJDx8PAw+fPnN2+88UaiA6/37dtn6tata7JmzWp8fHxMmTJlzAcffHDXbMkdVP1v06ZNM8WKFTPu7u6mRIkSZt68efbHVq5caSpWrGh8fX2Nj4+PqVSpktm0aZP98X8fhL569WpTvHhx4+bmZgoXLmyMSXoQ+h3ly5c3kszmzZuTPJZa7/PMmTPGzc3NLFmyxBhz/+1hjDE9e/Y0OXLkMJLMyJEjjTHGxMTEmBEjRpgiRYoYd3d3kzdvXtO8eXNz5MiRu2YCgMzKZowx1lYgAAAAAJkFu2ABAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcBgKCAAAAACHoYAAAAAAcJj/BxJWroagGesIAAAAAElFTkSuQmCC' width=800.0/>
</div>



# Analysis
#it appears that once I wrangled this dataset, by getting rid of NA values and any non numeric data that it was in much better shape to look at the correlations of the linking chronic kidney disease and insulin resistance. I am assuming that the Labels refer to the control versus the CKD groups and then we have the lab values taken for both groups and the differences in their response to insulin. Looking at the tryptophan box plots I saw that  the values are not that much different in the two groups. Then I made the correlation matrix between columns of data and there seems to be strong positive positive correlations and makes me think that this data set quality is good now. Then we seem to have a good number fo correlations that are >90%. Going further, creating test and train sets helped in the process to see how well this dataset would be in predictions of CKD and insulin resistance. The values for the final prediction for understanding the "goodness" of the predictive value was very good!
Accuracy: 0.9583
Precision: 1.0000
Recall: 0.9375
F1 Score: 0.9677
Confusion Matrix:
 [[ 8  0]
 [ 

 I am not sure about the generalizability of this wrangled dataset but I am new to this process. This assignment did get my brain cells going on some basics around data wrangling.1 15]]


```python

```
